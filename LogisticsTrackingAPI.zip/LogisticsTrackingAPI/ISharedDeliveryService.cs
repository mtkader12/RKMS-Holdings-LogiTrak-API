﻿using LogisticsTrackingAPI.ResourceAccess;

public interface ISharedDeliveryService
{
    Task<DeliveryDto> GetDeliveryByIdAsync(int deliveryId);
    Task<List<DeliveryDto>> GetDeliveriesByDriverIdAsync(int driverId);
    Task AssignResourcesToDeliveryAsync(int deliveryId, int driverId, int vehicleId, int trailerId);
    Task<List<Driver>> GetDriversAsync(); // Add this method
    Task UpdateDeliveryAsync(int deliveryId, DeliveryDto deliveryDto);
}

public class SharedDeliveryService : ISharedDeliveryService
{
    private readonly DeliveryResource _deliveryResource;
    private readonly DriverResource _driverResource;
    public SharedDeliveryService(DeliveryResource deliveryResource, DriverResource driverResource)
    {
        _deliveryResource = deliveryResource ?? throw new ArgumentNullException(nameof(deliveryResource));
        _driverResource = driverResource ?? throw new ArgumentNullException(nameof(driverResource));
    }
    public async Task<List<Driver>> GetDriversAsync()
    {
        return await _driverResource.GetAllAsync(); // Fetch all drivers
    }
    public async Task<DeliveryDto> GetDeliveryByIdAsync(int deliveryId)
    {
        var delivery = await _deliveryResource.GetByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

        // Map Delivery to DeliveryDto
        return MapToDto(delivery);
    }
    // Helper Method for Mapping
    private DeliveryDto MapToDto(Delivery delivery)
    {
        return new DeliveryDto
        {
            Id = delivery.Id,
            ClientId = delivery.ClientId,
            LoadType = delivery.LoadType,
            PickupLocation = delivery.PickupLocation,
            DeliveryLocation = delivery.DeliveryLocation,
            Pricing = delivery.Pricing,
            ScheduledDate = delivery.ScheduledDate,
            RiskLevel = delivery.RiskLevel,
            DriverId = delivery.DriverId
        };
    }

    public async Task UpdateDeliveryAsync(int deliveryId, DeliveryDto deliveryDto)
    {
        if (deliveryDto == null) throw new ArgumentNullException(nameof(deliveryDto));

        var existingDelivery = await _deliveryResource.GetByIdAsync(deliveryId);
        if (existingDelivery == null) throw new KeyNotFoundException("Delivery not found");

        // Update properties
        existingDelivery.TrailerId = deliveryDto.TrailerId;
        existingDelivery.PickupLocation = deliveryDto.PickupLocation;
        existingDelivery.DeliveryLocation = deliveryDto.DeliveryLocation;
        existingDelivery.ScheduledDate = deliveryDto.ScheduledDate;
        existingDelivery.Pricing = deliveryDto.Pricing;

        await _deliveryResource.UpdateAsync(existingDelivery);
    }
    public async Task<List<DeliveryDto>> GetDeliveriesByDriverIdAsync(int driverId)
    {
        var deliveries = await _deliveryResource.GetDeliveriesByDriverIdAsync(driverId);
        if (deliveries == null || !deliveries.Any()) return new List<DeliveryDto>();

        // Map each Delivery to DeliveryDto
        return deliveries.Select(MapToDto).ToList();
    }

    public async Task AssignResourcesToDeliveryAsync(int deliveryId, int driverId, int vehicleId, int trailerId)
    {
        // Logic to assign resources (driver, vehicle, trailer) to a delivery.
    }
}
