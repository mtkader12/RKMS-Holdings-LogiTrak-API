﻿namespace LogisticsTrackingAPI.Constants
{
    public static class PredefinedMessages
    {
        public static readonly List<string> DriverMessages = new()
        {
            "Reached pickup location",
            "Loading goods",
            "On the way to delivery",
            "Delivery completed",
            "Delay due to traffic"
        };

        public static readonly List<string> ClientMessages = new()
        {
            "Request ETA",
            "Request current location",
            "Cancel booking",
            "Book a new trip",
            "Report an issue"
        };
    }
}
