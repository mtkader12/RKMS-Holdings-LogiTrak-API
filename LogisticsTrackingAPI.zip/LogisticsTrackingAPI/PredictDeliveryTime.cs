﻿namespace LogisticsTrackingAPI
{
    public class PredictDeliveryTimeService
    {
        private readonly HttpClient _httpClient;

        public PredictDeliveryTimeService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<int> PredictDeliveryTimeAsync(int distance, string trafficConditions, string weather)
        {
            var response = await _httpClient.PostAsJsonAsync("https://your-ml-api/predict", new
            {
                distance,
                trafficConditions,
                weather
            });

            return await response.Content.ReadFromJsonAsync<int>();
        }
    }

}
