﻿public class User
{
    public int Id { get; set; }
    public string Username { get; set; }
    public string Email { get; set; }
    public string PasswordHash { get; set; }
    public string PhoneNumber { get; set; }
    public string Role { get; set; }
    public int CompanyId { get; set; }
    public Company Company { get; set; }

    public int AccessLevelId { get; set; }
    public AccessLevel AccessLevel { get; set; }

  //  public ICollection<Notification> Notifications { get; set; }
}
