﻿public class WeatherConditions
{
    public int WeatherId { get; set; }
    public int VehicleId { get; set; }
    public string Condition { get; set; } // e.g., Clear, Rainy, Snowy
    public double Temperature { get; set; } // In Celsius
    public DateTime Timestamp { get; set; }
    public double Humidity { get; set; } // In percentage
    public string Location { get; set; }   
    // Navigation Properties
    public Vehicle Vehicle { get; set; }


    // Foreign key to Delivery
    public int DeliveryId { get; set; }

    // Navigation property for Delivery
    public Delivery Delivery { get; set; }
}
