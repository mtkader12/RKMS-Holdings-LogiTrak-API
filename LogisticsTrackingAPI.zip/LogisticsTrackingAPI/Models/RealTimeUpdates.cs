﻿public class RealTimeUpdates
{
    public int Id { get; set; }
    public int VehicleId { get; set; }
    public DateTime Timestamp { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public decimal Speed { get; set; } // In km/h

    // Navigation property
    public Vehicle Vehicle { get; set; }
    public Trailer Trailer { get; set; }
}
