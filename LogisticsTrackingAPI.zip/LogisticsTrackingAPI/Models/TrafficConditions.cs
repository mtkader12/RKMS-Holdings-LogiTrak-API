﻿public class TrafficConditions
{
    public int TrafficId { get; set; }
    public int VehicleId { get; set; }
    public string Condition { get; set; }
    public DateTime Timestamp { get; set; }
    public string Location { get; set; }
    public int Severity { get; set; } // e.g., High, Medium, Low

    // Navigation properties
    public Vehicle Vehicle { get; set; }

    // Add LogisticsRoute navigation
    public int? LogisticsRouteId { get; set; } // Nullable if traffic may not always link to a route
    public LogisticsRoute LogisticsRoute { get; set; }
    // Foreign key to Delivery
    public int DeliveryId { get; set; }

    // Navigation property for Delivery
    public Delivery Delivery { get; set; }
}
