﻿public class HistoricalDeliveryData
{
    public int Id { get; set; }
    public int DeliveryId { get; set; }
    public int VehicleId { get; set; }
    public int DriverId { get; set; }
    public DateTime DeliveryTime { get; set; }
    public string Delays { get; set; }
    public DateTime Timestamp { get; set; }
    public string DeliveryStatus { get; set; }
    public double DistanceTraveled { get; set; }
    public string TrafficConditionsSummary { get; set; } // E.g., "Heavy traffic near stops"
    public string WeatherConditionsSummary { get; set; } // E.g., "Rainy with fog"

    // Navigation Properties
    public Vehicle Vehicle { get; set; }
    public Driver Driver { get; set; }
    public LogisticsRoute LogisticsRoute { get; set; }
    public Delivery Delivery { get; set; }
}