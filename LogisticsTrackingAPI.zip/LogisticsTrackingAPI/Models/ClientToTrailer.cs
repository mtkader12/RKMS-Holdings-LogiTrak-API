﻿public class ClientToTrailer
{
    public int ClientToTrailerId { get; set; }
    public int TrailerId { get; set; }
    public int ClientId { get; set; }
    public string GoodsDescription { get; set; }
    public DateTime DateAssigned { get; set; }

    // Navigation properties
    public Trailer Trailer { get; set; }
    public Client Client { get; set; }
}
