﻿public class Driver
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string LicenseNumber { get; set; }
    public string PhoneNumber { get; set; }
    public string Address { get; set; }
    public int SkillLevel { get; set; } // High, Medium, Low
    public int Experience { get; set; }
    public decimal CurrentRating { get; set; }
    // Relationships
    public int? TrailerId { get; set; }
    public int? VehicleId { get; set; }

    // Navigation property
    public ICollection<Delivery> Deliveries { get; set; }
}