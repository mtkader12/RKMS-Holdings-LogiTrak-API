﻿public class Client
{
    public int Id { get; set; }
    public int CompanyId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
    public string PhoneNumber { get; set; }
   // public int DeliveryId { get; set; }
    // Navigation property
    public Company Company { get; set; }
    // Add this navigation property
    public ICollection<Delivery> Deliveries { get; set; }
}