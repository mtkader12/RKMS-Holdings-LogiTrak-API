﻿//public class Notification
//{
//    public int Id { get; set; }
//    public string Message { get; set; }
//    public int RecipientId { get; set; } // Link to the Client or User
//    public DateTime SentDate { get; set; }
//    public NotificationStatus Status { get; set; } // Enum: Sent, Failed, Pending

//    // Navigation Properties
//    public User User { get; set; }
//    public Client Client { get; set; }
//}

//public enum NotificationStatus
//{
//    Sent,
//    Failed,
//    Pending
//}
