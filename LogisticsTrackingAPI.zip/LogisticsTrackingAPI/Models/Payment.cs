﻿public class Payment
{
    public int Id { get; set; }
    public double Amount { get; set; }
    public DateTime PaymentDate { get; set; }
    public string Status { get; set; } // e.g., Completed, Pending, Failed
    public int ClientId { get; set; }
    // Navigation properties
    public int DeliveryId { get; set; }
    public Delivery Delivery { get; set; }
    public Client Client { get; set; }
}
