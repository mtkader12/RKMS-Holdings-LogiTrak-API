﻿public class Delivery
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string LoadType { get; set; } // e.g., Full Trailer, Pallets
    public int? PalletCount { get; set; }
    public string Urgency { get; set; } // High, Medium, Low
    public string PickupLocation { get; set; }
    public string DeliveryLocation { get; set; }
    public DateTime ScheduledDate { get; set; }
    public decimal Pricing { get; set; }
    public bool HasArrears { get; set; } // New field
    public int? DriverId { get; set; }
    public int RiskLevel { get; set; } // 1 = Low, 5 = High
    public string Status { get; set; } // e.g., In Transit, Delivered, Cancelled
    public int? VehicleId { get; set; }
    public int? TrailerId { get; set; }
    // Navigation property
    public Vehicle Vehicle { get; set; }
    public Driver Driver { get; set; }
    public Client Client { get; set; }
    public Trailer Trailer { get; set; }
    public LogisticsRoute LogisticsRoute { get; set; }
    public ICollection<WeatherConditions> WeatherConditions { get; set; }
    public ICollection<TrafficConditions> TrafficConditions { get; set; }
}
