﻿//public class IncidentReport
//{
//    public int Id { get; set; }
//    public int DeliveryId { get; set; }
//    public string Description { get; set; }
//    public DateTime IncidentDate { get; set; }
//    public string Severity { get; set; } // e.g., High, Medium, Low

//    // Navigation property
//    public Delivery Delivery { get; set; }
//    public Driver Driver { get; set; }
//    public int DriverId { get; set; }
//}