﻿public class LogisticsRoute
{
    public int Id { get; set; }
    public int DeliveryId { get; set; }
    public string DepotLocation { get; set; }
    public string Stops { get; set; } // JSON string for stops
    public decimal Distance { get; set; }
    public TimeSpan EstimatedTime { get; set; }

    // Navigation property
    public Delivery Delivery { get; set; }

    // Add collection for TrafficConditions
    public ICollection<TrafficConditions> TrafficConditions { get; set; }
}