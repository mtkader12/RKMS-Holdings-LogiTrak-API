﻿public class TypeOfGoods
{
    public int GoodsId { get; set; }
    public int? TrailerId { get; set; }
    public string GoodsType { get; set; }
    public DateTime Timestamp { get; set; }
    public string GoodsName { get; set; }
    public string Category { get; set; }
    public string HazardClass { get; set; } // e.g., Flammable, Fragile

    // Navigation property
    public Trailer Trailer { get; set; }
}
