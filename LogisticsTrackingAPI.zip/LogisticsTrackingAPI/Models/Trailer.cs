﻿public class Trailer
{
    public int TrailerId { get; set; }
    public string TrailerNumber { get; set; } // Unique identifier
    public int? VehicleId { get; set; }
    public string TrackerId { get; set; } // Unique tracker ID
    public int Capacity { get; set; }
    public string Type { get; set; } // e.g., Tautliner
    public string Status { get; set; } // Available, In Use, Maintenance
    public string Location { get; set; }
    public DateTime LastServiced { get; set; }
    public int? DeliveryId { get; set; }
    public int? DriverId { get; set; }

    public int? ClientId { get; set; }

    // Navigation properties
    public Client Client { get; set; }
    public Vehicle Vehicle { get; set; }
    public Driver Driver { get; set; }
    public Delivery Delivery { get; set; }
    public ICollection<TypeOfGoods> TypeOfGoods { get; set; }
    public ICollection<ClientToTrailer> Clients { get; set; }
}
