﻿public class Pricing
{
    public int Id { get; set; }
    public string TrailerType { get; set; } // e.g., Tautliner, Flatbed
    public decimal DistanceRate { get; set; } // Rate per kilometer
    public decimal LoadRate { get; set; } // Rate based on load
    public decimal ContractRate { get; set; } // Contract-based pricing
}
