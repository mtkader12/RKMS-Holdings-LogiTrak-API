﻿public class DriverPerformance
{
    public int Id { get; set; }
    public int DriverId { get; set; }
    public int DeliveryId { get; set; }
    public int MilesDriven { get; set; }
    public decimal FuelConsumed { get; set; } // In liters
    public TimeSpan TimeTaken { get; set; }
    public string PerformanceRating { get; set; } // e.g., Excellent, Good, Average, Poor
    public decimal AIOverallScore { get; set; }

    // Navigation properties
    public Driver Driver { get; set; }
    public Delivery Delivery { get; set; }
}
