using LogisticsTrackingAPI.Orchestration;
using LogisticsTrackingAPI.ResourceAccess;
using LogisticsTrackingAPI.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();
builder.Services.AddDbContext<AppDatabaseContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// Explicitly specify TrafficConditionsResource constructor
builder.Services.AddScoped<TrafficConditionsResource>(sp =>
{
    var dbContext = sp.GetRequiredService<AppDatabaseContext>();
    return new TrafficConditionsResource(dbContext); // Use AppDatabaseContext constructor
});

// Register Resources
builder.Services.AddScoped<TrailerResource>();
builder.Services.AddScoped<ClientToTrailerResource>();
builder.Services.AddScoped<RealTimeUpdatesResource>();
builder.Services.AddScoped<ClientResource>();
builder.Services.AddScoped<DeliveryResource>();
builder.Services.AddScoped<DriverResource>();
builder.Services.AddScoped<DriverPerformanceResource>();
builder.Services.AddScoped<VehicleResource>();
builder.Services.AddScoped<UserResource>();
builder.Services.AddScoped<CompanyResource>();
builder.Services.AddScoped<LogisticsRouteResource>();
builder.Services.AddScoped<PaymentResource>();
builder.Services.AddScoped<DriverResource>();
builder.Services.AddScoped<DriverService>();
builder.Services.AddScoped<DeliveryResource>();
builder.Services.AddScoped<DeliveryService>();
builder.Services.AddScoped<ISharedDeliveryService, SharedDeliveryService>();

builder.Services.AddScoped<AccessLevelResource>();

builder.Services.AddScoped<AccessLevelOrchestration>();
builder.Services.AddScoped<ClientOrchestration>();
builder.Services.AddScoped<CompanyOrchestration>();
builder.Services.AddScoped<DeliveryOrchestration>();
builder.Services.AddScoped<DriverOrchestration>();
builder.Services.AddScoped<DriverPerformanceOrchestration>();
builder.Services.AddScoped<LogisticsRouteOrchestration>();
builder.Services.AddScoped<TrafficConditionsOrchestration>();
builder.Services.AddScoped<WeatherConditionsOrchestration>();
builder.Services.AddScoped<WeatherConditionsService>();
builder.Services.AddScoped<WeatherConditionsResource>();
// Register Services
builder.Services.AddScoped<DriverService>();
builder.Services.AddScoped<DeliveryService>();
builder.Services.AddScoped<TrailerService>();
builder.Services.AddScoped<ClientToTrailerService>();
builder.Services.AddScoped<RealTimeUpdatesService>();
builder.Services.AddScoped<TrafficConditionsService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<ClientService>();
builder.Services.AddScoped<DriverPerformanceService>();
builder.Services.AddScoped<AccessLevelServices>();
builder.Services.AddScoped<CompanyService>();
builder.Services.AddScoped<PaymentService>();
builder.Services.AddScoped<LogisticsRouteService>();

// Add shared services
builder.Services.AddScoped<ISharedDeliveryService, SharedDeliveryService>();

// Register Notification Service
builder.Services.AddSingleton<NotificationService>(sp =>
    new NotificationService(
        accountSid: "your_account_sid",
        authToken: "your_auth_token",
        fromPhoneNumber: "your_twilio_whatsapp_number"
    ));

// Add HttpClient for external service integration
builder.Services.AddHttpClient();

// Add MemoryCache for caching
builder.Services.AddMemoryCache();

// Add Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Logistics API V1"));
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
