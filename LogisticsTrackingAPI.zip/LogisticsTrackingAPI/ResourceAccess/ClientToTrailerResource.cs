﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class ClientToTrailerResource
    {
        private readonly AppDatabaseContext _context;

        public ClientToTrailerResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all client-to-trailer mappings
        public async Task<List<ClientToTrailer>> GetAllAsync()
        {
            return await _context.ClientToTrailers
                .Include(ct => ct.Client)
                .Include(ct => ct.Trailer)
                .ToListAsync();
        }

        // Get client-to-trailer mapping by ID
        public async Task<ClientToTrailer> GetByIdAsync(int id)
        {
            return await _context.ClientToTrailers
                .Include(ct => ct.Client)
                .Include(ct => ct.Trailer)
                .FirstOrDefaultAsync(ct => ct.ClientToTrailerId == id);
        }

        // Add a new client-to-trailer mapping
        public async Task<int> AddAsync(ClientToTrailer mapping)
        {
            _context.ClientToTrailers.Add(mapping);
            await _context.SaveChangesAsync();

            return mapping.ClientToTrailerId;
        }

        // Update an existing client-to-trailer mapping
        public async Task UpdateAsync(ClientToTrailer mapping)
        {
            _context.ClientToTrailers.Update(mapping);
            await _context.SaveChangesAsync();
        }

        // Delete a client-to-trailer mapping
        public async Task DeleteAsync(ClientToTrailer mapping)
        {
            _context.ClientToTrailers.Remove(mapping);
            await _context.SaveChangesAsync();
        }

        // Validate if client exists by ID
        public async Task<bool> ClientExistsAsync(int clientId)
        {
            return await _context.Clients.AnyAsync(c => c.Id == clientId);
        }

        // Validate if trailer exists by ID
        public async Task<bool> TrailerExistsAsync(int trailerId)
        {
            return await _context.Trailers.AnyAsync(t => t.TrailerId == trailerId);
        }

        // Add this to the ClientToTrailerResource
        public async Task<bool> MappingExistsAsync(int clientId, int trailerId)
        {
            return await _context.ClientToTrailers.AnyAsync(ct => ct.ClientId == clientId && ct.TrailerId == trailerId);
        }

    }
}
