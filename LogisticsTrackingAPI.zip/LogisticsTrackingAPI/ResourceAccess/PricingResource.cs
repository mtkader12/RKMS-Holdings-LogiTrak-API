﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class PricingResource
    {
        private readonly AppDatabaseContext _context;

        public PricingResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all pricing data
        public async Task<List<Pricing>> GetAllAsync()
        {
            return await _context.Pricings.ToListAsync();
        }

        // Get pricing data by ID
        public async Task<Pricing> GetByIdAsync(int id)
        {
            return await _context.Pricings.FindAsync(id);
        }

        // Add new pricing data
        public async Task AddAsync(Pricing pricing)
        {
            _context.Pricings.Add(pricing);
            await _context.SaveChangesAsync();
        }

        // Update existing pricing data
        public async Task<bool> UpdateAsync(Pricing pricing)
        {
            _context.Pricings.Update(pricing);
            var rowsAffected = await _context.SaveChangesAsync();
            return rowsAffected > 0; // Return true if at least one row was updated
        }

        // Delete pricing data
        public async Task DeleteAsync(Pricing pricing)
        {
            _context.Pricings.Remove(pricing);
            await _context.SaveChangesAsync();
        }
    }
}
