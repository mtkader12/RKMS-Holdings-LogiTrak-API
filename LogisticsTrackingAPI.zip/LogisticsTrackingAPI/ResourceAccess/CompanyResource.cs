﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class CompanyResource
    {
        private readonly AppDatabaseContext _context;

        public CompanyResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all companies
        public async Task<List<Company>> GetAllAsync()
        {
            return await _context.Companies.ToListAsync();
        }

        // Get company by ID
        public async Task<Company> GetByIdAsync(int id)
        {
            return await _context.Companies.FindAsync(id);
        }

        // Add a new company
        public async Task AddAsync(Company company)
        {
            _context.Companies.Add(company);
            await _context.SaveChangesAsync();
        }

        // Update an existing company
        public async Task UpdateAsync(Company company)
        {
            _context.Companies.Update(company);
            await _context.SaveChangesAsync();
        }

        // Delete a company
        public async Task DeleteAsync(Company company)
        {
            _context.Companies.Remove(company);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> ExistsAsync(string companyName, string email)
        {
            // Example query logic
            return await _context.Companies
                .AnyAsync(c => c.Name == companyName || c.Email == email);
        }

    }
}
