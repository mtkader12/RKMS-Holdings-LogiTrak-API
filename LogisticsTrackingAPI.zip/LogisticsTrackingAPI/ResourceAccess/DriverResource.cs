﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class DriverResource
    {
        private readonly AppDatabaseContext _context;

        public DriverResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all drivers
        public async Task<List<Driver>> GetAllAsync()
        {
            return await _context.Drivers.ToListAsync();
        }

        // Get driver by ID
        public async Task<Driver> GetByIdAsync(int id)
        {
            return await _context.Drivers.FindAsync(id);
        }

        // Check if driver exists by license number
        public async Task<bool> ExistsAsync(string licenseNumber, int? excludeId = null)
        {
            return await _context.Drivers.AnyAsync(d =>
                d.LicenseNumber == licenseNumber && (excludeId == null || d.Id != excludeId));
        }

        // Add a new driver
        public async Task AddAsync(Driver driver)
        {
            _context.Drivers.Add(driver);
            await _context.SaveChangesAsync();
        }

        // Update an existing driver
        public async Task UpdateAsync(Driver driver)
        {
            _context.Drivers.Update(driver);
            await _context.SaveChangesAsync();
        }

        // Delete a driver
        public async Task DeleteAsync(Driver driver)
        {
            _context.Drivers.Remove(driver);
            await _context.SaveChangesAsync();
        }
    }
}
