﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class TrailerResource
    {
        private readonly AppDatabaseContext _context;

        public TrailerResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all trailers
        public async Task<List<Trailer>> GetAllAsync()
        {
            return await _context.Trailers.ToListAsync();
        }

        // Get trailer by ID
        public async Task<Trailer> GetByIdAsync(int id)
        {
            return await _context.Trailers.FindAsync(id);
        }

        // Add a new trailer
        public async Task<int> AddAsync(Trailer trailer)
        {
            _context.Trailers.Add(trailer);
            await _context.SaveChangesAsync();
            return trailer.TrailerId; // Assuming `Id` is the primary key for the `Trailer` entity
        }

        // Update an existing trailer
        public async Task<bool> UpdateAsync(Trailer trailer)
        {
            var existingTrailer = await _context.Trailers.FindAsync(trailer.TrailerId);
            if (existingTrailer == null)
                return false;

            // Update the properties
            existingTrailer.TrailerNumber = trailer.TrailerNumber;
            existingTrailer.Type = trailer.Type;
            existingTrailer.Status = trailer.Status;
            existingTrailer.Location = trailer.Location;
            existingTrailer.LastServiced = trailer.LastServiced;
            existingTrailer.VehicleId = trailer.VehicleId;
            existingTrailer.DriverId = trailer.DriverId;

            _context.Trailers.Update(existingTrailer);
            await _context.SaveChangesAsync();
            return true; // Indicates success
        }

        // Delete a trailer
        public async Task<bool> DeleteAsync(Trailer trailer)
        {
            _context.Trailers.Remove(trailer);
            await _context.SaveChangesAsync();
            return true; // Return true to indicate success
        }

        public async Task<Trailer> GetTrailerWithDetailsAsync(int trailerId)
        {
            return await _context.Trailers
                .Include(t => t.Vehicle) // Include associated Vehicle
                .Include(t => t.Driver)  // Include associated Driver
                .FirstOrDefaultAsync(t => t.TrailerId == trailerId);
        }

    }
}
