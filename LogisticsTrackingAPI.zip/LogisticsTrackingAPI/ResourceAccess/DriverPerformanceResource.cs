﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class DriverPerformanceResource
    {
        private readonly AppDatabaseContext _context;

        public DriverPerformanceResource(AppDatabaseContext dbContext)
        {
            _context = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        // Get all driver performances
        public async Task<List<DriverPerformance>> GetAllAsync()
        {
            return await _context.DriverPerformances
                .Include(dp => dp.Driver) // Include related Driver entity
                .Include(dp => dp.Delivery) // Include related Delivery entity
                .ToListAsync();
        }

        // Get driver performance by ID
        public async Task<DriverPerformance> GetByIdAsync(int id)
        {
            return await _context.DriverPerformances
                .Include(dp => dp.Driver)
                .Include(dp => dp.Delivery)
                .FirstOrDefaultAsync(dp => dp.Id == id);
        }

        // Get performances by driver ID
        public async Task<List<DriverPerformance>> GetByDriverIdAsync(int driverId)
        {
            return await _context.DriverPerformances
                .Include(dp => dp.Driver)
                .Include(dp => dp.Delivery)
                .Where(dp => dp.DriverId == driverId)
                .ToListAsync();
        }

        // Get performance by driver and delivery IDs
        public async Task<DriverPerformance> GetByDriverAndDeliveryAsync(int driverId, int deliveryId)
        {
            return await _context.DriverPerformances
                .Include(dp => dp.Driver)
                .Include(dp => dp.Delivery)
                .FirstOrDefaultAsync(dp => dp.DriverId == driverId && dp.DeliveryId == deliveryId);
        }

        // Add a new driver performance
        public async Task AddAsync(DriverPerformance performance)
        {
            if (performance == null)
                throw new ArgumentNullException(nameof(performance));

            await _context.DriverPerformances.AddAsync(performance);
            await _context.SaveChangesAsync();
        }

        // Update an existing driver performance
        public async Task UpdateAsync(DriverPerformance performance)
        {
            if (performance == null)
                throw new ArgumentNullException(nameof(performance));

            _context.DriverPerformances.Update(performance);
            await _context.SaveChangesAsync();
        }

        // Delete a driver performance
        public async Task DeleteAsync(DriverPerformance performance)
        {
            if (performance == null)
                throw new ArgumentNullException(nameof(performance));

            _context.DriverPerformances.Remove(performance);
            await _context.SaveChangesAsync();
        }

        // Check if a driver performance record exists by driver and delivery IDs
        public async Task<bool> ExistsAsync(int driverId, int deliveryId)
        {
            return await _context.DriverPerformances
                .AnyAsync(dp => dp.DriverId == driverId && dp.DeliveryId == deliveryId);
        }

        // Get top-performing drivers (for example: by highest rating or most miles driven)
        public async Task<List<DriverPerformance>> GetTopPerformingDriversAsync(int count)
        {
            return await _context.DriverPerformances
                .OrderByDescending(dp => dp.PerformanceRating) // Order by highest performance rating
                .Take(count) // Limit results
                .Include(dp => dp.Driver) // Include Driver details
                .ToListAsync();
        }
    }
}
