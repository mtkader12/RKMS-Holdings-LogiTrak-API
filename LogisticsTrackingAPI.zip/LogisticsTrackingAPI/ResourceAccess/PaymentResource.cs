﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class PaymentResource
    {
        private readonly AppDatabaseContext _context;

        public PaymentResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all payments
        public async Task<List<Payment>> GetAllAsync()
        {
            return await _context.Payments.ToListAsync();
        }

        // Get payment by ID
        public async Task<Payment> GetByIdAsync(int id)
        {
            return await _context.Payments.FindAsync(id);
        }

        // Add a new payment
        public async Task AddAsync(Payment payment)
        {
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();
        }

        // Update an existing payment
        public async Task UpdateAsync(Payment payment)
        {
            _context.Payments.Update(payment);
            await _context.SaveChangesAsync();
        }

        // Delete a payment
        public async Task DeleteAsync(Payment payment)
        {
            _context.Payments.Remove(payment);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> CheckClientArrearsAsync(int clientId)
        {
            // Replace this with actual logic to check arrears
            var clientHasArrears = await _context.Payments
                .Where(p => p.ClientId == clientId && p.Status != "Pending")
                .AnyAsync();

            return clientHasArrears;

           //     return await _context.Payments
           //.AnyAsync(p => p.ClientId == clientId && p.Status != "Completed");
        }

        public async Task<Payment> GetByDeliveryIdAsync(int deliveryId)
        {
            return await _context.Payments.FirstOrDefaultAsync(p => p.DeliveryId == deliveryId);
        }
    }
}