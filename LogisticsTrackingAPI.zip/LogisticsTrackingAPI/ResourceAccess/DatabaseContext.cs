﻿using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace LogisticsTrackingAPI.ResourceAccess
{
    /// <summary>
    /// Interface for DatabaseContext to enable dependency injection and testing
    /// </summary>
    public interface IDatabaseContext
    {
        IDbConnection CreateConnection();
    }

    /// <summary>
    /// Provides SQL Server connections using a configuration-based connection string
    /// </summary>
    public class DatabaseContext : IDatabaseContext
    {
        private readonly string _connectionString;

        /// <summary>
        /// Constructor that initializes the DatabaseContext with the required configuration
        /// </summary>
        /// <param name="configuration">The application configuration object</param>
        /// <exception cref="ArgumentNullException">Thrown when the connection string is missing or null</exception>
        public DatabaseContext(IConfiguration configuration)
        {
            if (configuration == null)
                throw new ArgumentNullException(nameof(configuration), "Configuration cannot be null.");

            _connectionString = configuration.GetConnectionString("SqlConnection")
                               ?? throw new ArgumentNullException(nameof(_connectionString), "SQL connection string is missing.");
        }

        /// <summary>
        /// Creates and returns a new SQL connection
        /// </summary>
        /// <returns>An open IDbConnection instance</returns>
        public IDbConnection CreateConnection()
        {
            var connection = new SqlConnection(_connectionString);

            // Modern .NET Core/6+ practice avoids explicitly calling .Open(). 
            // Connections should be opened lazily (Dapper will handle this as needed).
            return connection;
        }
    }
}


//using System.Data;
//using System.Data.SqlClient; // Import the SQL Server connection library

//namespace LogisticsTrackingAPI.ResourceAccess
//{
//        public class DatabaseContext
//        {
//            private readonly IConfiguration _configuration;
//            private readonly string _connectionString;

//            public DatabaseContext(IConfiguration configuration)
//            {
//                _configuration = configuration;
//                _connectionString = _configuration.GetConnectionString("SqlConnection"); // Adjusted to SQL Server connection string name
//            }

//            public IDbConnection CreateConnection() => new SqlConnection(_connectionString); // Using SqlConnection for SQL Server
//        }

//}

