﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class LogisticsRouteResource
    {
        private readonly AppDatabaseContext _context;

        public LogisticsRouteResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all logistics routes
        public async Task<List<LogisticsRoute>> GetAllAsync()
        {
            return await _context.LogisticsRoutes
                .Include(lr => lr.Delivery)
                .ToListAsync();
        }

        // Get logistics route by ID
        public async Task<LogisticsRoute> GetByIdAsync(int id)
        {
            return await _context.LogisticsRoutes
                .Include(lr => lr.Delivery)
                .FirstOrDefaultAsync(lr => lr.Id == id);
        }

        // Add a new logistics route
        public async Task AddAsync(LogisticsRoute logisticsRoute)
        {
            _context.LogisticsRoutes.Add(logisticsRoute);
            await _context.SaveChangesAsync();
        }

        // Update an existing logistics route
        public async Task<int> UpdateAsync(LogisticsRoute logisticsRoute)
        {
            _context.LogisticsRoutes.Update(logisticsRoute);
            return await _context.SaveChangesAsync(); // Returns number of affected rows
        }
        // Delete a logistics route
        public async Task DeleteAsync(LogisticsRoute logisticsRoute)
        {
            _context.LogisticsRoutes.Remove(logisticsRoute);
            await _context.SaveChangesAsync();
        }

        // Validate if delivery exists by ID
        public async Task<bool> DeliveryExistsAsync(int deliveryId)
        {
            return await _context.Deliveries.AnyAsync(d => d.Id == deliveryId);
        }

        public async Task<LogisticsRoute> GetByDeliveryIdAsync(int deliveryId)
        {
            return await _context.LogisticsRoutes
                .FirstOrDefaultAsync(lr => lr.DeliveryId == deliveryId);
        }

    }
}
