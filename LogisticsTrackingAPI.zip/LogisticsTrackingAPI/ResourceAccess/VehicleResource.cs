﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class VehicleResource
    {
        private readonly AppDatabaseContext _context;

        public VehicleResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all vehicles
        public async Task<List<Vehicle>> GetAllAsync()
        {
            return await _context.Vehicles.ToListAsync();
        }

        // Get vehicle by ID
        public async Task<Vehicle> GetByIdAsync(int id)
        {
            return await _context.Vehicles.FindAsync(id);
        }

        // Add a new vehicle
        public async Task AddAsync(Vehicle vehicle)
        {
            _context.Vehicles.Add(vehicle);
            await _context.SaveChangesAsync();
        }

        // Update an existing vehicle
        public async Task UpdateAsync(Vehicle vehicle)
        {
            _context.Vehicles.Update(vehicle);
            await _context.SaveChangesAsync();
        }

        // Delete a vehicle
        public async Task DeleteAsync(Vehicle vehicle)
        {
            _context.Vehicles.Remove(vehicle);
            await _context.SaveChangesAsync();
        }

        // Check if vehicle registration number exists
        public async Task<bool> ExistsAsync(string registrationNumber, int? excludeId = null)
        {
            return await _context.Vehicles.AnyAsync(v =>
                v.RegistrationNumber == registrationNumber && (excludeId == null || v.Id != excludeId));
        }
    }
}
