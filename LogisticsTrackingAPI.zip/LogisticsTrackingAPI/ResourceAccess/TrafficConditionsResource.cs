﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class TrafficConditionsResource
    {
        private readonly AppDatabaseContext _context;

        public TrafficConditionsResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all traffic conditions
        public async Task<List<TrafficConditions>> GetAllAsync()
        {
            return await _context.TrafficConditions
                .Include(tc => tc.Vehicle)
                .ToListAsync();
        }

        // Get traffic condition by ID
        public async Task<TrafficConditions> GetByIdAsync(int id)
        {
            return await _context.TrafficConditions
                .Include(tc => tc.Vehicle)
                .FirstOrDefaultAsync(tc => tc.TrafficId == id);
        }

        // Add a new traffic condition
        public async Task<int> AddAsync(TrafficConditions condition)
        {
            _context.TrafficConditions.Add(condition);
            await _context.SaveChangesAsync();

            // Return the ID of the newly added TrafficCondition
            return condition.TrafficId;
        }


        // Update an existing traffic condition
        public async Task<int> UpdateAsync(TrafficConditions condition)
        {
            _context.TrafficConditions.Update(condition);
            return await _context.SaveChangesAsync(); // Return the number of rows affected
        }

        // Delete a traffic condition
        public async Task DeleteAsync(TrafficConditions condition)
        {
            _context.TrafficConditions.Remove(condition);
            await _context.SaveChangesAsync();
        }

        public async Task AddRangeAsync(IEnumerable<TrafficConditions> conditions)
        {
            // Add the conditions to the database context
            _context.TrafficConditions.AddRange(conditions);

            // Save changes to the database
            await _context.SaveChangesAsync();
        }


        // Validate if vehicle exists by ID
        public async Task<bool> VehicleExistsAsync(int vehicleId)
        {
            return await _context.Vehicles.AnyAsync(v => v.Id == vehicleId);
        }

            private readonly HttpClient _httpClient;
            private const string HereApiBaseUrl = "https://traffic.ls.hereapi.com/traffic/6.3/flow.json";

            private readonly string _appId = "rh8A3CwSRmkNuO5u64k3"; // Replace with your actual App ID
            private readonly string _apiKey = "i7lXBVv7viMZfchm2Y0T7OAB8uHF8-tBl9imn_Hppn8"; // Replace with your actual API key

            public TrafficConditionsResource(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }

            public async Task<List<TrafficConditions>> FetchTrafficDataAsync(string pickupLocation, string deliveryLocation)
            {
                try
                {
                    // Prepare the request URL
                    var url = $"{HereApiBaseUrl}?apiKey={_apiKey}&bbox={pickupLocation};{deliveryLocation}&responseattributes=sh";

                    // Send HTTP GET request
                    var response = await _httpClient.GetAsync(url);

                    if (!response.IsSuccessStatusCode)
                    {
                        throw new Exception($"Failed to fetch traffic data. Status code: {response.StatusCode}");
                    }

                    // Parse the JSON response
                    var content = await response.Content.ReadAsStringAsync();
                    var trafficData = JsonSerializer.Deserialize<HereTrafficResponse>(content);

                    // Map the traffic data to your domain model
                    return MapTrafficData(trafficData);
                }
                catch (Exception ex)
                {
                    // Log and handle exceptions
                    throw new Exception($"An error occurred while fetching traffic data: {ex.Message}");
                }
            }

            private List<TrafficConditions> MapTrafficData(HereTrafficResponse trafficResponse)
            {
                var trafficConditions = new List<TrafficConditions>();

                foreach (var flowSegment in trafficResponse.Rws[0].Roads)
                {
                    trafficConditions.Add(new TrafficConditions
                    {
                        Location = flowSegment.Description,
                        Severity = flowSegment.CurrentSpeed < flowSegment.FreeFlowSpeed
                            ? 3 // High severity (Congested)
                            : 1 // Low severity (Normal)
                        ,Timestamp = DateTime.UtcNow
                    });
                }

                return trafficConditions;
            }
        }

        // Example response class for HERE Traffic API
        public class HereTrafficResponse
        {
            public Rws[] Rws { get; set; }
        }

        public class Rws
        {
            public Road[] Roads { get; set; }
        }

        public class Road
        {
            public string Description { get; set; }
            public int CurrentSpeed { get; set; }
            public int FreeFlowSpeed { get; set; }
        }
}
