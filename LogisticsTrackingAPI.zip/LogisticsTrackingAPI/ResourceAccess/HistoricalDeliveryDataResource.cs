﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class HistoricalDeliveryDataResource
    {
        private readonly AppDatabaseContext _context;

        public HistoricalDeliveryDataResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all historical delivery data
        public async Task<List<HistoricalDeliveryData>> GetAllAsync()
        {
            return await _context.HistoricalDeliveryData
                .Include(h => h.Vehicle)
                .Include(h => h.Driver)
                .Include(h => h.Delivery)
                .ToListAsync();
        }

        // Get historical data by delivery ID
        public async Task<HistoricalDeliveryData> GetByDeliveryIdAsync(int deliveryId)
        {
            return await _context.HistoricalDeliveryData
                .Include(h => h.Vehicle)
                .Include(h => h.Driver)
                .Include(h => h.Delivery)
                .FirstOrDefaultAsync(h => h.DeliveryId == deliveryId);
        }

        // Add new historical data
        public async Task AddAsync(HistoricalDeliveryData data)
        {
            _context.HistoricalDeliveryData.Add(data);
            await _context.SaveChangesAsync();
        }

        // Update historical data
        public async Task UpdateAsync(HistoricalDeliveryData data)
        {
            _context.HistoricalDeliveryData.Update(data);
            await _context.SaveChangesAsync();
        }

        // Delete historical data
        public async Task DeleteAsync(HistoricalDeliveryData data)
        {
            _context.HistoricalDeliveryData.Remove(data);
            await _context.SaveChangesAsync();
        }

        // Check if related entities exist
        public async Task<bool> VehicleExistsAsync(int vehicleId) =>
            await _context.Vehicles.AnyAsync(v => v.Id == vehicleId);

        public async Task<bool> DriverExistsAsync(int driverId) =>
            await _context.Drivers.AnyAsync(d => d.Id == driverId);

        public async Task<bool> DeliveryExistsAsync(int deliveryId) =>
            await _context.Deliveries.AnyAsync(d => d.Id == deliveryId);

        // Check for duplicate historical data
        public async Task<bool> ExistsAsync(int deliveryId) =>
            await _context.HistoricalDeliveryData.AnyAsync(h => h.DeliveryId == deliveryId);
    }
}
