﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class UserResource
    {
        private readonly AppDatabaseContext _context;

        public UserResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all users
        public async Task<List<User>> GetAllAsync()
        {
            return await _context.Users
                .Include(u => u.Company)
                .Include(u => u.AccessLevel)
                .ToListAsync();
        }

        // Get user by ID
        public async Task<User> GetByIdAsync(int id)
        {
            return await _context.Users
                .Include(u => u.Company)
                .Include(u => u.AccessLevel)
                .FirstOrDefaultAsync(u => u.Id == id);
        }

        // Add a new user
        public async Task AddAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
        }

        // Update an existing user
        public async Task UpdateAsync(User user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        // Delete a user
        public async Task DeleteAsync(User user)
        {
            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }

        // Check if username or email exists
        public async Task<bool> ExistsAsync(string username, string email, int? excludeId = null)
        {
            return await _context.Users.AnyAsync(u =>
                (u.Username == username || u.Email == email) && (excludeId == null || u.Id != excludeId));
        }

        // Check if company exists
        public async Task<bool> CompanyExistsAsync(int companyId)
        {
            return await _context.Companies.AnyAsync(c => c.Id == companyId);
        }

        // Check if access level exists
        public async Task<bool> AccessLevelExistsAsync(int accessLevelId)
        {
            return await _context.AccessLevels.AnyAsync(a => a.AccessLevelId == accessLevelId);
        }

        public async Task<List<UserDto>> GetUsersByCompanyIdAsync(int companyId)
        {
            return await _context.Users
                .Where(u => u.CompanyId == companyId)
                .Select(u => new UserDto
                {
                    Id = u.Id,
                    Username = u.Username,
                    Email = u.Email,
                    PhoneNumber = u.PhoneNumber,
                    Role = u.Role,
                    CompanyId = u.CompanyId,
                    AccessLevelId = u.AccessLevelId
                }).ToListAsync();
        }

    }
}
