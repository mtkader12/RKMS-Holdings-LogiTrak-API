﻿//using Microsoft.EntityFrameworkCore;
//using System.Collections.Generic;
//using System.Threading.Tasks;

//namespace LogisticsTrackingAPI.ResourceAccess
//{
//    public class IncidentReportResource
//    {
//        private readonly AppDatabaseContext _context;

//        public IncidentReportResource(AppDatabaseContext context)
//        {
//            _context = context;
//        }

//        // Get all incident reports
//        public async Task<List<IncidentReport>> GetAllAsync()
//        {
//            return await _context.IncidentReports
//                .Include(ir => ir.Delivery)
//                .ToListAsync();
//        }

//        // Get incident report by ID
//        public async Task<IncidentReport> GetByIdAsync(int id)
//        {
//            return await _context.IncidentReports
//                .Include(ir => ir.Delivery)
//                .FirstOrDefaultAsync(ir => ir.Id == id);
//        }

//        // Add a new incident report
//        public async Task AddAsync(IncidentReport incidentReport)
//        {
//            _context.IncidentReports.Add(incidentReport);
//            await _context.SaveChangesAsync();
//        }

//        // Update an existing incident report
//        public async Task<int> UpdateAsync(IncidentReport incidentReport)
//        {
//            _context.IncidentReports.Update(incidentReport);
//            return await _context.SaveChangesAsync(); // Return the number of rows affected
//        }


//        // Delete an incident report
//        public async Task<int> DeleteAsync(IncidentReport incidentReport)
//        {
//            _context.IncidentReports.Remove(incidentReport);
//            return await _context.SaveChangesAsync(); // Return the number of rows affected
//        }

//        // Validate if delivery exists by ID
//        public async Task<bool> DeliveryExistsAsync(int deliveryId)
//        {
//            return await _context.Deliveries.AnyAsync(d => d.Id == deliveryId);
//        }

//        public async Task<List<IncidentReport>> GetRecentIncidentsAsync(int driverId)
//        {
//            return await _context.IncidentReports
//                .Where(incident => incident.DriverId == driverId)
//                .OrderByDescending(incident => incident.Timestamp)
//                .Take(5) // Adjust the number as needed
//                .ToListAsync();
//        }

//    }
//}
