﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class WeatherConditionsResource
    {
        private readonly AppDatabaseContext _context;

        public WeatherConditionsResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all weather conditions
        public async Task<List<WeatherConditions>> GetAllAsync()
        {
            return await _context.WeatherConditions
                .Include(wc => wc.Vehicle)
                .ToListAsync();
        }

        // Get weather condition by ID
        public async Task<WeatherConditions> GetByIdAsync(int id)
        {
            return await _context.WeatherConditions
                .Include(wc => wc.Vehicle)
                .FirstOrDefaultAsync(wc => wc.WeatherId == id);
        }

        // Add a new weather condition
        public async Task AddAsync(WeatherConditions condition)
        {
            _context.WeatherConditions.Add(condition);
            await _context.SaveChangesAsync();
        }


        // Update an existing weather condition
        public async Task UpdateAsync(WeatherConditions weatherCondition)
        {
            _context.WeatherConditions.Update(weatherCondition);
            await _context.SaveChangesAsync();
        }

        // Delete a weather condition
        public async Task DeleteAsync(WeatherConditions weatherCondition)
        {
            _context.WeatherConditions.Remove(weatherCondition);
            await _context.SaveChangesAsync();
        }

        // Validate if vehicle exists by ID
        public async Task<bool> VehicleExistsAsync(int vehicleId)
        {
            return await _context.Vehicles.AnyAsync(v => v.Id == vehicleId);
        }
    }
}
