﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;
using LogisticsTrackingAPI.ResourceAccess;

public interface IBaseRepository<T>
{
    Task<IEnumerable<T>> GetAllAsync();
    Task<T> GetByIdAsync(int id);
    Task<int> AddAsync(T entity);
    Task<int> UpdateAsync(T entity);
    Task<int> DeleteAsync(int id);
}

public class BaseRepository<T> : IBaseRepository<T>
{
    private readonly IDatabaseContext _databaseContext;

    public BaseRepository(IDatabaseContext databaseContext)
    {
        _databaseContext = databaseContext;
    }

    public async Task<IEnumerable<T>> GetAllAsync()
    {
        using var connection = _databaseContext.CreateConnection();
        string query = $"SELECT * FROM {typeof(T).Name}s";
        return await connection.QueryAsync<T>(query);
    }

    public async Task<T> GetByIdAsync(int id)
    {
        using var connection = _databaseContext.CreateConnection();
        string query = $"SELECT * FROM {typeof(T).Name}s WHERE Id = @Id";
        return await connection.QuerySingleOrDefaultAsync<T>(query, new { Id = id });
    }

    public async Task<int> AddAsync(T entity)
    {
        using var connection = _databaseContext.CreateConnection();
        string query = $"INSERT INTO {typeof(T).Name}s (...) VALUES (...)"; // Specify columns and parameters
        return await connection.ExecuteAsync(query, entity);
    }

    public async Task<int> UpdateAsync(T entity)
    {
        using var connection = _databaseContext.CreateConnection();
        string query = $"UPDATE {typeof(T).Name}s SET ... WHERE Id = @Id"; // Specify columns and parameters
        return await connection.ExecuteAsync(query, entity);
    }

    public async Task<int> DeleteAsync(int id)
    {
        using var connection = _databaseContext.CreateConnection();
        string query = $"DELETE FROM {typeof(T).Name}s WHERE Id = @Id";
        return await connection.ExecuteAsync(query, new { Id = id });
    }
}
