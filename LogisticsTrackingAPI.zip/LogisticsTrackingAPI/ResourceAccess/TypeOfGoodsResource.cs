﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class TypeOfGoodsResource
    {
        private readonly AppDatabaseContext _context;

        public TypeOfGoodsResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all types of goods
        public async Task<List<TypeOfGoods>> GetAllAsync()
        {
            return await _context.TypeOfGoods
                .Include(tog => tog.Trailer)
                .ToListAsync();
        }

        // Get type of goods by ID
        public async Task<TypeOfGoods> GetByIdAsync(int id)
        {
            return await _context.TypeOfGoods
                .Include(tog => tog.Trailer)
                .FirstOrDefaultAsync(tog => tog.GoodsId == id);
        }

        // Add a new type of goods
        public async Task<int> AddAsync(TypeOfGoods goods)
        {
            _context.TypeOfGoods.Add(goods);
            await _context.SaveChangesAsync();

            return goods.GoodsId; // Assuming `Id` is the primary key that gets generated upon saving
        }


        // Update an existing type of goods
        public async Task UpdateAsync(TypeOfGoods goods)
        {
            _context.TypeOfGoods.Update(goods);
            await _context.SaveChangesAsync();
        }

        // Delete a type of goods
        public async Task DeleteAsync(TypeOfGoods goods)
        {
            _context.TypeOfGoods.Remove(goods);
            await _context.SaveChangesAsync();
        }

        // Validate if trailer exists by ID
        public async Task<bool> TrailerExistsAsync(int trailerId)
        {
            return await _context.Trailers.AnyAsync(t => t.TrailerId == trailerId);
        }
    }
}
