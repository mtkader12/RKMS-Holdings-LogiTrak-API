﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class ClientResource
    {
        private readonly AppDatabaseContext _context;

        public ClientResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all clients
        public async Task<List<Client>> GetAllAsync()
        {
            return await _context.Clients
                .Include(c => c.Company)
                .ToListAsync();
        }

        // Get client by ID
        public async Task<Client> GetByIdAsync(int id)
        {
            return await _context.Clients
                .Include(c => c.Company)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        // Check if client exists by name or email
        public async Task<bool> ExistsAsync(string name, string email, int? excludeId = null)
        {
            return await _context.Clients.AnyAsync(c =>
                (c.Name == name || c.Email == email) &&
                (excludeId == null || c.Id != excludeId));
        }

        // Add a new client
        public async Task AddAsync(Client client)
        {
            _context.Clients.Add(client);
            await _context.SaveChangesAsync();
        }

        // Update an existing client
        public async Task UpdateAsync(Client client)
        {
            _context.Clients.Update(client);
            await _context.SaveChangesAsync();
        }

        // Delete a client
        public async Task DeleteAsync(Client client)
        {
            _context.Clients.Remove(client);
            await _context.SaveChangesAsync();
        }

        // Validate if a company exists by ID
        public async Task<bool> CompanyExistsAsync(int companyId)
        {
            return await _context.Companies.AnyAsync(c => c.Id == companyId);
        }

        public async Task<List<ClientDto>> GetClientsByCompanyIdAsync(int companyId)
        {
            return await _context.Clients
                .Where(c => c.CompanyId == companyId)
                .Select(c => new ClientDto
                {
                    Id = c.Id,
                    Name = c.Name,
                    Email = c.Email,
                    PhoneNumber = c.PhoneNumber,
                    CompanyId = c.CompanyId
                }).ToListAsync();
        }

    }
}
