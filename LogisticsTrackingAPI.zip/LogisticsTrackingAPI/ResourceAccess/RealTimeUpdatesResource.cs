﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class RealTimeUpdatesResource
    {
        private readonly AppDatabaseContext _context;

        public RealTimeUpdatesResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all real-time updates
        public async Task<List<RealTimeUpdates>> GetAllAsync()
        {
            return await _context.RealTimeUpdates
                .Include(rt => rt.Vehicle)
                .ToListAsync();
        }

        // Get real-time update by ID
        public async Task<RealTimeUpdates> GetByIdAsync(int id)
        {
            return await _context.RealTimeUpdates
                .Include(rt => rt.Vehicle)
                .FirstOrDefaultAsync(rt => rt.Id == id);
        }

        // Get updates by vehicle ID
        public async Task<List<RealTimeUpdates>> GetUpdatesByVehicleIdAsync(int vehicleId)
        {
            return await _context.RealTimeUpdates
                .Include(rt => rt.Vehicle)
                .Where(rt => rt.VehicleId == vehicleId)
                .ToListAsync();
        }

        // Add a new real-time update
        public async Task AddAsync(RealTimeUpdates update)
        {
            _context.RealTimeUpdates.Add(update);
            await _context.SaveChangesAsync();
        }

        // Delete a real-time update
        public async Task DeleteAsync(RealTimeUpdates update)
        {
            _context.RealTimeUpdates.Remove(update);
            await _context.SaveChangesAsync();
        }

        // Validate if vehicle exists by ID
        public async Task<bool> VehicleExistsAsync(int vehicleId)
        {
            return await _context.Vehicles.AnyAsync(v => v.Id == vehicleId);
        }
    }
}
