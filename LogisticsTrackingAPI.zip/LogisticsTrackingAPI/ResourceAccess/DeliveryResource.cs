﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.ResourceAccess
{
    public class DeliveryResource
    {
        private readonly AppDatabaseContext _context;

        public DeliveryResource(AppDatabaseContext context)
        {
            _context = context;
        }

        // Get all deliveries
        public async Task<List<Delivery>> GetAllAsync()
        {
            return await _context.Deliveries
                .Include(d => d.Client)
                .ToListAsync();
        }

        // Get delivery by ID
        public async Task<Delivery> GetByIdAsync(int id)
        {
            return await _context.Deliveries
                .Include(d => d.Client)
                .FirstOrDefaultAsync(d => d.Id == id);
        }

        // Check for duplicate deliveries
        public async Task<bool> ExistsAsync(Delivery delivery, int? excludeId = null)
        {
            return await _context.Deliveries.AnyAsync(d =>
                d.ClientId == delivery.ClientId &&
                d.PickupLocation == delivery.PickupLocation &&
                d.DeliveryLocation == delivery.DeliveryLocation &&
                d.ScheduledDate == delivery.ScheduledDate &&
                (excludeId == null || d.Id != excludeId));
        }

        // Add a new delivery
        public async Task AddAsync(Delivery delivery)
        {
            _context.Deliveries.Add(delivery);
            await _context.SaveChangesAsync();
        }

        // Update an existing delivery
        public async Task UpdateAsync(Delivery delivery)
        {
            _context.Deliveries.Update(delivery);
            await _context.SaveChangesAsync();
        }

        // Delete a delivery
        public async Task DeleteAsync(Delivery delivery)
        {
            _context.Deliveries.Remove(delivery);
            await _context.SaveChangesAsync();
        }

        // Validate if client exists by ID
        public async Task<bool> ClientExistsAsync(int clientId)
        {
            return await _context.Clients.AnyAsync(c => c.Id == clientId);
        }

        public async Task<List<Delivery>> GetByClientIdAsync(int clientId)
        {
            return await _context.Deliveries
                .Where(d => d.ClientId == clientId)
                .Select(d => new Delivery
                {
                    Id = d.Id,
                    ClientId = d.ClientId,
                    PickupLocation = d.PickupLocation,
                    DeliveryLocation = d.DeliveryLocation,
                    ScheduledDate = d.ScheduledDate,
                    Pricing = d.Pricing,
                    HasArrears = d.HasArrears
                })
                .ToListAsync();
        }
        public async Task<bool> ExistsAsync(int deliveryId)
        {
            return await _context.Deliveries.AnyAsync(d => d.Id == deliveryId);
        }

        public async Task<List<Delivery>> GetDeliveriesByDriverIdAsync(int driverId)
        {
            return await _context.Deliveries
                .Where(d => d.DriverId == driverId)
                .ToListAsync();
        }

    }
}
