﻿//using Microsoft.EntityFrameworkCore;
//using System.Collections.Generic;
//using System.Threading.Tasks;

//namespace LogisticsTrackingAPI.ResourceAccess
//{
//    public class NotificationResource
//    {
//        private readonly AppDatabaseContext _context;

//        public NotificationResource(AppDatabaseContext context)
//        {
//            _context = context;
//        }

//        // Get all notifications
//        public async Task<List<Notification>> GetAllAsync()
//        {
//            return await _context.Notifications.ToListAsync();
//        }

//        // Get notification by ID
//        public async Task<Notification> GetByIdAsync(int id)
//        {
//            return await _context.Notifications.FindAsync(id);
//        }

//        // Add a new notification
//        public async Task AddAsync(Notification notification)
//        {
//            _context.Notifications.Add(notification);
//            await _context.SaveChangesAsync();
//        }

//        // Update an existing notification
//        public async Task UpdateAsync(Notification notification)
//        {
//            _context.Notifications.Update(notification);
//            await _context.SaveChangesAsync();
//        }

//        // Delete a notification
//        public async Task DeleteAsync(Notification notification)
//        {
//            _context.Notifications.Remove(notification);
//            await _context.SaveChangesAsync();
//        }
//    }
//}
