﻿namespace LogisticsTrackingAPI
{
    using System.Net.Http.Json;

    public class RouteOptimizationService
    {
        private readonly HttpClient _httpClient;

        public RouteOptimizationService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> OptimizeRouteAsync(string origin, string destination, List<string> waypoints)
        {
            var apiKey = "YOUR_API_KEY";
            var waypointsParam = string.Join("|", waypoints);
            var url = $"https://maps.googleapis.com/maps/api/directions/json?origin={origin}&destination={destination}&waypoints={waypointsParam}&key={apiKey}";

            var response = await _httpClient.GetFromJsonAsync<dynamic>(url);
            return response?.routes[0]?.overview_polyline?.points;
        }
    }

}
