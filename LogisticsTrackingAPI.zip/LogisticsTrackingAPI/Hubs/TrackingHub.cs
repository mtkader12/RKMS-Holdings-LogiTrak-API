﻿using Microsoft.AspNetCore.SignalR;

namespace LogisticsTrackingAPI.Hubs
{
    public class TrackingHub : Hub
    {
        public async Task SendTrackingUpdate(string vehicleId, string status, double latitude, double longitude)
        {
            // Broadcast to all connected clients
            await Clients.All.SendAsync("ReceiveTrackingUpdate", vehicleId, status, latitude, longitude);
        }
    }
}
