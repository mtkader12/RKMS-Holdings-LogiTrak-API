﻿using Microsoft.EntityFrameworkCore;

public class AppDatabaseContext : DbContext
{
    public AppDatabaseContext(DbContextOptions<AppDatabaseContext> options) : base(options)
    {
    }

    // DbSet properties for all entities
    public DbSet<AccessLevel> AccessLevels { get; set; }
    public DbSet<Company> Companies { get; set; }
    public DbSet<Client> Clients { get; set; }
    public DbSet<ClientToTrailer> ClientToTrailers { get; set; }
    public DbSet<Vehicle> Vehicles { get; set; }
    public DbSet<Delivery> Deliveries { get; set; }
    public DbSet<Pricing> Pricings { get; set; }
    //public DbSet<IncidentReport> IncidentReports { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<RealTimeUpdates> RealTimeUpdates { get; set; }
    public DbSet<Driver> Drivers { get; set; }
    public DbSet<DriverPerformance> DriverPerformances { get; set; }
    public DbSet<HistoricalDeliveryData> HistoricalDeliveryData { get; set; }
    public DbSet<LogisticsRoute> LogisticsRoutes { get; set; }
    public DbSet<TrafficConditions> TrafficConditions { get; set; }
    public DbSet<Trailer> Trailers { get; set; }
    public DbSet<TypeOfGoods> TypeOfGoods { get; set; }
    public DbSet<WeatherConditions> WeatherConditions { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Other table configurations are unchanged

        // Delivery Table


        // Delivery Table Configuration
        modelBuilder.Entity<Delivery>()
            .HasOne(d => d.Trailer)
            .WithOne(t => t.Delivery)
            .HasForeignKey<Trailer>(t => t.DeliveryId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Trailer>()
            .HasOne(t => t.Delivery)
            .WithOne(d => d.Trailer)
            .HasForeignKey<Delivery>(d => d.TrailerId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Delivery>().ToTable("Delivery");
        modelBuilder.Entity<Delivery>().HasKey(d => d.Id);

        modelBuilder.Entity<Delivery>().Property(d => d.LoadType)
            .IsRequired()
            .HasMaxLength(50);

        modelBuilder.Entity<Delivery>().Property(d => d.Urgency)
            .IsRequired()
            .HasMaxLength(20);

        modelBuilder.Entity<Delivery>().Property(d => d.Pricing)
            .HasColumnType("decimal(18,2)");

        modelBuilder.Entity<Delivery>().Property(d => d.HasArrears)
            .IsRequired();

        modelBuilder.Entity<Delivery>().Property(d => d.PickupLocation)
            .IsRequired()
            .HasMaxLength(255);

        modelBuilder.Entity<Delivery>().Property(d => d.DeliveryLocation)
            .IsRequired()
            .HasMaxLength(255);

        modelBuilder.Entity<Delivery>().Property(d => d.ScheduledDate)
            .IsRequired();

        modelBuilder.Entity<TrafficConditions>().HasKey(tc => tc.TrafficId);

        modelBuilder.Entity<TypeOfGoods>()
        .HasKey(t => t.GoodsId); // Specify the primary key

        modelBuilder.Entity<WeatherConditions>()
      .HasKey(wc => wc.WeatherId); // Specify the primary key property

        // Relationships
        modelBuilder.Entity<Delivery>()
            .HasOne(d => d.Client)
            .WithMany(c => c.Deliveries)
            .HasForeignKey(d => d.ClientId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Delivery>()
            .HasOne(d => d.LogisticsRoute)
            .WithOne(lr => lr.Delivery)
            .HasForeignKey<LogisticsRoute>(lr => lr.DeliveryId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Delivery>()
            .HasMany(d => d.WeatherConditions)
            .WithOne(wc => wc.Delivery)
            .HasForeignKey(wc => wc.DeliveryId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Delivery>()
            .HasMany(d => d.TrafficConditions)
            .WithOne(tc => tc.Delivery)
            .HasForeignKey(tc => tc.DeliveryId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<TrafficConditions>()
            .HasOne(tc => tc.LogisticsRoute)
            .WithMany(lr => lr.TrafficConditions)
            .HasForeignKey(tc => tc.LogisticsRouteId);

        modelBuilder.Entity<Delivery>()
       .HasOne(d => d.Driver)
       .WithMany(d => d.Deliveries)
       .HasForeignKey(d => d.DriverId);

    }
}
