﻿using LogisticsTrackingAPI.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class DriverPerformanceService
    {
        private readonly DriverPerformanceResource _resource;

        public DriverPerformanceService(DriverPerformanceResource resource)
        {
            _resource = resource ?? throw new ArgumentNullException(nameof(resource));
        }

        // Get all driver performances
        public async Task<List<DriverPerformanceDto>> GetAllAsync()
        {
            var performances = await _resource.GetAllAsync();
            return performances.ConvertAll(MapToDto);
        }

        // Get driver performance by ID
        public async Task<DriverPerformanceDto> GetByIdAsync(int id)
        {
            var performance = await _resource.GetByIdAsync(id);
            if (performance == null) throw new KeyNotFoundException("Driver Performance not found");

            return MapToDto(performance);
        }

        // Get performances by driver ID
        public async Task<List<DriverPerformanceDto>> GetByDriverIdAsync(int driverId)
        {
            var performances = await _resource.GetByDriverIdAsync(driverId);
            return performances.ConvertAll(MapToDto);
        }

        // Add a new driver performance
        public async Task<int> AddAsync(DriverPerformanceDto dto)
        {
            ValidateDriverPerformanceDto(dto);

            if (await _resource.ExistsAsync(dto.DriverId, dto.DeliveryId))
                throw new InvalidOperationException("Driver performance for this delivery already exists.");

            var performance = MapToEntity(dto);
            await _resource.AddAsync(performance);
            return performance.Id;
        }

        // Update an existing driver performance
        public async Task<bool> UpdateAsync(int id, DriverPerformanceDto dto)
        {
            ValidateDriverPerformanceDto(dto);

            var existingPerformance = await _resource.GetByIdAsync(id);
            if (existingPerformance == null) return false;

            // Update fields
            existingPerformance.MilesDriven = dto.MilesDriven;
            existingPerformance.FuelConsumed = dto.FuelConsumed;
            existingPerformance.TimeTaken = dto.TimeTaken;
            existingPerformance.PerformanceRating = dto.PerformanceRating;

            await _resource.UpdateAsync(existingPerformance);
            return true;
        }

        // Save or update a performance record
        public async Task SaveOrUpdateAsync(DriverPerformance performance)
        {
            var existingPerformance = await _resource.GetByDriverAndDeliveryAsync(performance.DriverId, performance.DeliveryId);

            if (existingPerformance == null)
            {
                // Add a new record
                await _resource.AddAsync(performance);
            }
            else
            {
                // Update the existing record
                existingPerformance.MilesDriven = performance.MilesDriven;
                existingPerformance.FuelConsumed = performance.FuelConsumed;
                existingPerformance.TimeTaken = performance.TimeTaken;
                existingPerformance.PerformanceRating = performance.PerformanceRating;

                await _resource.UpdateAsync(existingPerformance);
            }
        }

        //// Update driver performance for an incident
        //public async Task<DriverPerformanceDto> UpdatePerformanceForIncidentAsync(int driverId, IncidentReportDto incident)
        //{
        //    var performance = await _resource.GetByDriverAndDeliveryAsync(driverId, incident.DeliveryId);

        //    if (performance == null)
        //    {
        //        performance = new DriverPerformance
        //        {
        //            DriverId = driverId,
        //            DeliveryId = incident.DeliveryId,
        //            MilesDriven = 0,
        //            FuelConsumed = 0,
        //            TimeTaken = TimeSpan.Zero,
        //            PerformanceRating = "Average"
        //        };

        //        await _resource.AddAsync(performance);
        //    }
        //    else
        //    {
        //        switch (incident.Severity.ToLower())
        //        {
        //            case "high":
        //                performance.PerformanceRating = "Poor";
        //                break;
        //            case "medium":
        //                performance.PerformanceRating = "Average";
        //                break;
        //            case "low":
        //                performance.PerformanceRating = "Good";
        //                break;
        //            default:
        //                throw new ArgumentException("Invalid incident severity level.");
        //        }

        //        await _resource.UpdateAsync(performance);
        //    }

        //    return MapToDto(performance);
        //}

        // Get top-performing drivers
        public async Task<List<DriverPerformanceDto>> GetTopPerformingDriversAsync(int count)
        {
            var performances = await _resource.GetTopPerformingDriversAsync(count);
            return performances.ConvertAll(MapToDto);
        }

        // Get by driver and delivery
        public async Task<DriverPerformanceDto> GetByDriverAndDeliveryAsync(int driverId, int deliveryId)
        {
            var performance = await _resource.GetByDriverAndDeliveryAsync(driverId, deliveryId);
            return performance != null ? MapToDto(performance) : null;
        }

        // Map from entity to DTO
        private DriverPerformanceDto MapToDto(DriverPerformance performance)
        {
            return new DriverPerformanceDto
            {
                Id = performance.Id,
                DriverId = performance.DriverId,
                DeliveryId = performance.DeliveryId,
                MilesDriven = performance.MilesDriven,
                FuelConsumed = performance.FuelConsumed,
                TimeTaken = performance.TimeTaken,
                PerformanceRating = performance.PerformanceRating
            };
        }

        // Map from DTO to entity
        private DriverPerformance MapToEntity(DriverPerformanceDto dto)
        {
            return new DriverPerformance
            {
                DriverId = dto.DriverId,
                DeliveryId = dto.DeliveryId,
                MilesDriven = dto.MilesDriven,
                FuelConsumed = dto.FuelConsumed,
                TimeTaken = dto.TimeTaken,
                PerformanceRating = dto.PerformanceRating
            };
        }

        // Validate the DriverPerformanceDto
        private void ValidateDriverPerformanceDto(DriverPerformanceDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));
            if (dto.DriverId <= 0) throw new ArgumentException("Invalid DriverId");
            if (dto.DeliveryId <= 0) throw new ArgumentException("Invalid DeliveryId");
        }
    }
}
