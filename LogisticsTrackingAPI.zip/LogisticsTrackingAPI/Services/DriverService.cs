﻿using LogisticsTrackingAPI.ResourceAccess;

public class DriverService
{
    private readonly DriverResource _driverResource;
    private readonly ISharedDeliveryService _sharedDeliveryService;

    public DriverService(DriverResource driverResource, ISharedDeliveryService sharedDeliveryService)
    {
        _driverResource = driverResource ?? throw new ArgumentNullException(nameof(driverResource));
        _sharedDeliveryService = sharedDeliveryService ?? throw new ArgumentNullException(nameof(sharedDeliveryService));
    }

    public async Task<DriverDto> GetByIdAsync(int driverId)
    {
        var driver = await _driverResource.GetByIdAsync(driverId);
        if (driver == null) throw new KeyNotFoundException("Driver not found");
        return MapToDto(driver);
    }

    public async Task<List<DriverDto>> GetAvailableDriversForDeliveryAsync(int deliveryId)
    {
        var delivery = await _sharedDeliveryService.GetDeliveryByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

        var drivers = await _driverResource.GetAllAsync();
        return drivers
            .Where(d => d.SkillLevel >= delivery.RiskLevel)
            .Select(MapToDto)
            .ToList();
    }

    private DriverDto MapToDto(Driver driver)
    {
        return new DriverDto
        {
            Id = driver.Id,
            Name = driver.Name,
            LicenseNumber = driver.LicenseNumber,
            PhoneNumber = driver.PhoneNumber,
            SkillLevel = driver.SkillLevel,
            Experience = driver.Experience,
            CurrentRating = driver.CurrentRating
        };
    }
}
