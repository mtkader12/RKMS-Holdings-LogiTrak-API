﻿using LogisticsTrackingAPI.ResourceAccess;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class TrafficConditionsService
    {
        private readonly TrafficConditionsResource _resource;
        private readonly IMemoryCache _cache;
        private readonly HttpClient _httpClient;
        private const string HereMapsApiKey = "YOUR_API_KEY"; // Replace with your actual HERE Maps API key

        public TrafficConditionsService(TrafficConditionsResource resource, IMemoryCache cache, HttpClient httpClient)
        {
            _resource = resource;
            _cache = cache;
            _httpClient = httpClient;
        }

        // Get all traffic conditions
        public async Task<List<TrafficConditionsDto>> GetAllAsync()
        {
            var conditions = await _resource.GetAllAsync();
            return conditions.ConvertAll(tc => new TrafficConditionsDto
            {
                TrafficId = tc.TrafficId,
                VehicleId = tc.VehicleId,
                Condition = tc.Condition,
                Timestamp = tc.Timestamp,
                Location = tc.Location,
                Severity = tc.Severity,
                VehicleRegistration = tc.Vehicle.RegistrationNumber
            });
        }

        // Get traffic condition by ID
        public async Task<TrafficConditionsDto> GetByIdAsync(int id)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null) throw new KeyNotFoundException("Traffic condition not found");

            return new TrafficConditionsDto
            {
                TrafficId = condition.TrafficId,
                VehicleId = condition.VehicleId,
                Condition = condition.Condition,
                Timestamp = condition.Timestamp,
                Location = condition.Location,
                Severity = condition.Severity,
                VehicleRegistration = condition.Vehicle.RegistrationNumber
            };
        }

        // Add a new traffic condition
        public async Task<int> AddAsync(TrafficConditionsDto dto)
        {
            if (!await _resource.VehicleExistsAsync(dto.VehicleId))
                throw new KeyNotFoundException("Vehicle not found");

            var condition = new TrafficConditions
            {
                VehicleId = dto.VehicleId,
                Condition = dto.Condition,
                Timestamp = dto.Timestamp,
                Location = dto.Location,
                Severity = dto.Severity
            };

            var addedConditionId = await _resource.AddAsync(condition);

            return addedConditionId;
        }

        // Add traffic conditions from API to the database
        public async Task AddTrafficConditionsFromApiAsync(string pickupLocation, string deliveryLocation)
        {
            var trafficConditions = await GetTrafficConditionsFromApiAsync(pickupLocation, deliveryLocation);

            // Convert to TrafficConditions model
            var conditionsToSave = trafficConditions.ConvertAll(tc => new TrafficConditions
            {
                Location = tc.Location,
                Condition = tc.Condition,
                Severity = tc.Severity,
                Timestamp = tc.Timestamp
            });

            // Save traffic conditions to the database
            await _resource.AddRangeAsync(conditionsToSave);
        }

        // Update an existing traffic condition
        public async Task<bool> UpdateAsync(int id, TrafficConditionsDto dto)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null) return false;

            condition.VehicleId = dto.VehicleId;
            condition.Condition = dto.Condition;
            condition.Timestamp = dto.Timestamp;
            condition.Location = dto.Location;
            condition.Severity = dto.Severity;

            var updatedRows = await _resource.UpdateAsync(condition);
            return updatedRows > 0;
        }

        // Delete a traffic condition
        public async Task<bool> DeleteAsync(int id)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null)
            {
                throw new KeyNotFoundException("Traffic condition not found");
            }

            try
            {
                await _resource.DeleteAsync(condition);
                return true;
            }
            catch
            {
                return false;
            }
        }

        // Fetch traffic conditions from HERE Maps API
        public async Task<List<TrafficConditionsDto>> GetTrafficConditionsFromApiAsync(string pickupLocation, string deliveryLocation)
        {
            var cacheKey = $"TrafficConditions_{pickupLocation}_{deliveryLocation}";
            if (!_cache.TryGetValue(cacheKey, out List<TrafficConditionsDto> cachedData))
            {
                var apiUrl = $"https://traffic.ls.hereapi.com/traffic/6.3/incidents.json" +
                             $"?bbox={pickupLocation};{deliveryLocation}" +
                             $"&apiKey={HereMapsApiKey}";

                var response = await _httpClient.GetAsync(apiUrl);
                if (!response.IsSuccessStatusCode)
                {
                    throw new HttpRequestException($"Failed to fetch traffic data: {response.StatusCode}");
                }

                var content = await response.Content.ReadAsStringAsync();
                var apiResponse = JsonSerializer.Deserialize<HereTrafficApiResponse>(content);

                cachedData = apiResponse?.Incidents.ConvertAll(incident => new TrafficConditionsDto
                {
                    Location = $"{incident.Position.Latitude},{incident.Position.Longitude}",
                    Condition = incident.Description,
                    Severity = incident.Severity,
                    Timestamp = DateTime.UtcNow
                }) ?? new List<TrafficConditionsDto>();

                _cache.Set(cacheKey, cachedData, TimeSpan.FromMinutes(15));
            }

            return cachedData;
        }
    }

    // Models for HERE Maps API Response
    public class HereTrafficApiResponse
    {
        public List<TrafficIncident> Incidents { get; set; }
    }

    public class TrafficIncident
    {
        public string Description { get; set; }
        public int Severity { get; set; }
        public Position Position { get; set; }
    }

    public class Position
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
