﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class HistoricalDeliveryDataService
    {
        private readonly HistoricalDeliveryDataResource _resource;

        public HistoricalDeliveryDataService(HistoricalDeliveryDataResource resource)
        {
            _resource = resource;
        }

        // Get all historical delivery data
        public async Task<List<HistoricalDeliveryDataDto>> GetAllAsync()
        {
            var historicalData = await _resource.GetAllAsync();
            return historicalData.ConvertAll(data => new HistoricalDeliveryDataDto
            {
                DeliveryId = data.DeliveryId,
                VehicleId = data.VehicleId,
                DriverId = data.DriverId,
                DeliveryTime = data.DeliveryTime,
                Delays = data.Delays,
                DistanceTraveled = data.DistanceTraveled,
                VehicleRegistration = data.Vehicle.RegistrationNumber,
                DriverName = data.Driver.Name,
                DeliveryDetails = $"{data.Delivery.PickupLocation} -> {data.Delivery.DeliveryLocation} ({data.Delivery.ScheduledDate:yyyy-MM-dd})"
            });
        }

        // Get historical data by delivery ID
        public async Task<HistoricalDeliveryDataDto> GetByDeliveryIdAsync(int deliveryId)
        {
            var data = await _resource.GetByDeliveryIdAsync(deliveryId);
            if (data == null) throw new KeyNotFoundException("Historical Delivery Data not found");

            return new HistoricalDeliveryDataDto
            {
                DeliveryId = data.DeliveryId,
                VehicleId = data.VehicleId,
                DriverId = data.DriverId,
                DeliveryTime = data.DeliveryTime,
                Delays = data.Delays,
                DistanceTraveled = data.DistanceTraveled,
                VehicleRegistration = data.Vehicle.RegistrationNumber,
                DriverName = data.Driver.Name,
                DeliveryDetails = $"{data.Delivery.PickupLocation} -> {data.Delivery.DeliveryLocation} ({data.Delivery.ScheduledDate:yyyy-MM-dd})"
            };
        }

        // Add new historical data 
        public async Task<int> AddAsync(HistoricalDeliveryDataDto dto)
        {
            // Validate related entities
            if (!await _resource.VehicleExistsAsync(dto.VehicleId))
                throw new KeyNotFoundException("Vehicle not found");
            if (!await _resource.DriverExistsAsync(dto.DriverId))
                throw new KeyNotFoundException("Driver not found");
            if (!await _resource.DeliveryExistsAsync(dto.DeliveryId))
                throw new KeyNotFoundException("Delivery not found");

            // Check for duplicate historical data
            if (await _resource.ExistsAsync(dto.DeliveryId))
                throw new InvalidOperationException("Historical data for this delivery already exists.");

            // Create a new historical delivery data record
            var data = new HistoricalDeliveryData
            {
                DeliveryId = dto.DeliveryId,
                VehicleId = dto.VehicleId,
                DriverId = dto.DriverId,
                DeliveryTime = dto.DeliveryTime,
                Delays = dto.Delays,
                DistanceTraveled = dto.DistanceTraveled,
                TrafficConditionsSummary = dto.TrafficConditionsSummary, // New field
                WeatherConditionsSummary = dto.WeatherConditionsSummary  // New field
            };

            await _resource.AddAsync(data);
            return data.DeliveryId;
        }

        public async Task<bool> UpdateAsync(int deliveryId, HistoricalDeliveryDataDto dto)
        {
            // Retrieve existing historical delivery data
            var data = await _resource.GetByDeliveryIdAsync(deliveryId);
            if (data == null)
                throw new KeyNotFoundException("Historical Delivery Data not found");

            // Update DeliveryTime, Delays, and DistanceTraveled fields
            data.DeliveryTime = dto.DeliveryTime;
            data.Delays = dto.Delays;
            data.DistanceTraveled = dto.DistanceTraveled;

            // Validate and update VehicleId if it has changed
            if (dto.VehicleId != data.VehicleId)
            {
                if (!await _resource.VehicleExistsAsync(dto.VehicleId))
                    throw new KeyNotFoundException("Vehicle not found");
                data.VehicleId = dto.VehicleId;
            }

            // Validate and update DriverId if it has changed
            if (dto.DriverId != data.DriverId)
            {
                if (!await _resource.DriverExistsAsync(dto.DriverId))
                    throw new KeyNotFoundException("Driver not found");
                data.DriverId = dto.DriverId;
            }

            // Update the historical data in the database
            await _resource.UpdateAsync(data);

            // Return true to indicate successful update
            return true;
        }

        // Delete historical data
        public async Task<bool> DeleteAsync(int deliveryId)
        {
            // Retrieve existing historical delivery data
            var data = await _resource.GetByDeliveryIdAsync(deliveryId);
            if (data == null)
                return false; // Return false if the record doesn't exist

            // Delete the historical delivery data
            await _resource.DeleteAsync(data);

            // Return true to indicate successful deletion
            return true;
        }

    }
}
