﻿using LogisticsTrackingAPI.ResourceAccess;

public class RealTimeUpdatesService
{
    private readonly RealTimeUpdatesResource _updatesResource;
    private readonly TrailerResource _trailerResource;

    public RealTimeUpdatesService(RealTimeUpdatesResource updatesResource, TrailerResource trailerResource)
    {
        _updatesResource = updatesResource ?? throw new ArgumentNullException(nameof(updatesResource));
        _trailerResource = trailerResource ?? throw new ArgumentNullException(nameof(trailerResource));
    }

    public async Task<List<RealTimeUpdatesDto>> GetTrailerUpdatesAsync(int trailerId)
    {
        var trailer = await _trailerResource.GetByIdAsync(trailerId);
        if (trailer == null) throw new KeyNotFoundException("Trailer not found");

        if (!trailer.VehicleId.HasValue) throw new InvalidOperationException("Trailer does not have a VehicleId");

        var updates = await _updatesResource.GetUpdatesByVehicleIdAsync(trailer.VehicleId.Value);
        return updates.Select(update => new RealTimeUpdatesDto
        {
            Id = update.Id,
            VehicleId = update.VehicleId,
            Timestamp = update.Timestamp,
            Latitude = update.Latitude,
            Longitude = update.Longitude,
            Speed = update.Speed
        }).ToList();
    }
}
