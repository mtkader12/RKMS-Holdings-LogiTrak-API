﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class AccessLevelServices
    {
        private readonly AccessLevelResource _resource;

        public AccessLevelServices(AccessLevelResource resource)
        {
            _resource = resource;
        }

        // Get all access levels
        public async Task<List<AccessLevelDto>> GetAllAsync()
        {
            var accessLevels = await _resource.GetAllAsync();
            return accessLevels.ConvertAll(al => new AccessLevelDto
            {
                AccessLevelId = al.AccessLevelId,
                AccessLevelName = al.AccessLevelName,
                Permissions = al.Permissions
            });
        }

        // Get access level by ID
        public async Task<AccessLevelDto> GetByIdAsync(int id)
        {
            var accessLevel = await _resource.GetByIdAsync(id);
            if (accessLevel == null) throw new KeyNotFoundException("Access Level not found");

            return new AccessLevelDto
            {
                AccessLevelId = accessLevel.AccessLevelId,
                AccessLevelName = accessLevel.AccessLevelName,
                Permissions = accessLevel.Permissions
            };
        }

        // Add a new access level
        public async Task<int> AddAsync(AccessLevelDto dto)
        {
            var accessLevel = new AccessLevel
            {
                AccessLevelName = dto.AccessLevelName,
                Permissions = dto.Permissions
            };

            await _resource.AddAsync(accessLevel);

            // Assuming the _resource.AddAsync method sets the AccessLevelId after adding the entity to the database
            return accessLevel.AccessLevelId;
        }

        // Update an existing access level
        public async Task<bool> UpdateAsync(int id, AccessLevelDto dto)
        {
            var accessLevel = await _resource.GetByIdAsync(id);
            if (accessLevel == null) return false; // Return false if Access Level is not found

            accessLevel.AccessLevelName = dto.AccessLevelName;
            accessLevel.Permissions = dto.Permissions;

            await _resource.UpdateAsync(accessLevel); // Perform the update operation
            return true; // Return true to indicate success
        }


        // Delete an access level
        public async Task<bool> DeleteAsync(int id)
        {
            var accessLevel = await _resource.GetByIdAsync(id);
            if (accessLevel == null) return false; // Return false if the Access Level is not found

            await _resource.DeleteAsync(accessLevel); // Perform the delete operation
            return true; // Return true to indicate successful deletion
        }
    }
}
