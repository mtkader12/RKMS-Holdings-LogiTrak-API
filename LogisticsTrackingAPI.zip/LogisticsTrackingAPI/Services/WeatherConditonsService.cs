﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class WeatherConditionsService
    {
        private readonly WeatherConditionsResource _resource;

        public WeatherConditionsService(WeatherConditionsResource resource)
        {
            _resource = resource;
        }

        // Get all weather conditions
        public async Task<List<WeatherConditionsDto>> GetAllAsync()
        {
            var conditions = await _resource.GetAllAsync();
            return conditions.ConvertAll(wc => new WeatherConditionsDto
            {
                WeatherId = wc.WeatherId,
                VehicleId = wc.VehicleId,
                Condition = wc.Condition,
                Temperature = wc.Temperature,
                Humidity = wc.Humidity,
                Timestamp = wc.Timestamp,
                VehicleRegistration = wc.Vehicle?.RegistrationNumber
            });
        }

        // Get weather condition by ID
        public async Task<WeatherConditionsDto> GetByIdAsync(int id)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null) throw new KeyNotFoundException("Weather condition not found");

            return new WeatherConditionsDto
            {
                WeatherId = condition.WeatherId,
                VehicleId = condition.VehicleId,
                Condition = condition.Condition,
                Temperature = condition.Temperature,
                Humidity = condition.Humidity,
                Timestamp = condition.Timestamp,
                VehicleRegistration = condition.Vehicle?.RegistrationNumber
            };
        }

        // Add a new weather condition
        public async Task<int> AddAsync(WeatherConditionsDto dto)
        {
            // Validate that the associated vehicle exists if VehicleId is provided
            if (dto.VehicleId != 0 && !await _resource.VehicleExistsAsync(dto.VehicleId))
                throw new KeyNotFoundException("Vehicle not found");

            // Create a new WeatherConditions entity
            var condition = new WeatherConditions
            {
                VehicleId = dto.VehicleId,
                Condition = dto.Condition,
                Temperature = dto.Temperature,
                Humidity = dto.Humidity,
                Timestamp = dto.Timestamp
            };

            // Add the new weather condition to the database
            await _resource.AddAsync(condition);

            // Return the ID of the newly added record
            return condition.WeatherId;
        }


        // Update an existing weather condition
        public async Task<bool> UpdateAsync(int id, WeatherConditionsDto dto)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null) return false;

            condition.Condition = dto.Condition;
            condition.Temperature = dto.Temperature;
            condition.Humidity = dto.Humidity;
            condition.Timestamp = dto.Timestamp;

            if (dto.VehicleId != condition.VehicleId)
            {
                if (dto.VehicleId != 0 && !await _resource.VehicleExistsAsync(dto.VehicleId))
                    throw new KeyNotFoundException("Vehicle not found");
                condition.VehicleId = dto.VehicleId;
            }

            await _resource.UpdateAsync(condition);
            return true;
        }

        // Delete a weather condition
        public async Task<bool> DeleteAsync(int id)
        {
            var condition = await _resource.GetByIdAsync(id);
            if (condition == null) return false;

            await _resource.DeleteAsync(condition);
            return true;
        }
    }
}
