﻿using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

public class NotificationService
{
    private readonly string _accountSid;
    private readonly string _authToken;
    private readonly string _fromPhoneNumber;

    public NotificationService(string accountSid, string authToken, string fromPhoneNumber)
    {
        _accountSid = accountSid;
        _authToken = authToken;
        _fromPhoneNumber = fromPhoneNumber;

        TwilioClient.Init(_accountSid, _authToken);
    }

    /// <summary>
    /// Sends a WhatsApp message using Twilio.
    /// </summary>
    /// <param name="toPhoneNumber">Recipient's phone number in E.164 format.</param>
    /// <param name="message">Message content to send.</param>
    /// <returns>The status of the message.</returns>
    public async Task<string> SendWhatsAppMessageAsync(string toPhoneNumber, string message)
    {
        try
        {
            var messageResource = await MessageResource.CreateAsync(
                body: message,
                from: new PhoneNumber($"whatsapp:{_fromPhoneNumber}"),
                to: new PhoneNumber($"whatsapp:{toPhoneNumber}")
            );

            return messageResource.Status.ToString();
        }
        catch (Exception ex)
        {
            // Log the error
            Console.WriteLine($"Error sending WhatsApp message: {ex.Message}");
            return "Failed";
        }
    }
}
