﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class CompanyService
    {
        private readonly CompanyResource _resource;

        public CompanyService(CompanyResource resource)
        {
            _resource = resource;
        }

        // Get all companies
        public async Task<List<CompanyDto>> GetAllAsync()
        {
            var companies = await _resource.GetAllAsync();
            return companies.ConvertAll(company => new CompanyDto
            {
                Id = company.Id,
                Name = company.Name,
                Address = company.Address,
                ContactDetails = company.ContactDetails
            });
        }

        // Get a company by ID
        public async Task<CompanyDto> GetByIdAsync(int id)
        {
            var company = await _resource.GetByIdAsync(id);
            if (company == null) throw new KeyNotFoundException("Company not found");

            return new CompanyDto
            {
                Id = company.Id,
                Name = company.Name,
                Address = company.Address,
                ContactDetails = company.ContactDetails
            };
        }

        // Add a new company
        public async Task<int> AddAsync(CompanyDto dto)
        {
            var company = new Company
            {
                Name = dto.Name,
                Address = dto.Address,
                Email = dto.Email,
                ContactDetails = dto.ContactDetails,
                //AccountType = dto.AccountType
            };

            await _resource.AddAsync(company);

            // Return the ID of the newly created company
            return company.Id;
        }
        // Update an existing company
        public async Task<bool> UpdateAsync(int id, CompanyDto dto)
        {
            // Fetch the company by its ID
            var company = await _resource.GetByIdAsync(id);
            if (company == null)
                return false; // Return false if the company does not exist

            // Update the company fields with the data from the DTO
            company.Name = dto.Name ?? company.Name; // Ensure we don't overwrite with null values
            company.Address = dto.Address ?? company.Address;
            company.ContactDetails = dto.ContactDetails ?? company.ContactDetails;

            // Persist the changes using the resource layer
            await _resource.UpdateAsync(company);
            return true; // Return true to indicate a successful update
        }


        // Delete a company
        public async Task<bool> DeleteAsync(int id)
        {
            var company = await _resource.GetByIdAsync(id);
            if (company == null) return false;

            await _resource.DeleteAsync(company);
            return true;
        }

        public async Task<bool> ExistsAsync(string companyName, string email)
        {
            return await _resource.ExistsAsync(companyName, email);
        }

    }
}
