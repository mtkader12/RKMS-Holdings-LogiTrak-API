﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class VehicleService
    {
        private readonly VehicleResource _resource;
        private readonly TrailerService _trailerService; // Injecting TrailerService
        public VehicleService(VehicleResource resource, TrailerService trailerService)
        {
            _resource = resource;
            _trailerService = trailerService ?? throw new ArgumentNullException(nameof(trailerService));
        }

        // Get all vehicles
        public async Task<List<VehicleDto>> GetAllAsync()
        {
            var vehicles = await _resource.GetAllAsync();
            return vehicles.ConvertAll(vehicle => new VehicleDto
            {
                Id = vehicle.Id,
                RegistrationNumber = vehicle.RegistrationNumber,
                Make = vehicle.Make,
                Model = vehicle.Model,
                Status = vehicle.Status
            });
        }

        // Get vehicle by ID
        public async Task<VehicleDto> GetByIdAsync(int id)
        {
            var vehicle = await _resource.GetByIdAsync(id);
            if (vehicle == null) throw new KeyNotFoundException("Vehicle not found");

            return new VehicleDto
            {
                Id = vehicle.Id,
                RegistrationNumber = vehicle.RegistrationNumber,
                Make = vehicle.Make,
                Model = vehicle.Model,
                Status = vehicle.Status
            };
        }

        // Add a new vehicle
        public async Task AddAsync(VehicleDto dto)
        {
            if (await _resource.ExistsAsync(dto.RegistrationNumber))
                throw new InvalidOperationException("A vehicle with the same registration number already exists.");

            var vehicle = new Vehicle
            {
                RegistrationNumber = dto.RegistrationNumber,
                Make = dto.Make,
                Model = dto.Model,
                Status = dto.Status
            };

            await _resource.AddAsync(vehicle);
        }

        // Update an existing vehicle
        public async Task UpdateAsync(int id, VehicleDto dto)
        {
            var vehicle = await _resource.GetByIdAsync(id);
            if (vehicle == null) throw new KeyNotFoundException("Vehicle not found");

            if (await _resource.ExistsAsync(dto.RegistrationNumber, id))
                throw new InvalidOperationException("Another vehicle with the same registration number already exists.");

            vehicle.RegistrationNumber = dto.RegistrationNumber;
            vehicle.Make = dto.Make;
            vehicle.Model = dto.Model;
            vehicle.Status = dto.Status;

            await _resource.UpdateAsync(vehicle);
        }

        // Delete a vehicle
        public async Task DeleteAsync(int id)
        {
            var vehicle = await _resource.GetByIdAsync(id);
            if (vehicle == null) throw new KeyNotFoundException("Vehicle not found");

            await _resource.DeleteAsync(vehicle);
        }

        public async Task LinkVehicleToTrailerAsync(int vehicleId, int trailerId)
        {
            // Get the vehicle by ID
            var vehicle = await _resource.GetByIdAsync(vehicleId);
            if (vehicle == null)
                throw new KeyNotFoundException("Vehicle not found");

            // Get the trailer by ID
            var trailer = await _trailerService.GetByIdAsync(trailerId);
            if (trailer == null)
                throw new KeyNotFoundException("Trailer not found");

            // Update the trailer's vehicle link and status
            trailer.VehicleId = vehicleId;
            trailer.Status = "Linked";

            // Map the trailer entity to TrailerDto
            var trailerDto = new TrailerDto
            {
                TrailerId = trailer.TrailerId,
                ClientId = trailer.ClientId,
                DeliveryId = trailer.DeliveryId,
                Type = trailer.Type,
                Capacity = trailer.Capacity,
                VehicleId = trailer.VehicleId,
                Status = trailer.Status
            };

            // Update the trailer using the TrailerService
            await _trailerService.UpdateAsync(trailer.TrailerId, trailerDto);
        }


    }
}
