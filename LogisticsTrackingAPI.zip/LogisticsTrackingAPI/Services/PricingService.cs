﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class PricingService
    {
        private readonly PricingResource _resource;

        public PricingService(PricingResource resource)
        {
            _resource = resource;
        }

        // Get all pricing data
        public async Task<List<PricingDto>> GetAllAsync()
        {
            var pricings = await _resource.GetAllAsync();
            return pricings.ConvertAll(pricing => new PricingDto
            {
                Id = pricing.Id,
                TrailerType = pricing.TrailerType,
                DistanceRate = pricing.DistanceRate,
                LoadRate = pricing.LoadRate,
                ContractRate = pricing.ContractRate
            });
        }

        // Get pricing data by ID
        public async Task<PricingDto> GetByIdAsync(int id)
        {
            var pricing = await _resource.GetByIdAsync(id);
            if (pricing == null) throw new KeyNotFoundException("Pricing not found");

            return new PricingDto
            {
                Id = pricing.Id,
                TrailerType = pricing.TrailerType,
                DistanceRate = pricing.DistanceRate,
                LoadRate = pricing.LoadRate,
                ContractRate = pricing.ContractRate
            };
        }

        // Add new pricing data
        public async Task<int> AddAsync(PricingDto dto)
        {
            var pricing = new Pricing
            {
                TrailerType = dto.TrailerType,
                DistanceRate = dto.DistanceRate,
                LoadRate = dto.LoadRate,
                ContractRate = dto.ContractRate
            };

            // Add the pricing record to the database
            await _resource.AddAsync(pricing);

            // Return the ID of the newly added pricing record
            return pricing.Id; // Ensure `Id` is the primary key and is set after saving.
        }


        // Update existing pricing data
        public async Task<bool> UpdateAsync(int id, PricingDto dto)
        {
            // Fetch the existing pricing record
            var pricing = await _resource.GetByIdAsync(id);
            if (pricing == null)
                throw new KeyNotFoundException("Pricing not found");

            // Update the pricing properties
            pricing.TrailerType = dto.TrailerType;
            pricing.DistanceRate = dto.DistanceRate;
            pricing.LoadRate = dto.LoadRate;
            pricing.ContractRate = dto.ContractRate;

            // Perform the update operation and check if the update succeeded
            var updateSucceeded = await _resource.UpdateAsync(pricing);
            return updateSucceeded;
        }


        // Delete pricing data
        public async Task<bool> DeleteAsync(int id)
        {
            // Fetch the pricing entity by ID
            var pricing = await _resource.GetByIdAsync(id);

            // If the entity is not found, return false
            if (pricing == null) return false;

            // Perform the deletion
            await _resource.DeleteAsync(pricing);

            // Assume the deletion is always successful if it reaches this point
            return true;
        }

    }
}
