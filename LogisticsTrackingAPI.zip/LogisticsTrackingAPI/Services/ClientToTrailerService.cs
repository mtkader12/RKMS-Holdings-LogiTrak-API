﻿using LogisticsTrackingAPI.ResourceAccess;

public class ClientToTrailerService
{
    private readonly ClientToTrailerResource _resource;
    private readonly TrailerResource _trailerResource;

    public ClientToTrailerService(ClientToTrailerResource resource, TrailerResource trailerResource)
    {
        _resource = resource ?? throw new ArgumentNullException(nameof(resource));
        _trailerResource = trailerResource ?? throw new ArgumentNullException(nameof(trailerResource));
    }

    public async Task<List<ClientToTrailerDto>> GetAllAsync()
    {
        var mappings = await _resource.GetAllAsync();
        return mappings.ConvertAll(mapping => new ClientToTrailerDto
        {
            ClientToTrailerId = mapping.ClientToTrailerId,
            TrailerId = mapping.TrailerId,
            ClientId = mapping.ClientId,
            GoodsDescription = mapping.GoodsDescription,
            DateAssigned = mapping.DateAssigned
        });
    }

    public async Task<ClientToTrailerDto> GetByIdAsync(int id)
    {
        var mapping = await _resource.GetByIdAsync(id);
        if (mapping == null) throw new KeyNotFoundException("Mapping not found");
        return new ClientToTrailerDto { ClientToTrailerId = mapping.ClientToTrailerId };
    }

    public async Task<int> AddAsync(ClientToTrailerDto mappingDto)
    {
        if (mappingDto == null) throw new ArgumentNullException(nameof(mappingDto));

        var mapping = new ClientToTrailer
        {
            TrailerId = mappingDto.TrailerId,
            ClientId = mappingDto.ClientId,
            GoodsDescription = mappingDto.GoodsDescription,
            DateAssigned = mappingDto.DateAssigned
        };

        await _resource.AddAsync(mapping);
        return mapping.ClientToTrailerId;
    }
}
