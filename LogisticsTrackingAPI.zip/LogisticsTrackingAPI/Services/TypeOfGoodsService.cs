﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class TypeOfGoodsService
    {
        private readonly TypeOfGoodsResource _resource;

        public TypeOfGoodsService(TypeOfGoodsResource resource)
        {
            _resource = resource;
        }

        // Get all types of goods
        public async Task<List<TypeOfGoodsDto>> GetAllAsync()
        {
            var goodsList = await _resource.GetAllAsync();
            return goodsList.ConvertAll(goods => new TypeOfGoodsDto
            {
                GoodsId = goods.GoodsId,
                TrailerId = goods.TrailerId ?? 0,
                GoodsType = goods.GoodsType,
                Timestamp = goods.Timestamp,
                GoodsName = goods.GoodsName,
                Category = goods.Category,
                HazardClass = goods.HazardClass,
                TrailerNumber = goods.Trailer?.TrailerNumber
            });
        }

        // Get type of goods by ID
        public async Task<TypeOfGoodsDto> GetByIdAsync(int id)
        {
            var goods = await _resource.GetByIdAsync(id);
            if (goods == null) throw new KeyNotFoundException("Type of goods not found");

            return new TypeOfGoodsDto
            {
                GoodsId = goods.GoodsId,
                TrailerId = goods.TrailerId ?? 0,
                GoodsType = goods.GoodsType,
                Timestamp = goods.Timestamp,
                GoodsName = goods.GoodsName,
                Category = goods.Category,
                HazardClass = goods.HazardClass,
                TrailerNumber = goods.Trailer?.TrailerNumber
            };
        }

        // Add a new type of goods
        public async Task<int> AddAsync(TypeOfGoodsDto dto)
        {
            if (dto.TrailerId.HasValue && !await _resource.TrailerExistsAsync(dto.TrailerId.Value))
                throw new KeyNotFoundException("Trailer not found");

            var goods = new TypeOfGoods
            {
                TrailerId = dto.TrailerId,
                GoodsType = dto.GoodsType,
                Timestamp = dto.Timestamp,
                GoodsName = dto.GoodsName,
                Category = dto.Category,
                HazardClass = dto.HazardClass
            };

            // Add the entity to the resource and get the ID
            var createdId = await _resource.AddAsync(goods);

            return createdId; // Return the ID of the newly added record
        }


        // Update an existing type of goods
        public async Task<bool> UpdateAsync(int id, TypeOfGoodsDto dto)
        {
            // Fetch the existing goods entity by ID
            var goods = await _resource.GetByIdAsync(id);
            if (goods == null)
                throw new KeyNotFoundException("Type of goods not found");

            // Validate and update properties
            goods.GoodsType = dto.GoodsType;
            goods.Timestamp = dto.Timestamp;
            goods.GoodsName = dto.GoodsName;
            goods.Category = dto.Category;
            goods.HazardClass = dto.HazardClass;

            // Handle trailer updates
            if (dto.TrailerId != goods.TrailerId)
            {
                if (dto.TrailerId.HasValue && !await _resource.TrailerExistsAsync(dto.TrailerId.Value))
                    throw new KeyNotFoundException("Trailer not found");
                goods.TrailerId = dto.TrailerId;
            }

            // Perform the update operation
            try
            {
                await _resource.UpdateAsync(goods);
                return true; // Indicate success
            }
            catch
            {
                return false; // Indicate failure in case of an exception
            }
        }


        // Delete a type of goods
        public async Task<bool> DeleteAsync(int id)
        {
            // Retrieve the record to be deleted
            var goods = await _resource.GetByIdAsync(id);
            if (goods == null)
                throw new KeyNotFoundException("Type of goods not found");

            try
            {
                // Attempt to delete the record
                await _resource.DeleteAsync(goods);
                return true; // Indicate success
            }
            catch
            {
                return false; // Indicate failure in case of an exception
            }
        }

    }
}
