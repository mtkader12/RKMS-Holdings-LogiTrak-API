﻿using LogisticsTrackingAPI.ResourceAccess;

public class TrailerService
{
    private readonly TrailerResource _trailerResource;
    private readonly ISharedDeliveryService _sharedDeliveryService;

    public TrailerService(TrailerResource trailerResource, ISharedDeliveryService sharedDeliveryService)
    {
        _trailerResource = trailerResource ?? throw new ArgumentNullException(nameof(trailerResource));
        _sharedDeliveryService = sharedDeliveryService ?? throw new ArgumentNullException(nameof(sharedDeliveryService));
    }

    public async Task<List<TrailerDto>> GetAllAsync()
    {
        var trailers = await _trailerResource.GetAllAsync();
        return trailers.ConvertAll(MapToDto);
    }

    public async Task<TrailerDto> GetByIdAsync(int id)
    {
        var trailer = await _trailerResource.GetByIdAsync(id);
        if (trailer == null) throw new KeyNotFoundException("Trailer not found");
        return MapToDto(trailer);
    }

    public async Task AssignTrailerToDeliveryAsync(int trailerId, int deliveryId)
    {
        var trailer = await _trailerResource.GetByIdAsync(trailerId);
        if (trailer == null) throw new KeyNotFoundException("Trailer not found");

        var delivery = await _sharedDeliveryService.GetDeliveryByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

        if (trailer.Status != "Available")
            throw new InvalidOperationException("Trailer is not available for assignment");

        delivery.TrailerId = trailerId;
        await _sharedDeliveryService.UpdateDeliveryAsync(deliveryId, delivery);
    }

    public async Task UpdateAsync(int trailerId, TrailerDto trailerDto)
    {
        if (trailerDto == null) throw new ArgumentNullException(nameof(trailerDto));

        var trailer = await _trailerResource.GetByIdAsync(trailerId);
        if (trailer == null) throw new KeyNotFoundException("Trailer not found");

        // Update trailer properties
        trailer.VehicleId = trailerDto.VehicleId;
        trailer.Status = trailerDto.Status;

        await _trailerResource.UpdateAsync(trailer); // Save changes to the database
    }
    private TrailerDto MapToDto(Trailer trailer)
    {
        return new TrailerDto
        {
            TrailerId = trailer.TrailerId,
            TrailerNumber = trailer.TrailerNumber,
            TrackerId = trailer.TrackerId,
            Capacity = trailer.Capacity,
            Type = trailer.Type,
            Status = trailer.Status,
            Location = trailer.Location,
            LastServiced = trailer.LastServiced
        };
    }
}
