﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class PaymentService
    {
        private readonly PaymentResource _resource;

        public PaymentService(PaymentResource resource)
        {
            _resource = resource;
        }

        // Get all payments
        public async Task<List<PaymentDto>> GetAllAsync()
        {
            var payments = await _resource.GetAllAsync();
            return payments.ConvertAll(payment => new PaymentDto
            {
                Id = payment.Id,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                Status = payment.Status
            });
        }

        // Get payment by ID
        public async Task<PaymentDto> GetByIdAsync(int id)
        {
            var payment = await _resource.GetByIdAsync(id);
            if (payment == null) throw new KeyNotFoundException("Payment not found");

            return new PaymentDto
            {
                Id = payment.Id,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                Status = payment.Status
            };
        }

        // Add a new payment
        public async Task AddAsync(PaymentDto dto)
        {
            var payment = new Payment
            {
                Amount = dto.Amount,
                PaymentDate = dto.PaymentDate,
                Status = dto.Status
            };

            await _resource.AddAsync(payment);
        }

        // Update an existing payment
        public async Task UpdateAsync(int id, PaymentDto dto)
        {
            var payment = await _resource.GetByIdAsync(id);
            if (payment == null) throw new KeyNotFoundException("Payment not found");

            payment.Amount = dto.Amount;
            payment.PaymentDate = dto.PaymentDate;
            payment.Status = dto.Status;

            await _resource.UpdateAsync(payment);
        }

        // Delete a payment
        public async Task DeleteAsync(int id)
        {
            var payment = await _resource.GetByIdAsync(id);
            if (payment == null) throw new KeyNotFoundException("Payment not found");

            await _resource.DeleteAsync(payment);
        }
        public async Task<bool> CheckArrearsAsync(int clientId)
        {
            // Logic to check if the client has arrears
            // For example, query the database or an external API
            bool hasArrears = await _resource.CheckClientArrearsAsync(clientId);
            return hasArrears;
        }

        public async Task<PaymentDto> GetByDeliveryIdAsync(int deliveryId)
        {
            var payment = await _resource.GetByDeliveryIdAsync(deliveryId);
            return payment != null ? new PaymentDto
            {
                Id = payment.Id,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                Status = payment.Status,
                ClientId = payment.ClientId
            } : null;
        }

    }
}
