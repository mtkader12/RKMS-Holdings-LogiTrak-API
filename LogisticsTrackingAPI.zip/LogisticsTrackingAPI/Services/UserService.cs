﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class UserService
    {
        private readonly UserResource _resource;

        public UserService(UserResource resource)
        {
            _resource = resource;
        }

        // Get all users
        public async Task<List<UserDto>> GetAllAsync()
        {
            var users = await _resource.GetAllAsync();
            return users.ConvertAll(user => new UserDto
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Role = user.Role,
                CompanyId = user.CompanyId,
                AccessLevelId = user.AccessLevelId,
                CompanyName = user.Company?.Name,
                AccessLevelName = user.AccessLevel?.AccessLevelName
            });
        }

        // Get user by ID
        public async Task<UserDto> GetByIdAsync(int id)
        {
            var user = await _resource.GetByIdAsync(id);
            if (user == null) throw new KeyNotFoundException("User not found");

            return new UserDto
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Role = user.Role,
                CompanyId = user.CompanyId,
                AccessLevelId = user.AccessLevelId,
                CompanyName = user.Company?.Name,
                AccessLevelName = user.AccessLevel?.AccessLevelName
            };
        }

        // Add a new user
        public async Task AddAsync(UserDto dto)
        {
            if (!await _resource.CompanyExistsAsync(dto.CompanyId))
                throw new KeyNotFoundException("Company not found");

            if (!await _resource.AccessLevelExistsAsync(dto.AccessLevelId))
                throw new KeyNotFoundException("Access Level not found");

            if (await _resource.ExistsAsync(dto.Username, dto.Email))
                throw new InvalidOperationException("A user with the same username or email already exists.");

            var user = new User
            {
                Username = dto.Username,
                Email = dto.Email,
                PasswordHash = HashPassword(dto.PasswordHash),
                PhoneNumber = dto.PhoneNumber,
                Role = dto.Role,
                CompanyId = dto.CompanyId,
                AccessLevelId = dto.AccessLevelId
            };

            await _resource.AddAsync(user);
        }

        // Update an existing user
        public async Task UpdateAsync(int id, UserDto dto)
        {
            var user = await _resource.GetByIdAsync(id);
            if (user == null) throw new KeyNotFoundException("User not found");

            if (await _resource.ExistsAsync(dto.Username, dto.Email, id))
                throw new InvalidOperationException("Another user with the same username or email already exists.");

            user.Username = dto.Username;
            user.Email = dto.Email;
            user.PhoneNumber = dto.PhoneNumber;
            user.Role = dto.Role;

            if (dto.CompanyId != user.CompanyId)
            {
                if (!await _resource.CompanyExistsAsync(dto.CompanyId))
                    throw new KeyNotFoundException("Company not found");
                user.CompanyId = dto.CompanyId;
            }

            if (dto.AccessLevelId != user.AccessLevelId)
            {
                if (!await _resource.AccessLevelExistsAsync(dto.AccessLevelId))
                    throw new KeyNotFoundException("Access Level not found");
                user.AccessLevelId = dto.AccessLevelId;
            }

            await _resource.UpdateAsync(user);
        }

        // Delete a user
        public async Task DeleteAsync(int id)
        {
            var user = await _resource.GetByIdAsync(id);
            if (user == null) throw new KeyNotFoundException("User not found");

            await _resource.DeleteAsync(user);
        }

        public async Task<List<UserDto>> GetUsersByCompanyIdAsync(int companyId)
        {
            return await _resource.GetUsersByCompanyIdAsync(companyId);
        }


        // Hash password (helper method)
        private string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }
    }
}
