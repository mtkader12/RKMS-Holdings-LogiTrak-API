﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class ClientService
    {
        private readonly ClientResource _resource;

        public ClientService(ClientResource resource)
        {
            _resource = resource;
        }

        // Get all clients
        public async Task<List<ClientDto>> GetAllAsync()
        {
            var clients = await _resource.GetAllAsync();
            return clients.ConvertAll(client => new ClientDto
            {
                Id = client.Id,
                CompanyId = client.CompanyId,
                Name = client.Name,
                Email = client.Email,
                PhoneNumber = client.PhoneNumber,
                CompanyName = client.Company.Name
            });
        }

        // Get client by ID
        public async Task<ClientDto> GetByIdAsync(int id)
        {
            var client = await _resource.GetByIdAsync(id);
            if (client == null) throw new KeyNotFoundException("Client not found");

            return new ClientDto
            {
                Id = client.Id,
                CompanyId = client.CompanyId,
                Name = client.Name,
                Email = client.Email,
                PhoneNumber = client.PhoneNumber,
                CompanyName = client.Company.Name
            };
        }

        // Add a new client
        public async Task<int> AddAsync(ClientDto dto)
        {
            // Check if the company exists
            if (!await _resource.CompanyExistsAsync(dto.CompanyId))
                throw new KeyNotFoundException("Company not found");

            // Check if a client with the same name or email already exists
            if (await _resource.ExistsAsync(dto.Name, dto.Email))
                throw new InvalidOperationException("A client with the same name or email already exists.");

            // Create the client entity
            var client = new Client
            {
                CompanyId = dto.CompanyId,
                Name = dto.Name,
                Email = dto.Email,
                PhoneNumber = dto.PhoneNumber
            };

            // Add the client entity to the database
            await _resource.AddAsync(client);

            // Return the ID of the newly created client
            return client.Id;
        }


        // Update an existing client
        public async Task<bool> UpdateAsync(int id, ClientDto dto)
        {
            var client = await _resource.GetByIdAsync(id);
            if (client == null) return false;

            client.Name = dto.Name;
            client.Email = dto.Email;
            client.PhoneNumber = dto.PhoneNumber;

            if (dto.CompanyId != client.CompanyId)
            {
                if (!await _resource.CompanyExistsAsync(dto.CompanyId))
                    throw new KeyNotFoundException("Company not found");
                client.CompanyId = dto.CompanyId;
            }

            await _resource.UpdateAsync(client);
            return true;
        }

        // Delete a client
        public async Task<bool> DeleteAsync(int id)
        {
            var client = await _resource.GetByIdAsync(id);
            if (client == null) return false;

            await _resource.DeleteAsync(client);
            return true;
        }

        public async Task<List<ClientDto>> GetClientsByCompanyIdAsync(int companyId)
        {
            return await _resource.GetClientsByCompanyIdAsync(companyId);
        }

    }
}
