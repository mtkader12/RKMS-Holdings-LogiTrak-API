﻿using LogisticsTrackingAPI.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class AIService
    {
    //    //private readonly IncidentReportService _incidentReportService;
    //    private readonly DriverService _driverService;
    //    private readonly DeliveryService _deliveryService;

    //    public AIService(
    //        IncidentReportService incidentReportService,
    //        DriverService driverService,
    //        DeliveryService deliveryService)
    //    {
    //        _incidentReportService = incidentReportService;
    //        _driverService = driverService;
    //        _deliveryService = deliveryService;
    //    }

    //    public async Task<List<DriverDto>> RankDriversForDeliveryAsync(int deliveryId)
    //    {
    //        var delivery = await _deliveryService.GetByIdAsync(deliveryId);
    //        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

    //        var allDrivers = await _driverService.GetAllAsync();
    //        var allIncidents = await _incidentReportService.GetAllAsync();

    //        var driverScores = allDrivers.Select(driver =>
    //        {
    //            var driverIncidents = allIncidents.Where(i => i.DriverId == driver.Id).ToList();
    //            driver.CurrentRating = CalculateDriverScore(driver, driverIncidents);
    //            return driver;
    //        }).OrderByDescending(d => d.CurrentRating).ToList();

    //        return driverScores;
    //    }

    //    private decimal CalculateDriverScore(DriverDto driver, List<IncidentReportDto> incidents)
    //    {
    //        var incidentScore = incidents.Sum(i => CalculateRiskScore(i));
    //        var skillScore = driver.SkillLevel * 5;
    //        var experienceScore = driver.Experience * 2;
    //        return skillScore + experienceScore - incidentScore;
    //    }

    //    private decimal CalculateRiskScore(IncidentReportDto incident)
    //    {
    //        return incident.Severity.ToLower() switch
    //        {
    //            "high" => 10,
    //            "medium" => 5,
    //            "low" => 1,
    //            _ => 0
    //        };
    //    }
    }
}
