﻿//using LogisticsTrackingAPI.ResourceAccess;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace LogisticsTrackingAPI.Services
//{
//    public class IncidentReportService
//    {
//        private readonly IncidentReportResource _resource;

//        public IncidentReportService(IncidentReportResource resource)
//        {
//            _resource = resource;
//        }

//        public async Task<int> AddAsync(IncidentReportDto dto)
//        {
//            var entity = new IncidentReport
//            {
//                DeliveryId = dto.DeliveryId,
//                Severity = dto.Severity,
//                Description = dto.Description,
//                IncidentDate = dto.IncidentDate
//            };

//            await _resource.AddAsync(entity);
//            return entity.Id;
//        }

//        public async Task<bool> UpdateAsync(int id, IncidentReportDto dto)
//        {
//            var entity = await _resource.GetByIdAsync(id);
//            if (entity == null) return false;

//            entity.Severity = dto.Severity;
//            entity.Description = dto.Description;
//            entity.IncidentDate = dto.IncidentDate;

//            return await _resource.UpdateAsync(entity) > 0;
//        }

//        public async Task<bool> DeleteAsync(int id)
//        {
//            var entity = await _resource.GetByIdAsync(id);
//            if (entity == null) return false;

//            return await _resource.DeleteAsync(entity) > 0;
//        }

//        public async Task<List<IncidentReportDto>> GetAllAsync()
//        {
//            var entities = await _resource.GetAllAsync();
//            return entities.Select(e => new IncidentReportDto
//            {
//                Id = e.Id,
//                DeliveryId = e.DeliveryId,
//                Severity = e.Severity,
//                Description = e.Description,
//                IncidentDate = e.IncidentDate
//            }).ToList();
//        }

//        public async Task<List<IncidentReportDto>> GetRecentIncidentsAsync(int driverId)
//        {
//            var incidents = await _resource.GetRecentIncidentsAsync(driverId);
//            return incidents.ConvertAll(MapToDto);
//        }

//    }
//}
