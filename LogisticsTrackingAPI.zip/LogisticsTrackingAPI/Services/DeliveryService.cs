﻿using LogisticsTrackingAPI.ResourceAccess;

public class DeliveryService
{
    private readonly DeliveryResource _deliveryResource;

    public DeliveryService(DeliveryResource deliveryResource)
    {
        _deliveryResource = deliveryResource ?? throw new ArgumentNullException(nameof(deliveryResource));
    }

    public async Task<DeliveryDto> GetByIdAsync(int deliveryId)
    {
        var delivery = await _deliveryResource.GetByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");
        return MapToDto(delivery);
    }

    public async Task UpdateAsync(int deliveryId, DeliveryDto deliveryDto)
    {
        if (deliveryDto == null) throw new ArgumentNullException(nameof(deliveryDto));

        var delivery = await _deliveryResource.GetByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

        delivery.TrailerId = deliveryDto.TrailerId;
        delivery.PickupLocation = deliveryDto.PickupLocation;
        delivery.DeliveryLocation = deliveryDto.DeliveryLocation;
        delivery.ScheduledDate = deliveryDto.ScheduledDate;
        delivery.Pricing = deliveryDto.Pricing;

        await _deliveryResource.UpdateAsync(delivery);
    }
    public async Task AddAsync(DeliveryDto deliveryDto)
    {
        if (deliveryDto == null) throw new ArgumentNullException(nameof(deliveryDto));

        var delivery = MapToEntity(deliveryDto);
        await _deliveryResource.AddAsync(delivery);
    }

    public async Task DeleteAsync(int deliveryId)
    {
        var delivery = await _deliveryResource.GetByIdAsync(deliveryId);
        if (delivery == null) throw new KeyNotFoundException("Delivery not found");

        await _deliveryResource.DeleteAsync(delivery);
    }

    // Get all deliveries
    public async Task<List<DeliveryDto>> GetAllAsync()
    {
        var deliveries = await _deliveryResource.GetAllAsync();
        return deliveries.Select(MapToDto).ToList(); // Mapping each delivery to a DTO
    }

    // Get deliveries by Client ID
    public async Task<List<DeliveryDto>> GetByClientIdAsync(int clientId)
    {
        var deliveries = await _deliveryResource.GetByClientIdAsync(clientId);
        return deliveries.Select(MapToDto).ToList();
    }

    // Helper method to map DTO to Delivery entity
    private Delivery MapToEntity(DeliveryDto deliveryDto)
    {
        return new Delivery
        {
            Id = deliveryDto.Id,
            ClientId = deliveryDto.ClientId,
            LoadType = deliveryDto.LoadType,
            PickupLocation = deliveryDto.PickupLocation,
            DeliveryLocation = deliveryDto.DeliveryLocation,
            Pricing = deliveryDto.Pricing,
            ScheduledDate = deliveryDto.ScheduledDate,
            RiskLevel = deliveryDto.RiskLevel,
            DriverId = deliveryDto.DriverId
        };
    }

    private DeliveryDto MapToDto(Delivery delivery)
    {
        return new DeliveryDto
        {
            Id = delivery.Id,
            ClientId = delivery.ClientId,
            LoadType = delivery.LoadType,
            PickupLocation = delivery.PickupLocation,
            DeliveryLocation = delivery.DeliveryLocation,
            Pricing = delivery.Pricing,
            ScheduledDate = delivery.ScheduledDate,
            RiskLevel = delivery.RiskLevel,
            DriverId = delivery.DriverId
        };
    }
}
