﻿using LogisticsTrackingAPI.ResourceAccess;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Services
{
    public class LogisticsRouteService
    {
        private readonly LogisticsRouteResource _resource;

        public LogisticsRouteService(LogisticsRouteResource resource)
        {
            _resource = resource;
        }

        // Get all logistics routes
        public async Task<List<LogisticsRouteDto>> GetAllAsync()
        {
            var routes = await _resource.GetAllAsync();
            return routes.ConvertAll(route => new LogisticsRouteDto
            {
                Id = route.Id,
                DeliveryId = route.DeliveryId,
                DepotLocation = route.DepotLocation,
                Stops = route.Stops,
                Distance = route.Distance,
                EstimatedTime = route.EstimatedTime,
                DeliveryDetails = $"{route.Delivery.PickupLocation} -> {route.Delivery.DeliveryLocation}"
            });
        }

        // Get logistics route by ID
        public async Task<LogisticsRouteDto> GetByIdAsync(int id)
        {
            var route = await _resource.GetByIdAsync(id);
            if (route == null) throw new KeyNotFoundException("Logistics Route not found");

            return new LogisticsRouteDto
            {
                Id = route.Id,
                DeliveryId = route.DeliveryId,
                DepotLocation = route.DepotLocation,
                Stops = route.Stops,
                Distance = route.Distance,
                EstimatedTime = route.EstimatedTime,
                DeliveryDetails = $"{route.Delivery.PickupLocation} -> {route.Delivery.DeliveryLocation}"
            };
        }

        // Add a new logistics route
        public async Task<int> AddAsync(LogisticsRouteDto dto)
        {
            // Check if the associated delivery exists
            if (!await _resource.DeliveryExistsAsync(dto.DeliveryId))
                throw new KeyNotFoundException("Delivery not found");

            // Map DTO to entity
            var logisticsRoute = new LogisticsRoute
            {
                DeliveryId = dto.DeliveryId,
                DepotLocation = dto.DepotLocation,
                Stops = dto.Stops,
                Distance = dto.Distance,
                EstimatedTime = dto.EstimatedTime
            };

            // Add the logistics route to the database
            await _resource.AddAsync(logisticsRoute);

            // Return the ID of the newly created logistics route
            return logisticsRoute.Id;
        }


        // Update an existing logistics route
        public async Task<bool> UpdateAsync(int id, LogisticsRouteDto dto)
        {
            // Fetch the logistics route by ID
            var logisticsRoute = await _resource.GetByIdAsync(id);
            if (logisticsRoute == null)
                throw new KeyNotFoundException("Logistics Route not found");

            // Update logistics route properties if they are different
            if (!string.Equals(logisticsRoute.DepotLocation, dto.DepotLocation, StringComparison.OrdinalIgnoreCase))
                logisticsRoute.DepotLocation = dto.DepotLocation;

            if (!string.Equals(logisticsRoute.Stops, dto.Stops, StringComparison.OrdinalIgnoreCase))
                logisticsRoute.Stops = dto.Stops;

            if (logisticsRoute.Distance != dto.Distance)
                logisticsRoute.Distance = dto.Distance;

            if (logisticsRoute.EstimatedTime != dto.EstimatedTime)
                logisticsRoute.EstimatedTime = dto.EstimatedTime;

            // Validate and update the DeliveryId if it is different
            if (dto.DeliveryId != logisticsRoute.DeliveryId)
            {
                if (!await _resource.DeliveryExistsAsync(dto.DeliveryId))
                    throw new KeyNotFoundException("Delivery not found");
                logisticsRoute.DeliveryId = dto.DeliveryId;
            }

            // Perform the update and return the success status
            var updatedRows = await _resource.UpdateAsync(logisticsRoute);
            return updatedRows > 0; // Return true if one or more rows were updated
        }



        // Delete a logistics route
        public async Task<bool> DeleteAsync(int id)
        {
            var logisticsRoute = await _resource.GetByIdAsync(id);
            if (logisticsRoute == null)
                return false; // Return false if the logistics route does not exist.

            await _resource.DeleteAsync(logisticsRoute);
            return true; // Return true if the deletion is successful.
        }

        public async Task<LogisticsRouteDto> GetByDeliveryIdAsync(int deliveryId)
        {
            var route = await _resource.GetByDeliveryIdAsync(deliveryId);
            if (route == null) throw new KeyNotFoundException("Logistics route not found for the given delivery ID.");

            return new LogisticsRouteDto
            {
                Id = route.Id,
                DeliveryId = route.DeliveryId,
                DepotLocation = route.DepotLocation,
                Stops = route.Stops,
                Distance = route.Distance,
                EstimatedTime = route.EstimatedTime
            };
        }
    }
}
