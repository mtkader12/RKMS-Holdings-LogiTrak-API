﻿using LogisticsTrackingAPI.Orchestration;
using LogisticsTrackingAPI.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class LogisticsRouteOrchestration
    {
        private readonly LogisticsRouteService _logisticsRouteService;
        private readonly DeliveryService _deliveryService;
        private readonly TrafficConditionsOrchestration _trafficConditionsOrchestration;
        private readonly WeatherConditionsOrchestration _weatherConditionsOrchestration;

        public LogisticsRouteOrchestration(
            LogisticsRouteService logisticsRouteService,
            DeliveryService deliveryService,
            TrafficConditionsOrchestration trafficConditionsOrchestration,
            WeatherConditionsOrchestration weatherConditionsOrchestration)
        {
            _logisticsRouteService = logisticsRouteService;
            _deliveryService = deliveryService;
            _trafficConditionsOrchestration = trafficConditionsOrchestration;
            _weatherConditionsOrchestration = weatherConditionsOrchestration;
        }

        // 1. Get all logistics routes
        public async Task<List<LogisticsRouteDto>> GetAllLogisticsRoutesAsync()
        {
            return await _logisticsRouteService.GetAllAsync();
        }

        // 2. Get a logistics route by ID
        public async Task<LogisticsRouteDto> GetLogisticsRouteByIdAsync(int id)
        {
            return await _logisticsRouteService.GetByIdAsync(id);
        }

        // 3. Determine and add a logistics route based on a delivery
        public async Task<int> DetermineAndAddRouteAsync(int deliveryId)
        {
            // Fetch the delivery details
            var delivery = await _deliveryService.GetByIdAsync(deliveryId);
            if (delivery == null)
                throw new KeyNotFoundException("Delivery not found.");

            // Fetch real-time traffic and weather data via orchestrations
            var trafficConditions = await _trafficConditionsOrchestration.GetTrafficConditionsForDeliveryAsync(delivery.PickupLocation, delivery.DeliveryLocation);
            var weatherConditions = await _weatherConditionsOrchestration.GetWeatherConditionsForDeliveryAsync(delivery.PickupLocation, delivery.DeliveryLocation);


            // Determine the optimal route (dummy logic for now)
            var route = new LogisticsRouteDto
            {
                DepotLocation = delivery.PickupLocation,
                Stops = $"{delivery.PickupLocation} -> {delivery.DeliveryLocation}",
                Distance = CalculateDistance(delivery.PickupLocation, delivery.DeliveryLocation), // Placeholder for distance calculation
                EstimatedTime = CalculateEstimatedTime(trafficConditions, weatherConditions),   // Placeholder for time calculation
                DeliveryId = deliveryId
            };

            // Add the route to the database
            return await _logisticsRouteService.AddAsync(route);
        }

        // 4. Update an existing logistics route
        public async Task<bool> UpdateLogisticsRouteAsync(int id, LogisticsRouteDto logisticsRouteDto)
        {
            return await _logisticsRouteService.UpdateAsync(id, logisticsRouteDto);
        }

        // 5. Delete a logistics route
        public async Task<bool> DeleteLogisticsRouteAsync(int id)
        {
            return await _logisticsRouteService.DeleteAsync(id);
        }

        // Helper: Calculate distance between pickup and delivery locations
        private decimal CalculateDistance(string pickup, string delivery)
        {
            // Dummy calculation (implement actual distance calculation logic)
            return 100.0m;
        }

        // Helper: Calculate estimated time based on traffic and weather
        private TimeSpan CalculateEstimatedTime(List<TrafficConditionsDto> traffic, List<WeatherConditionsDto> weather)
        {
            // Dummy calculation (implement logic to analyze traffic and weather data)
            int totalMinutes = 120; // in minutes (replace this with real calculation logic)

            // Convert the result to TimeSpan
            return TimeSpan.FromMinutes(totalMinutes);
        }

    }
}
