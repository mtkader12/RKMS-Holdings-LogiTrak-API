﻿using LogisticsTrackingAPI.Services;

namespace LogisticsTrackingAPI.Orchestration
{
    /// <summary>
    /// Orchestration layer for managing Access Levels.
    /// Acts as a mediator between the Access Level services and higher-level business logic or controllers.
    /// </summary>
    public class AccessLevelOrchestration
    {
        private readonly AccessLevelServices _accessLevelServices;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccessLevelOrchestration"/> class.
        /// </summary>
        /// <param name="accessLevelServices">The service layer handling data operations for Access Levels.</param>
        public AccessLevelOrchestration(AccessLevelServices accessLevelServices)
        {
            _accessLevelServices = accessLevelServices;
        }

        /// <summary>
        /// Retrieves all Access Levels from the system.
        /// </summary>
        /// <returns>A list of <see cref="AccessLevelDto"/> representing all Access Levels.</returns>
        public async Task<List<AccessLevelDto>> GetAllAccessLevelsAsync()
        {
            return await _accessLevelServices.GetAllAsync(); // Calls the service to fetch all Access Levels.
        }

        /// <summary>
        /// Retrieves a specific Access Level by its ID.
        /// </summary>
        /// <param name="id">The ID of the Access Level to retrieve.</param>
        /// <returns>An <see cref="AccessLevelDto"/> representing the Access Level, or null if not found.</returns>
        public async Task<AccessLevelDto> GetAccessLevelByIdAsync(int id)
        {
            return await _accessLevelServices.GetByIdAsync(id); // Calls the service to fetch a specific Access Level by ID.
        }

        /// <summary>
        /// Adds a new Access Level to the system.
        /// </summary>
        /// <param name="dto">The data transfer object containing details of the new Access Level.</param>
        /// <returns>The ID of the newly created Access Level.</returns>
        public async Task<int> AddAccessLevelAsync(AccessLevelDto dto)
        {
            return await _accessLevelServices.AddAsync(dto); // Calls the service to add a new Access Level.
        }

        /// <summary>
        /// Updates an existing Access Level in the system.
        /// </summary>
        /// <param name="id">The ID of the Access Level to update.</param>
        /// <param name="dto">The data transfer object containing updated details of the Access Level.</param>
        /// <returns>A boolean indicating whether the update was successful (true) or not (false).</returns>
        public async Task<bool> UpdateAccessLevelAsync(int id, AccessLevelDto dto)
        {
            return await _accessLevelServices.UpdateAsync(id, dto); // Calls the service to update an existing Access Level.
        }

        /// <summary>
        /// Deletes an Access Level from the system by its ID.
        /// </summary>
        /// <param name="id">The ID of the Access Level to delete.</param>
        /// <returns>A boolean indicating whether the deletion was successful (true) or not (false).</returns>
        public async Task<bool> DeleteAccessLevelAsync(int id)
        {
            return await _accessLevelServices.DeleteAsync(id); // Calls the service to delete an Access Level.
        }
    }
}
