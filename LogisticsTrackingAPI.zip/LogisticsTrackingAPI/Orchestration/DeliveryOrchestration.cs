﻿using LogisticsTrackingAPI.Services;

public class DeliveryOrchestration : BaseOrchestration
{
    private readonly DeliveryService _deliveryService;
    private readonly PaymentService _paymentService;
    private readonly NotificationOrchestration _notificationOrchestration;
    private readonly HistoricalDeliveryDataService _historicalDeliveryDataService;
    private readonly DriverOrchestration _driverOrchestration;
    private readonly RealTimeUpdatesService _realTimeUpdatesService;

    public DeliveryOrchestration(
        DeliveryService deliveryService,
        PaymentService paymentService,
        NotificationOrchestration notificationOrchestration,
        HistoricalDeliveryDataService historicalDeliveryDataService,
        DriverOrchestration driverOrchestration,
        RealTimeUpdatesService realTimeUpdatesService)
    {
        _deliveryService = deliveryService;
        _paymentService = paymentService;
        _notificationOrchestration = notificationOrchestration;
        _historicalDeliveryDataService = historicalDeliveryDataService;
        _driverOrchestration = driverOrchestration;
        _realTimeUpdatesService = realTimeUpdatesService;
    }

    public async Task<DeliveryDto> CreateDeliveryAsync(DeliveryDto deliveryDto)
{
    try
    {
        // 1. Check arrears
        bool hasArrears = await _paymentService.CheckArrearsAsync(deliveryDto.ClientId);
        if (hasArrears)
        {
            await _notificationOrchestration.SendToCompanyUserAsync(
                deliveryDto.ClientId, 
                "Client has outstanding payments. Delivery may be delayed."
            );
            throw new InvalidOperationException("Client has outstanding payments.");
        }

        // 2. Assign driver, vehicle, and trailer
        // Use PickupLocation and DeliveryLocation for assigning resources
        var assignedDriver = await _driverOrchestration.AssignDriverAsync(
            deliveryDto.PickupLocation, deliveryDto.DeliveryLocation
        );
        deliveryDto.DriverId = assignedDriver.Id;

        var assignedVehicle = await _driverOrchestration.AssignVehicleAsync(
            deliveryDto.PickupLocation, deliveryDto.DeliveryLocation
        );
        deliveryDto.VehicleId = assignedVehicle.Id;

        var assignedTrailer = await _driverOrchestration.AssignTrailerAsync(
            deliveryDto.PickupLocation, deliveryDto.DeliveryLocation
        );
        deliveryDto.TrailerId = assignedTrailer.Id;

        // 3. Create delivery
        var createdDelivery = await _deliveryService.AddAsync(deliveryDto);

        // 4. Store historical data
        await _historicalDeliveryDataService.AddAsync(new HistoricalDeliveryDataDto
        {
            DeliveryId = createdDelivery.Id,
            ClientId = deliveryDto.ClientId,
            DriverId = deliveryDto.DriverId,
            VehicleId = deliveryDto.VehicleId,
            TrailerId = deliveryDto.TrailerId,
            PickupLocation = deliveryDto.PickupLocation,
            DeliveryLocation = deliveryDto.DeliveryLocation,
            ScheduledDate = deliveryDto.ScheduledDate
        });

        return createdDelivery;
    }
    catch (Exception ex)
    {
        // Log the error (if applicable)
        throw;
    }
}

}
