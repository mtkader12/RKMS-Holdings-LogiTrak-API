﻿using LogisticsTrackingAPI.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    /// <summary>
    /// Orchestration layer for managing driver performance and related operations.
    /// </summary>
    public class DriverPerformanceOrchestration
    {
        private readonly DriverPerformanceService _driverPerformanceService;
        private readonly DriverService _driverService;
        private readonly DeliveryService _deliveryService;

        public DriverPerformanceOrchestration(
            DriverPerformanceService driverPerformanceService,
            DriverService driverService,
            DeliveryService deliveryService)
        {
            _driverPerformanceService = driverPerformanceService;
            _driverService = driverService;
            _deliveryService = deliveryService;
        }

        /// <summary>
        /// Adds or updates a driver performance record.
        /// </summary>
        public async Task SaveOrUpdatePerformanceAsync(DriverPerformanceDto performanceDto)
        {
            // Validate the driver
            var driver = await _driverService.GetByIdAsync(performanceDto.DriverId);
            if (driver == null)
                throw new KeyNotFoundException("Driver not found");

            // Validate the delivery
            var delivery = await _deliveryService.GetByIdAsync(performanceDto.DeliveryId);
            if (delivery == null)
                throw new KeyNotFoundException("Delivery not found");

            // Map DTO to entity
            var performanceEntity = MapToEntity(performanceDto);

            // Save or update the performance record
            await _driverPerformanceService.SaveOrUpdateAsync(performanceEntity);
        }

        /// <summary>
        /// Retrieves all driver performance records.
        /// </summary>
        public async Task<List<DriverPerformanceDto>> GetAllPerformancesAsync()
        {
            return await _driverPerformanceService.GetAllAsync();
        }

        /// <summary>
        /// Retrieves performance records for a specific driver.
        /// </summary>
        public async Task<List<DriverPerformanceDto>> GetPerformancesByDriverIdAsync(int driverId)
        {
            return await _driverPerformanceService.GetByDriverIdAsync(driverId);
        }

        /// <summary>
        /// Retrieves the top-performing drivers based on AI scores.
        /// </summary>
        public async Task<List<DriverPerformanceDto>> GetTopPerformingDriversAsync(int count)
        {
            return await _driverPerformanceService.GetTopPerformingDriversAsync(count);
        }

        /// <summary>
        /// Temporarily Disabled: Updates driver performance based on an incident.
        /// </summary>
        //[Obsolete("Incident-related logic is temporarily disabled. This method is not functional.")]
        //public Task UpdatePerformanceForIncidentAsync(int driverId, IncidentReportDto incidentDto)
        //{
        //    throw new NotImplementedException("This logic is shelved. Remove references to this method.");
        //}

        /// <summary>
        /// Retrieves the performance ranking for a driver.
        /// </summary>
        public async Task<decimal> GetDriverRankingAsync(int driverId)
        {
            var performances = await _driverPerformanceService.GetByDriverIdAsync(driverId);
            if (performances == null || performances.Count == 0)
                throw new KeyNotFoundException("No performance records found for this driver");

            // Calculate an average AI score for the driver
            decimal totalScore = 0;
            foreach (var performance in performances)
            {
                totalScore += performance.AIOverallScore;
            }

            return totalScore / performances.Count;
        }

        /// <summary>
        /// Maps a DriverPerformanceDto to a DriverPerformance entity.
        /// </summary>
        private DriverPerformance MapToEntity(DriverPerformanceDto dto)
        {
            if (dto == null) throw new ArgumentNullException(nameof(dto));

            return new DriverPerformance
            {
                Id = dto.Id,
                DriverId = dto.DriverId,
                DeliveryId = dto.DeliveryId,
                MilesDriven = dto.MilesDriven,
                FuelConsumed = dto.FuelConsumed,
                TimeTaken = dto.TimeTaken,
                PerformanceRating = dto.PerformanceRating
            };
        }
    }
}
