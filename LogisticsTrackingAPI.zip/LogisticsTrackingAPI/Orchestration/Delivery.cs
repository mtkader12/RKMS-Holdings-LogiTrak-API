﻿using LogisticsTrackingAPI.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class DeliveryOrchestration
    {
        private readonly DeliveryService _deliveryService;
        private readonly PaymentService _paymentService;

        public DeliveryOrchestration(DeliveryService deliveryService, PaymentService paymentService)
        {
            _deliveryService = deliveryService;
            _paymentService = paymentService;
        }

        // 1. Get all deliveries
        public async Task<List<DeliveryDto>> GetAllDeliveriesAsync()
        {
            return await _deliveryService.GetAllAsync();
        }

        // 2. Get delivery by ID
        public async Task<DeliveryDto> GetDeliveryByIdAsync(int id)
        {
            return await _deliveryService.GetByIdAsync(id);
        }

        // 3. Add a new delivery
        public async Task AddDeliveryAsync(DeliveryDto deliveryDto)
        {
            // Check if the client is in arrears
            var hasArrears = await _paymentService.CheckArrearsAsync(deliveryDto.ClientId);

            // Log or notify about arrears, but allow booking
            if (hasArrears)
            {
                Console.WriteLine($"Warning: Client {deliveryDto.ClientId} is in arrears. Booking will proceed.");
                deliveryDto.HasArrears = true; // Add this flag to indicate arrears status
            }

            // Add the delivery
            await _deliveryService.AddAsync(deliveryDto);

            // Record initial payment entry
            var paymentDto = new PaymentDto
            {
                ClientId = deliveryDto.ClientId,
                DeliveryId = deliveryDto.Id,
                Amount = 0.0, // Pricing to be updated later
                PaymentDate = DateTime.UtcNow,
                Status = "Pending"
            };

            await _paymentService.AddAsync(paymentDto);
        }

        // 4. Update an existing delivery
        public async Task UpdateDeliveryAsync(int id, DeliveryDto deliveryDto)
        {
            // Update the delivery details
            await _deliveryService.UpdateAsync(id, deliveryDto);

            // Optionally, update payment details if related to pricing changes
            var payment = await _paymentService.GetByDeliveryIdAsync(id);
            if (payment != null && deliveryDto.Pricing > 0)
            {
                payment.Amount = (double)deliveryDto.Pricing;
                await _paymentService.UpdateAsync(payment.Id, payment);
            }
        }

        // 5. Delete a delivery
        public async Task DeleteDeliveryAsync(int id)
        {
            // Check if the delivery exists
            var delivery = await _deliveryService.GetByIdAsync(id);
            if (delivery == null)
                throw new KeyNotFoundException("Delivery not found");

            // Delete the delivery
            await _deliveryService.DeleteAsync(id);

            // Remove related payment records
            var payment = await _paymentService.GetByDeliveryIdAsync(id);
            if (payment != null)
            {
                await _paymentService.DeleteAsync(payment.Id);
            }
        }

        // 6. Check for client arrears
        public async Task<bool> CheckClientArrearsAsync(int clientId)
        {
            return await _paymentService.CheckArrearsAsync(clientId);
        }

        //Method to Get Bookings for a Specific Client
        public async Task<List<DeliveryDto>> GetDeliveriesByClientIdAsync(int clientId)
        {
            // Fetch all deliveries for a given client ID
            return await _deliveryService.GetByClientIdAsync(clientId);
        }

    }
}
