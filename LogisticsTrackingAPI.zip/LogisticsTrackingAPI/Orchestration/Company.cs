﻿using LogisticsTrackingAPI.Services;
//using LogisticsTrackingAPI.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class CompanyOrchestration
    {
        private readonly CompanyService _companyService;
        private readonly UserService _userService;
        private readonly ClientService _clientService;

        public CompanyOrchestration(CompanyService companyService, UserService userService, ClientService clientService)
        {
            _companyService = companyService;
            _userService = userService;
            _clientService = clientService;
        }

        // 1. Get all companies
        public async Task<List<CompanyDto>> GetAllCompaniesAsync()
        {
            return await _companyService.GetAllAsync();
        }

        // 2. Get a company by ID
        public async Task<CompanyDto> GetCompanyByIdAsync(int companyId)
        {
            return await _companyService.GetByIdAsync(companyId);
        }

        // 3. Add a new company
        public async Task<int> AddCompanyAsync(CompanyDto companyDto)
        {
            // Validate duplicate entry by name or email
            if (await _companyService.ExistsAsync(companyDto.Name, companyDto.Email))
                throw new InvalidOperationException("A company with the same name or email already exists.");

            return await _companyService.AddAsync(companyDto);
        }

        // 4. Update a company
        public async Task<bool> UpdateCompanyAsync(int companyId, CompanyDto updatedCompanyDto)
        {
            var company = await _companyService.GetByIdAsync(companyId);
            if (company == null)
                throw new Exception("Company not found.");

            return await _companyService.UpdateAsync(companyId, updatedCompanyDto);
        }

        // 5. Delete a company
        public async Task<bool> DeleteCompanyAsync(int companyId)
        {
            var company = await _companyService.GetByIdAsync(companyId);
            if (company == null)
                throw new Exception("Company not found.");

            // Check for active users or clients
            var users = await _userService.GetUsersByCompanyIdAsync(companyId);
            if (users.Count > 0)
                throw new InvalidOperationException("Cannot delete company with active users.");

            var clients = await _clientService.GetClientsByCompanyIdAsync(companyId);
            if (clients.Count > 0)
                throw new InvalidOperationException("Cannot delete company with active clients.");

            return await _companyService.DeleteAsync(companyId);
        }

        // 6. Get all users under a company
        public async Task<List<UserDto>> GetAllUsersInCompanyAsync(int companyId)
        {
            return await _userService.GetUsersByCompanyIdAsync(companyId);
        }

        // 7. Get all clients under a company
        public async Task<List<ClientDto>> GetAllClientsInCompanyAsync(int companyId)
        {
            return await _clientService.GetClientsByCompanyIdAsync(companyId);
        }

        // 8. Assign a user to a company
        public async Task AssignUserToCompanyAsync(int userId, int companyId)
        {
            var user = await _userService.GetByIdAsync(userId);
            if (user == null)
                throw new Exception("User not found.");

            var company = await _companyService.GetByIdAsync(companyId);
            if (company == null)
                throw new Exception("Company not found.");

            user.CompanyId = companyId;
            await _userService.UpdateAsync(userId, user);
        }

        // 9. Assign a client to a company
        public async Task AssignClientToCompanyAsync(int clientId, int companyId)
        {
            var client = await _clientService.GetByIdAsync(clientId);
            if (client == null)
                throw new Exception("Client not found.");

            var company = await _companyService.GetByIdAsync(companyId);
            if (company == null)
                throw new Exception("Company not found.");

            client.CompanyId = companyId;
            await _clientService.UpdateAsync(clientId, client);
        }
    }
}
