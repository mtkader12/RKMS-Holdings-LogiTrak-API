﻿using LogisticsTrackingAPI.Services;

public class ClientToTrailerOrchestration
{
    private readonly ClientToTrailerService _clientToTrailerService;

    public ClientToTrailerOrchestration(ClientToTrailerService clientToTrailerService)
    {
        _clientToTrailerService = clientToTrailerService;
    }

    public async Task<List<ClientToTrailerDto>> GetAllClientToTrailerLinksAsync()
    {
        return await _clientToTrailerService.GetAllAsync();
    }

    public async Task<ClientToTrailerDto> GetClientToTrailerByIdAsync(int id)
    {
        return await _clientToTrailerService.GetByIdAsync(id);
    }

    public async Task<int> CreateClientToTrailerLinkAsync(ClientToTrailerDto dto)
    {
        return  await _clientToTrailerService.AddAsync(dto);
    }

    public async Task<bool> UpdateClientToTrailerLinkAsync(int id, ClientToTrailerDto dto)
    {
        return await _clientToTrailerService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteClientToTrailerLinkAsync(int id)
    {
        return await _clientToTrailerService.DeleteAsync(id);
    }
}
