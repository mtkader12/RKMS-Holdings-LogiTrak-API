﻿using LogisticsTrackingAPI.Models;
using LogisticsTrackingAPI.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class WeatherConditionsOrchestration
    {
        private readonly WeatherConditionsRepository _weatherConditionsRepository;

        public WeatherConditionsOrchestration(WeatherConditionsRepository weatherConditionsRepository)
        {
            _weatherConditionsRepository = weatherConditionsRepository ?? throw new ArgumentNullException(nameof(weatherConditionsRepository), "WeatherConditions repository cannot be null.");
        }

        // 1. Retrieve all weather conditions
        public async Task<IEnumerable<WeatherConditions>> GetAllWeatherConditionsAsync()
        {
            try
            {
                return await _weatherConditionsRepository.GetAllWeatherConditionsAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Error retrieving all weather conditions.", ex);
            }
        }

        // 2. Retrieve a weather condition by ID
        public async Task<WeatherConditions> GetWeatherConditionByIdAsync(int weatherId)
        {
            try
            {
                return await _weatherConditionsRepository.GetWeatherConditionByIdAsync(weatherId);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving weather condition with ID {weatherId}.", ex);
            }
        }

        // 3. Create a new weather condition entry
        public async Task<int> CreateWeatherConditionAsync(WeatherConditions weatherCondition)
        {
            try
            {
                return await _weatherConditionsRepository.CreateWeatherConditionAsync(weatherCondition);
            }
            catch (Exception ex)
            {
                throw new Exception("Error creating new weather condition entry.", ex);
            }
        }

        // 4. Update an existing weather condition entry
        public async Task<bool> UpdateWeatherConditionAsync(WeatherConditions weatherCondition)
        {
            try
            {
                return await _weatherConditionsRepository.UpdateWeatherConditionAsync(weatherCondition);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating weather condition with ID {weatherCondition.WeatherId}.", ex);
            }
        }

        // 5. Delete a weather condition entry
        public async Task<bool> DeleteWeatherConditionAsync(int weatherId)
        {
            try
            {
                return await _weatherConditionsRepository.DeleteWeatherConditionAsync(weatherId);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting weather condition with ID {weatherId}.", ex);
            }
        }
    }
}
