﻿using LogisticsTrackingAPI.Services;

public class LogisticsRouteOrchestration
{
    private readonly LogisticsRouteService _logisticsRouteService;

    public LogisticsRouteOrchestration(LogisticsRouteService logisticsRouteService)
    {
        _logisticsRouteService = logisticsRouteService;
    }

    public async Task<List<LogisticsRouteDto>> GetAllRoutesAsync()
    {
        return await _logisticsRouteService.GetAllAsync();
    }

    public async Task<LogisticsRouteDto> GetRouteByIdAsync(int id)
    {
        return await _logisticsRouteService.GetByIdAsync(id);
    }

    public async Task<int> CreateRouteAsync(LogisticsRouteDto dto)
    {
        return await _logisticsRouteService.AddAsync(dto);
    }

    public async Task<bool> UpdateRouteAsync(int id, LogisticsRouteDto dto)
    {
        return await _logisticsRouteService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteRouteAsync(int id)
    {
        return await _logisticsRouteService.DeleteAsync(id);
    }
}
