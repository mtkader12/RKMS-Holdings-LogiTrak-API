﻿using LogisticsTrackingAPI.Models;
using LogisticsTrackingAPI.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class DriverOrchestration
    {
        private readonly DriverRepository _driverRepository;

        public DriverOrchestration(DriverRepository driverRepository)
        {
            _driverRepository = driverRepository ?? throw new ArgumentNullException(nameof(driverRepository), "Driver repository cannot be null.");
        }

        // 1. Get all drivers
        public async Task<IEnumerable<Driver>> GetAllDriversAsync()
        {
            try
            {
                return await _driverRepository.GetAllDriversAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching all drivers.", ex);
            }
        }

        // 2. Get driver by ID
        public async Task<Driver> GetDriverByIdAsync(int driverId)
        {
            if (driverId <= 0)
                throw new ArgumentException("Driver ID must be greater than zero.", nameof(driverId));

            try
            {
                return await _driverRepository.GetDriverByIdAsync(driverId);
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching driver by ID.", ex);
            }
        }

        // 3. Create a new driver
        public async Task<int> CreateDriverAsync(Driver driver)
        {
            if (driver == null)
                throw new ArgumentNullException(nameof(driver), "Driver cannot be null.");

            try
            {
                return await _driverRepository.CreateDriverAsync(driver);
            }
            catch (Exception ex)
            {
                throw new Exception("Error creating new driver.", ex);
            }
        }

        // 4. Update driver details
        public async Task<bool> UpdateDriverAsync(Driver driver)
        {
            if (driver == null)
                throw new ArgumentNullException(nameof(driver), "Driver cannot be null.");

            try
            {
                return await _driverRepository.UpdateDriverAsync(driver);
            }
            catch (Exception ex)
            {
                throw new Exception("Error updating driver.", ex);
            }
        }

        // 5. Delete driver
        public async Task<bool> DeleteDriverAsync(int driverId)
        {
            if (driverId <= 0)
                throw new ArgumentException("Driver ID must be greater than zero.", nameof(driverId));

            try
            {
                return await _driverRepository.DeleteDriverAsync(driverId);
            }
            catch (Exception ex)
            {
                throw new Exception("Error deleting driver.", ex);
            }
        }

        // 6. Get drivers by vehicle ID
        public async Task<IEnumerable<Driver>> GetDriversByVehicleAsync(int vehicleId)
        {
            if (vehicleId <= 0)
                throw new ArgumentException("Vehicle ID must be greater than zero.", nameof(vehicleId));

            try
            {
                return await _driverRepository.GetDriversByVehicleAsync(vehicleId);
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching drivers by vehicle ID.", ex);
            }
        }

        // 7. Get drivers by company ID
        public async Task<IEnumerable<Driver>> GetDriversByCompanyAsync(int companyId)
        {
            if (companyId <= 0)
                throw new ArgumentException("Company ID must be greater than zero.", nameof(companyId));

            try
            {
                return await _driverRepository.GetDriversByCompanyAsync(companyId);
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching drivers by company ID.", ex);
            }
        }
    }
}
