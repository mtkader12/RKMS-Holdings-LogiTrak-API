﻿using LogisticsTrackingAPI.Services;

public class TypeOfGoodsOrchestration
{
    private readonly TypeOfGoodsService _typeOfGoodsService;

    public TypeOfGoodsOrchestration(TypeOfGoodsService typeOfGoodsService)
    {
        _typeOfGoodsService = typeOfGoodsService;
    }

    public async Task<List<TypeOfGoodsDto>> GetAllTypesOfGoodsAsync()
    {
        return await _typeOfGoodsService.GetAllAsync();
    }

    public async Task<TypeOfGoodsDto> GetTypeOfGoodsByIdAsync(int id)
    {
        return await _typeOfGoodsService.GetByIdAsync(id);
    }

    public async Task<int> CreateTypeOfGoodsAsync(TypeOfGoodsDto dto)
    {
        return await _typeOfGoodsService.AddAsync(dto);
    }

    public async Task<bool> UpdateTypeOfGoodsAsync(int id, TypeOfGoodsDto dto)
    {
        return await _typeOfGoodsService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteTypeOfGoodsAsync(int id)
    {
        return await _typeOfGoodsService.DeleteAsync(id);
    }
}
