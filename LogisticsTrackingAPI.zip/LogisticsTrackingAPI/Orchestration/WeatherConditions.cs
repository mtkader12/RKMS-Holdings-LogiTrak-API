﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using LogisticsTrackingAPI.Services;

namespace LogisticsTrackingAPI.Orchestration
{
    /// <summary>
    /// Handles business logic related to weather conditions and their influence on logistics routes.
    /// </summary>
    public class WeatherConditionsOrchestration
    {
        private readonly WeatherConditionsService _weatherConditionsService;
        private readonly LogisticsRouteService _logisticsRouteService;
        private readonly HttpClient _httpClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="WeatherConditionsOrchestration"/> class.
        /// </summary>
        public WeatherConditionsOrchestration(
            WeatherConditionsService weatherConditionsService,
            LogisticsRouteService logisticsRouteService,
            HttpClient httpClient)
        {
            _weatherConditionsService = weatherConditionsService;
            _logisticsRouteService = logisticsRouteService;
            _httpClient = httpClient;
        }

        /// <summary>
        /// Adjusts the logistics route based on weather conditions and updates the estimated time.
        /// </summary>
        public async Task<int> InfluenceRouteWithWeatherAsync(int deliveryId)
        {
            // Fetch the logistics route associated with the delivery.
            var route = await _logisticsRouteService.GetByDeliveryIdAsync(deliveryId);
            if (route == null)
                throw new KeyNotFoundException("Logistics route for the delivery not found.");

            // Fetch weather conditions for both pickup and delivery locations.
            var weatherConditions = await GetWeatherConditionsForDeliveryAsync(route.DepotLocation, route.Stops);

            // Calculate adjusted estimated time based on weather conditions.
            int adjustedETA = CalculateAdjustedETA(weatherConditions);

            // Update the logistics route's estimated time.
            route.EstimatedTime = TimeSpan.FromMinutes(adjustedETA);
            await _logisticsRouteService.UpdateAsync(route.Id, route);

            // Optionally store summarized weather data in the database for historical reference.
            foreach (var weather in weatherConditions)
            {
                await _weatherConditionsService.AddAsync(new WeatherConditionsDto
                {
                    Location = weather.Location,
                    Condition = weather.Condition,
                    Temperature = weather.Temperature,
                    Humidity = weather.Humidity,
                    Timestamp = weather.Timestamp
                });
            }

            return adjustedETA;
        }

        /// <summary>
        /// Calculates the adjusted estimated time based on weather conditions.
        /// </summary>
        private int CalculateAdjustedETA(List<WeatherConditionsDto> weatherConditions)
        {
            int totalDelay = 0;
            foreach (var weather in weatherConditions)
            {
                if (weather.Condition.Contains("Rain", StringComparison.OrdinalIgnoreCase))
                    totalDelay += 20; // Add delay for rain.
                if (weather.Condition.Contains("Snow", StringComparison.OrdinalIgnoreCase))
                    totalDelay += 30; // Add delay for snow.
            }
            return 100 + totalDelay; // Base ETA + delays.
        }

        /// <summary>
        /// Retrieves weather conditions for both the pickup and delivery locations of a delivery route.
        /// </summary>
        public async Task<List<WeatherConditionsDto>> GetWeatherConditionsForDeliveryAsync(string pickupLocation, string deliveryLocation)
        {
            var pickupWeather = await GetWeatherForLocationAsync(pickupLocation);
            var deliveryWeather = await GetWeatherForLocationAsync(deliveryLocation);

            return new List<WeatherConditionsDto> { pickupWeather, deliveryWeather };
        }

        /// <summary>
        /// Retrieves weather conditions for a given location using the OpenWeatherMap API.
        /// </summary>
        public async Task<WeatherConditionsDto> GetWeatherForLocationAsync(string location)
        {
            var apiKey = "YOUR_OPENWEATHERMAP_API_KEY";
            var apiUrl = $"https://api.openweathermap.org/data/2.5/weather?q={Uri.EscapeDataString(location)}&appid={apiKey}&units=metric";

            var response = await _httpClient.GetAsync(apiUrl);
            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException($"Failed to retrieve weather data. Status Code: {response.StatusCode}");

            var content = await response.Content.ReadAsStringAsync();
            var weatherData = JsonSerializer.Deserialize<OpenWeatherMapResponse>(content);

            return new WeatherConditionsDto
            {
                Location = location,
                Condition = weatherData.Weather[0].Description,
                Temperature = weatherData.Main.Temp,
                Humidity = weatherData.Main.Humidity,
                Timestamp = DateTime.UtcNow
            };
        }
    }

    /// <summary>
    /// Represents the response from the OpenWeatherMap API.
    /// </summary>
    public class OpenWeatherMapResponse
    {
        public MainData Main { get; set; }
        public WeatherDescription[] Weather { get; set; }
    }

    public class MainData
    {
        public double Temp { get; set; }
        public int Humidity { get; set; }
    }

    public class WeatherDescription
    {
        public string Description { get; set; }
    }
}
