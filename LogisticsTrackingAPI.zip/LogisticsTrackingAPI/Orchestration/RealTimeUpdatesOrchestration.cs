﻿using LogisticsTrackingAPI.Services;

public class RealTimeUpdatesOrchestration : BaseOrchestration
{
    private readonly RealTimeUpdatesService _realTimeUpdatesService;
    private readonly NotificationOrchestration _notificationOrchestration;

    public RealTimeUpdatesOrchestration(
        RealTimeUpdatesService realTimeUpdatesService,
        NotificationOrchestration notificationOrchestration)
    {
        _realTimeUpdatesService = realTimeUpdatesService;
        _notificationOrchestration = notificationOrchestration;
    }

    public async Task PublishLocationUpdateAsync(int vehicleId, double latitude, double longitude)
    {
        try
        {
            // Update location in real-time updates table
            await _realTimeUpdatesService.AddOrUpdateAsync(new RealTimeUpdatesDto
            {
                VehicleId = vehicleId,
                Latitude = latitude,
                Longitude = longitude,
                Timestamp = DateTime.UtcNow
            });

            // Notify company user about location
            await _notificationOrchestration.SendToCompanyUserAsync(vehicleId, $"Vehicle {vehicleId} updated its location.");
        }
        catch (Exception ex)
        {
            HandleException(ex);
        }
    }
}
