﻿public abstract class BaseOrchestration
{
    protected void HandleException(Exception ex)
    {
        // Centralized exception handling logic
        // Log error details
        Console.WriteLine($"Error: {ex.Message}");
        throw ex;
    }
}
