﻿using LogisticsTrackingAPI.Services;
using LogisticsTrackingAPI.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class UserOrchestration
    {
        private readonly UserService _userService;
        private readonly NotificationService _notificationService;
        private readonly ClientService _clientService;
        private readonly AccessLevelServices _accessLevelService;
        private readonly DriverService _driverService;

        public UserOrchestration(UserService userService, DriverService driverService ,ClientService clientService, NotificationService notificationService, AccessLevelServices accessLevelService)
        {
            _userService = userService;
            _clientService = clientService;
            _driverService = driverService;
            _notificationService = notificationService;
            _accessLevelService = accessLevelService;
        }

        // 1. Get all users
        public async Task<List<UserDto>> GetAllUsersAsync()
        {
            return await _userService.GetAllAsync();
        }

        // 2. Get user by ID
        public async Task<UserDto> GetUserByIdAsync(int userId)
        {
            return await _userService.GetByIdAsync(userId);
        }

        // 3. Add a new user
        public async Task AddUserAsync(UserDto userDto)
        {
            await _userService.AddAsync(userDto);
        }

        // 4. Update an existing user
        public async Task UpdateUserAsync(int userId, UserDto userDto)
        {
            await _userService.UpdateAsync(userId, userDto);
        }

        // 5. Delete a user
        public async Task DeleteUserAsync(int userId)
        {
            await _userService.DeleteAsync(userId);
        }

        // 6. Send WhatsApp message to a client
        public async Task SendMessageToClientAsync(int userId, int clientId, string message)
        {
            await ValidateAccessForMessaging(userId);

            var client = await _clientService.GetByIdAsync(clientId);
            if (client == null)
                throw new Exception("Client not found");

            await _notificationService.SendWhatsAppMessageAsync(client.PhoneNumber, message);
        }

        // 7. Send WhatsApp message to a driver
        public async Task SendMessageToDriverAsync(int userId, int driverId, string message)
        {
            await ValidateAccessForMessaging(userId);

            var driver = await _driverService.GetByIdAsync(driverId);
            if (driver == null)
                throw new Exception("Driver not found");

            await _notificationService.SendWhatsAppMessageAsync(driver.PhoneNumber, message);
        }

        // 8. Receive vehicle details, ETA, and route information
        public async Task<string> GetVehicleDetailsAsync(int userId, string vehicleId)
        {
            await ValidateAccessForVehicleDetails(userId);

            // Mock integration with a vehicle tracking service
            var vehicleDetails = await GetVehicleTrackingDetails(vehicleId);
            return $"Vehicle {vehicleId} is currently at {vehicleDetails.Location}, ETA: {vehicleDetails.ETA}, Route: {vehicleDetails.Route}.";
        }

        // Helper to validate access for messaging
        private async Task ValidateAccessForMessaging(int userId)
        {
            var user = await _userService.GetByIdAsync(userId);
            if (user == null)
                throw new Exception("User not found");

            var accessLevel = await _accessLevelService.GetByIdAsync(user.AccessLevelId);
            if (!accessLevel.Permissions.Contains("CanSendWhatsApp"))
                throw new UnauthorizedAccessException("User does not have permission to send WhatsApp messages.");
        }

        // Helper to validate access for vehicle details
        private async Task ValidateAccessForVehicleDetails(int userId)
        {
            var user = await _userService.GetByIdAsync(userId);
            if (user == null)
                throw new Exception("User not found");

            var accessLevel = await _accessLevelService.GetByIdAsync(user.AccessLevelId);
            if (!accessLevel.Permissions.Contains("CanViewVehicleDetails"))
                throw new UnauthorizedAccessException("User does not have permission to view vehicle details.");
        }

        // Mock method to simulate fetching vehicle tracking details
        private async Task<(string Location, string ETA, string Route)> GetVehicleTrackingDetails(string vehicleId)
        {
            // Simulate async API call to a vehicle tracking service
            await Task.Delay(100); // Simulate API latency
            return ("Location XYZ", "15:30 PM", "Route ABC");
        }
    }
}
