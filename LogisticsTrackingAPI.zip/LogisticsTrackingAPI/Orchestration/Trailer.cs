﻿using LogisticsTrackingAPI.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class TrailerOrchestration
    {
        private readonly TrailerService _trailerService;
        private readonly ClientToTrailerService _clientToTrailerService;

        public TrailerOrchestration(TrailerService trailerService, ClientToTrailerService clientToTrailerService)
        {
            _trailerService = trailerService ?? throw new ArgumentNullException(nameof(trailerService));
            _clientToTrailerService = clientToTrailerService ?? throw new ArgumentNullException(nameof(clientToTrailerService));
        }


        public async Task AssignTrailerToClientAsync(int trailerId, int clientId, string goodsDescription)
        {
            var trailer = await _trailerService.GetByIdAsync(trailerId);
            if (trailer == null || trailer.Status != "Available")
                throw new InvalidOperationException("Trailer is not available for assignment");

            var mappingDto = new ClientToTrailerDto
            {
                TrailerId = trailerId,
                ClientId = clientId,
                GoodsDescription = goodsDescription,
                DateAssigned = DateTime.UtcNow
            };

            await _clientToTrailerService.AddAsync(mappingDto);

            trailer.Status = "Assigned";
            await _trailerService.UpdateAsync(trailerId, trailer);
        }
        public async Task<List<TrailerDto>> GetAvailableTrailersAsync()
        {
            return await _trailerService.GetAllAsync(); // Filter by availability if needed
        }
    }
}