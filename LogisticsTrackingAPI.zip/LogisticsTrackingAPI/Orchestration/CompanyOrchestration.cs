﻿using LogisticsTrackingAPI.Services;

public class CompanyOrchestration
{
    private readonly CompanyService _companyService;

    public CompanyOrchestration(CompanyService companyService)
    {
        _companyService = companyService;
    }

    public async Task<List<CompanyDto>> GetAllCompaniesAsync()
    {
        return await _companyService.GetAllAsync();
    }

    public async Task<CompanyDto> GetCompanyByIdAsync(int id)
    {
        return await _companyService.GetByIdAsync(id);
    }

    public async Task<int> CreateCompanyAsync(CompanyDto dto)
    {
        return await _companyService.AddAsync(dto);
    }

    public async Task<bool> UpdateCompanyAsync(int id, CompanyDto dto)
    {
        var result = await _companyService.UpdateAsync(id, dto);
        if (!result)
        {
            // Handle the case where the update was not successful (e.g., company not found)
            throw new KeyNotFoundException($"Company with ID {id} not found.");
        }
        return result;
    }

    public async Task<bool> DeleteCompanyAsync(int id)
    {
        return await _companyService.DeleteAsync(id);
    }
}
