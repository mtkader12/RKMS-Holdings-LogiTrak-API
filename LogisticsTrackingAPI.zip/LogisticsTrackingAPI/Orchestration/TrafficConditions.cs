﻿using LogisticsTrackingAPI.Services;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace LogisticsTrackingAPI.Orchestration
{
    public class TrafficConditionsOrchestration
    {
        private readonly TrafficConditionsService _trafficConditionsService;

        public TrafficConditionsOrchestration(TrafficConditionsService trafficConditionsService)
        {
            _trafficConditionsService = trafficConditionsService;
        }

        // Fetch and save traffic conditions for a delivery
        public async Task AddTrafficConditionsForDeliveryAsync(string pickupLocation, string deliveryLocation)
        {
            // Fetch traffic conditions from API
            await _trafficConditionsService.AddTrafficConditionsFromApiAsync(pickupLocation, deliveryLocation);
        }

        // Get all traffic conditions
        public async Task<List<TrafficConditionsDto>> GetAllTrafficConditionsAsync()
        {
            return await _trafficConditionsService.GetAllAsync();
        }

        // Get traffic conditions for a specific delivery
        public async Task<List<TrafficConditionsDto>> GetTrafficConditionsForDeliveryAsync(string pickupLocation, string deliveryLocation)
        {
            return await _trafficConditionsService.GetTrafficConditionsFromApiAsync(pickupLocation, deliveryLocation);
        }

        // Delete traffic conditions by ID
        public async Task<bool> DeleteTrafficConditionAsync(int id)
        {
            return await _trafficConditionsService.DeleteAsync(id);
        }

        // Update traffic conditions
        public async Task<bool> UpdateTrafficConditionAsync(int id, TrafficConditionsDto trafficConditionDto)
        {
            return await _trafficConditionsService.UpdateAsync(id, trafficConditionDto);
        }
    }
}
