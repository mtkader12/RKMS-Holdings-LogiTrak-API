﻿using LogisticsTrackingAPI.Services;

public class PricingOrchestration
{
    private readonly PricingService _pricingService;

    public PricingOrchestration(PricingService pricingService)
    {
        _pricingService = pricingService;
    }

    public async Task<List<PricingDto>> GetAllPricingAsync()
    {
        return await _pricingService.GetAllAsync();
    }

    public async Task<PricingDto> GetPricingByIdAsync(int id)
    {
        return await _pricingService.GetByIdAsync(id);
    }

    public async Task<int> CreatePricingAsync(PricingDto dto)
    {
        return await _pricingService.AddAsync(dto);
    }

    public async Task<bool> UpdatePricingAsync(int id, PricingDto dto)
    {
        return await _pricingService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeletePricingAsync(int id)
    {
        return await _pricingService.DeleteAsync(id);
    }
}
