﻿using LogisticsTrackingAPI.Constants;
using LogisticsTrackingAPI.ResourceAccess;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class DriverOrchestration
    {
        private readonly DriverResource _driverResource;
        private readonly NotificationService _notificationService;

        public DriverOrchestration(DriverResource driverResource, NotificationService notificationService)
        {
            _driverResource = driverResource;
            _notificationService = notificationService;
        }

        // 1. Get all drivers
        public async Task<List<Driver>> GetAllDriversAsync()
        {
            return await _driverResource.GetAllAsync();
        }

        // 2. Get a driver by ID
        public async Task<Driver> GetDriverByIdAsync(int driverId)
        {
            var driver = await _driverResource.GetByIdAsync(driverId);
            if (driver == null)
                throw new Exception("Driver not found");
            return driver;
        }

        // 3. Add a new driver
        public async Task AddDriverAsync(Driver driver)
        {
            var exists = await _driverResource.ExistsAsync(driver.LicenseNumber);
            if (exists)
                throw new Exception("A driver with the same license number already exists");

            await _driverResource.AddAsync(driver);
        }

        // 4. Update an existing driver
        public async Task UpdateDriverAsync(int driverId, Driver updatedDriver)
        {
            var existingDriver = await _driverResource.GetByIdAsync(driverId);
            if (existingDriver == null)
                throw new Exception("Driver not found");

            existingDriver.Name = updatedDriver.Name;
            existingDriver.PhoneNumber = updatedDriver.PhoneNumber;
            existingDriver.LicenseNumber = updatedDriver.LicenseNumber;

            await _driverResource.UpdateAsync(existingDriver);
        }

        // 5. Delete a driver
        public async Task DeleteDriverAsync(int driverId)
        {
            var driver = await _driverResource.GetByIdAsync(driverId);
            if (driver == null)
                throw new Exception("Driver not found");

            await _driverResource.DeleteAsync(driver);
        }

        // 6. Send a WhatsApp message to the driver
        public async Task SendDriverUpdateAsync(int driverId, int messageIndex)
        {
            // Validate the message index
            if (messageIndex < 0 || messageIndex >= PredefinedMessages.DriverMessages.Count)
                throw new ArgumentOutOfRangeException(nameof(messageIndex), "Invalid message index");

            // Get the driver
            var driver = await _driverResource.GetByIdAsync(driverId);
            if (driver == null)
                throw new Exception("Driver not found");

            // Get the predefined message
            var message = PredefinedMessages.DriverMessages[messageIndex];

            // Send the message via WhatsApp
            await _notificationService.SendWhatsAppMessageAsync(driver.PhoneNumber, message);
        }

        // 7. Assign a trailer and vehicle to the driver
        public async Task AssignTrailerAndVehicleAsync(int driverId, int trailerId, int vehicleId)
        {
            var driver = await _driverResource.GetByIdAsync(driverId);
            if (driver == null)
                throw new Exception("Driver not found");

            // Assuming Driver has TrailerId and VehicleId fields
            driver.TrailerId = trailerId;
            driver.VehicleId = vehicleId;

            await _driverResource.UpdateAsync(driver);
        }
    }
}
