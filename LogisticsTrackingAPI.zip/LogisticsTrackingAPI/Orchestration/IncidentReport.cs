﻿//using LogisticsTrackingAPI.Services;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace LogisticsTrackingAPI.Orchestration
//{
//    /// <summary>
//    /// Orchestration layer for managing incident reports and their impact on drivers' performance.
//    /// </summary>
//    public class IncidentReportOrchestration
//    {
//        private readonly IncidentReportService _incidentReportService;
//        private readonly DeliveryService _deliveryService;
//        private readonly DriverService _driverService;
//        private readonly DriverPerformanceService _driverPerformanceService;

//        public IncidentReportOrchestration(
//            IncidentReportService incidentReportService,
//            DeliveryService deliveryService,
//            DriverService driverService,
//            DriverPerformanceService driverPerformanceService)
//        {
//            _incidentReportService = incidentReportService ?? throw new ArgumentNullException(nameof(incidentReportService));
//            _deliveryService = deliveryService ?? throw new ArgumentNullException(nameof(deliveryService));
//            _driverService = driverService ?? throw new ArgumentNullException(nameof(driverService));
//            _driverPerformanceService = driverPerformanceService ?? throw new ArgumentNullException(nameof(driverPerformanceService));
//        }

//        /// <summary>
//        /// Adds a new incident report and updates the associated driver's performance.
//        /// </summary>
//        public async Task<int> AddIncidentReportAndAdjustPerformanceAsync(IncidentReportDto dto)
//        {
//            ValidateIncidentReportDto(dto);

//            // Validate the delivery
//            if (!await _deliveryService.ExistsAsync(dto.DeliveryId))
//                throw new KeyNotFoundException("Delivery not found");

//            var delivery = await _deliveryService.GetByIdAsync(dto.DeliveryId);
//            if (delivery.DriverId == null || delivery.DriverId == 0)
//                throw new Exception("No driver is assigned to this delivery.");

//            // Validate the driver
//            var driver = await _driverService.GetByIdAsync(delivery.DriverId.Value);
//            if (driver == null)
//                throw new Exception("Driver not found.");

//            // Add the incident report
//            var incidentId = await _incidentReportService.AddAsync(dto);

//            // Update the driver's performance based on the incident
//            await UpdateDriverPerformanceAsync(delivery.DriverId.Value, dto);

//            return incidentId;
//        }

//        /// <summary>
//        /// Updates the driver's performance metrics based on the incident severity.
//        /// </summary>
//        /// 

//        private DriverPerformanceDto MapToDto(DriverPerformance performance)
//        {
//            return new DriverPerformanceDto
//            {
//                Id = performance.Id,
//                DriverId = performance.DriverId,
//                DeliveryId = performance.DeliveryId,
//                MilesDriven = performance.MilesDriven,
//                FuelConsumed = performance.FuelConsumed,
//                TimeTaken = performance.TimeTaken,
//                PerformanceRating = performance.PerformanceRating,
//                AIOverallScore = performance.AIOverallScore,
//                DriverName = performance.Driver?.Name,
//                DeliveryDetails = $"{performance.Delivery?.PickupLocation} -> {performance.Delivery?.DeliveryLocation}"
//            };
//        }

//        private DriverPerformance MapToEntity(DriverPerformanceDto dto)
//        {
//            return new DriverPerformance
//            {
//                Id = dto.Id,
//                DriverId = dto.DriverId,
//                DeliveryId = dto.DeliveryId,
//                MilesDriven = dto.MilesDriven,
//                FuelConsumed = dto.FuelConsumed,
//                TimeTaken = dto.TimeTaken,
//                PerformanceRating = dto.PerformanceRating,
//                AIOverallScore = dto.AIOverallScore
//            };
//        }

//        private void ValidateIncidentReportDto(IncidentReportDto dto)
//        {
//            if (dto == null) throw new ArgumentNullException(nameof(dto));
//            if (dto.DeliveryId <= 0) throw new ArgumentException("Invalid DeliveryId.");
//            if (string.IsNullOrWhiteSpace(dto.Severity)) throw new ArgumentException("Severity is required.");
//        }

//        private async Task<DriverPerformanceDto> UpdateDriverPerformanceAsync(int driverId, IncidentReportDto incident)
//        {
//            // Fetch the existing performance record for this driver and delivery
//            var performance = await _driverPerformanceService.GetByDriverAndDeliveryAsync(driverId, incident.DeliveryId);

//            if (performance == null)
//            {
//                // Use a factory or service to create a new record with proper initialization
//                var newPerformance = CreateNewPerformanceRecord(driverId, incident);
//                await _driverPerformanceService.SaveOrUpdateAsync(newPerformance);

//                // Convert to DTO after saving
//                performance = newPerformance;
//            }

//            // Use AI service to calculate the new performance rating based on incident
//            var aiService = new AIService();
//            var newRating = await aiService.CalculatePerformanceRatingAsync(performance, incident);

//            if (string.IsNullOrEmpty(newRating))
//                throw new InvalidOperationException("AI failed to calculate a valid performance rating.");

//            // Update the performance record with the AI-generated rating
//            performance.PerformanceRating = newRating;
//            await _driverPerformanceService.SaveOrUpdateAsync(performance);

//            // Convert the updated performance record to DTO and return
//            return MapToDto(performance);
//        }


//        // Factory method to create a new DriverPerformance object
//        private DriverPerformance CreateNewPerformanceRecord(int driverId, IncidentReportDto incident)
//        {
//            return new DriverPerformance
//            {
//                DriverId = driverId,
//                DeliveryId = incident.DeliveryId,
//                MilesDriven = 0, // Default
//                FuelConsumed = 0, // Default
//                TimeTaken = TimeSpan.Zero, // Default
//                PerformanceRating = "Average" // Default
//            };
//        }


//        /// <summary>
//        /// Retrieves incident reports for a specific driver.
//        /// </summary>
//        public async Task<List<IncidentReportDto>> GetIncidentReportsByDriverAsync(int driverId)
//        {
//            // Get all deliveries assigned to the driver
//            var deliveries = await _deliveryService.GetDeliveriesByDriverIdAsync(driverId);
//            if (deliveries == null || !deliveries.Any())
//                return new List<IncidentReportDto>();

//            // Get all incident reports
//            var allReports = await _incidentReportService.GetAllAsync();

//            // Filter incidents by deliveries assigned to this driver
//            var driverIncidents = allReports.Where(ir => deliveries.Any(d => d.Id == ir.DeliveryId)).ToList();

//            return driverIncidents;
//        }

//        /// <summary>
//        /// Retrieves all incident reports.
//        /// </summary>
//        public async Task<List<IncidentReportDto>> GetAllIncidentReportsAsync()
//        {
//            return await _incidentReportService.GetAllAsync();
//        }

//        /// <summary>
//        /// Retrieves an incident report by ID.
//        /// </summary>
//        public async Task<IncidentReportDto> GetIncidentReportByIdAsync(int id)
//        {
//            return await _incidentReportService.GetByIdAsync(id);
//        }
//    }
//}
