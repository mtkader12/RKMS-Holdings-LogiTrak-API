﻿using LogisticsTrackingAPI.Services;

public class NotificationOrchestration : BaseOrchestration
{
    private readonly NotificationService _notificationService;

    public NotificationOrchestration(NotificationService notificationService)
    {
        _notificationService = notificationService;
    }

    public async Task SendToClientAsync(int clientId, string message)
    {
        try
        {
            // Fetch client contact details
            var client = await _notificationService.GetClientContactAsync(clientId);

            if (client == null || string.IsNullOrEmpty(client.PhoneNumber))
                throw new KeyNotFoundException("Client contact details not found.");

            // Send WhatsApp notification
            await _notificationService.SendWhatsAppNotificationAsync(client.PhoneNumber, message);
        }
        catch (Exception ex)
        {
            HandleException(ex);
        }
    }

    public async Task SendToCompanyUserAsync(int companyId, string message)
    {
        try
        {
            // Fetch company user contact details
            var companyUser = await _notificationService.GetCompanyUserContactAsync(companyId);

            if (companyUser == null || string.IsNullOrEmpty(companyUser.PhoneNumber))
                throw new KeyNotFoundException("Company user contact details not found.");

            // Send WhatsApp notification
            await _notificationService.SendWhatsAppNotificationAsync(companyUser.PhoneNumber, message);
        }
        catch (Exception ex)
        {
            HandleException(ex);
        }
    }
}
