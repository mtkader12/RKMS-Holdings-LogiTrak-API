﻿using LogisticsTrackingAPI.Services;

public class ClientOrchestration
{
    private readonly ClientService _clientService;

    public ClientOrchestration(ClientService clientService)
    {
        _clientService = clientService;
    }

    public async Task<List<ClientDto>> GetAllClientsAsync()
    {
        return await _clientService.GetAllAsync();
    }

    public async Task<ClientDto> GetClientByIdAsync(int id)
    {
        return await _clientService.GetByIdAsync(id);
    }

    public async Task<int> CreateClientAsync(ClientDto dto)
    {
        return await _clientService.AddAsync(dto);
    }

    public async Task<bool> UpdateClientAsync(int id, ClientDto dto)
    {
        return await _clientService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteClientAsync(int id)
    {
        return await _clientService.DeleteAsync(id);
    }
}
