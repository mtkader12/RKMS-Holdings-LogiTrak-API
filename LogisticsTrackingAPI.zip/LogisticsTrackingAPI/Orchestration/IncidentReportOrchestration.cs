﻿using LogisticsTrackingAPI.Services;

public class IncidentReportOrchestration
{
    private readonly IncidentReportService _incidentReportService;

    public IncidentReportOrchestration(IncidentReportService incidentReportService)
    {
        _incidentReportService = incidentReportService;
    }

    public async Task<List<IncidentReportDto>> GetAllIncidentReportsAsync()
    {
        return await _incidentReportService.GetAllAsync();
    }

    public async Task<IncidentReportDto> GetIncidentReportByIdAsync(int id)
    {
        return await _incidentReportService.GetByIdAsync(id);
    }

    public async Task<int> CreateIncidentReportAsync(IncidentReportDto dto)
    {
        return await _incidentReportService.AddAsync(dto);
    }

    public async Task<bool> UpdateIncidentReportAsync(int id, IncidentReportDto dto)
    {
        return await _incidentReportService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteIncidentReportAsync(int id)
    {
        return await _incidentReportService.DeleteAsync(id);
    }
}
