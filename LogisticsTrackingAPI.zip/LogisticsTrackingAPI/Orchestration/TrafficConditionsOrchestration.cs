﻿using LogisticsTrackingAPI.Services;

public class TrafficConditionsOrchestration
{
    private readonly TrafficConditionsService _trafficConditionsService;

    public TrafficConditionsOrchestration(TrafficConditionsService trafficConditionsService)
    {
        _trafficConditionsService = trafficConditionsService;
    }

    public async Task<List<TrafficConditionsDto>> GetAllTrafficConditionsAsync()
    {
        return await _trafficConditionsService.GetAllAsync();
    }

    public async Task<TrafficConditionsDto> GetTrafficConditionByIdAsync(int id)
    {
        return await _trafficConditionsService.GetByIdAsync(id);
    }

    public async Task<int> CreateTrafficConditionAsync(TrafficConditionsDto dto)
    {
        return await _trafficConditionsService.AddAsync(dto);
    }

    public async Task<bool> UpdateTrafficConditionAsync(int id, TrafficConditionsDto dto)
    {
        return await _trafficConditionsService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteTrafficConditionAsync(int id)
    {
        return await _trafficConditionsService.DeleteAsync(id);
    }
}
