﻿using LogisticsTrackingAPI.Services;

public class DriverPerformanceOrchestration
{
    private readonly DriverPerformanceService _driverPerformanceService;

    public DriverPerformanceOrchestration(DriverPerformanceService driverPerformanceService)
    {
        _driverPerformanceService = driverPerformanceService;
    }

    public async Task<List<DriverPerformanceDto>> GetAllDriverPerformancesAsync()
    {
        return await _driverPerformanceService.GetAllAsync();
    }

    public async Task<DriverPerformanceDto> GetDriverPerformanceByIdAsync(int id)
    {
        return await _driverPerformanceService.GetByIdAsync(id);
    }

    public async Task<int> CreateDriverPerformanceAsync(DriverPerformanceDto dto)
    {
        return await _driverPerformanceService.AddAsync(dto);
    }

    public async Task<bool> UpdateDriverPerformanceAsync(int id, DriverPerformanceDto dto)
    {
        return await _driverPerformanceService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteDriverPerformanceAsync(int id)
    {
        return await _driverPerformanceService.DeleteAsync(id);
    }
}
