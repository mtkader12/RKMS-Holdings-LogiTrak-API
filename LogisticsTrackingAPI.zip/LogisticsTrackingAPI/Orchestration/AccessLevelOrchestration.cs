﻿using LogisticsTrackingAPI.Services;

public class AccessLevelOrchestration
{
    private readonly AccessLevelServices _accessLevelService;

    public AccessLevelOrchestration(AccessLevelServices accessLevelService)
    {
        _accessLevelService = accessLevelService;
    }

    public async Task<List<AccessLevelDto>> GetAllAccessLevelsAsync()
    {
        return await _accessLevelService.GetAllAsync();
    }

    public async Task<AccessLevelDto> GetAccessLevelByIdAsync(int id)
    {
        return await _accessLevelService.GetByIdAsync(id);
    }

    public async Task<int> CreateAccessLevelAsync(AccessLevelDto dto)
    {
        return await _accessLevelService.AddAsync(dto);
    }

    public async Task<bool> UpdateAccessLevelAsync(int id, AccessLevelDto dto)
    {
        return await _accessLevelService.UpdateAsync(id, dto);
    }

    public async Task<bool> DeleteAccessLevelAsync(int id)
    {
        return await _accessLevelService.DeleteAsync(id);
    }
}
