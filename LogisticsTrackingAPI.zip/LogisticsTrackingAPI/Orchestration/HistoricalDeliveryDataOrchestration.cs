﻿using LogisticsTrackingAPI.Services;

public class HistoricalDeliveryDataOrchestration
{
    private readonly HistoricalDeliveryDataService _historicalDeliveryDataService;

    public HistoricalDeliveryDataOrchestration(HistoricalDeliveryDataService historicalDeliveryDataService)
    {
        _historicalDeliveryDataService = historicalDeliveryDataService;
    }

    public async Task<List<HistoricalDeliveryDataDto>> GetAllHistoricalDataAsync()
    {
        return await _historicalDeliveryDataService.GetAllAsync();
    }

    public async Task<HistoricalDeliveryDataDto> GetHistoricalDataByDeliveryIdAsync(int deliveryId)
    {
        return await _historicalDeliveryDataService.GetByDeliveryIdAsync(deliveryId);
    }

    public async Task<int> AddHistoricalDataAsync(HistoricalDeliveryDataDto dto)
    {
        return await _historicalDeliveryDataService.AddAsync(dto);
    }

    public async Task<bool> UpdateHistoricalDataAsync(int deliveryId, HistoricalDeliveryDataDto dto)
    {
        return await _historicalDeliveryDataService.UpdateAsync(deliveryId, dto);
    }

    public async Task<bool> DeleteHistoricalDataAsync(int deliveryId)
    {
        return await _historicalDeliveryDataService.DeleteAsync(deliveryId);
    }
}
