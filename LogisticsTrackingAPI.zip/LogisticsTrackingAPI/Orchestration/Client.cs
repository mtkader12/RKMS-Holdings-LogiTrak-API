﻿using LogisticsTrackingAPI.Services;
using LogisticsTrackingAPI.Constants;

namespace LogisticsTrackingAPI.Orchestration
{
    public class ClientOrchestration
    {
        private readonly ClientService _clientService;
        private readonly NotificationService _notificationService;

        public ClientOrchestration(ClientService clientService, NotificationService notificationService)
        {
            _clientService = clientService;
            _notificationService = notificationService;
        }

        // 1. Get all clients
        public async Task<List<ClientDto>> GetAllClientsAsync()
        {
            return await _clientService.GetAllAsync();
        }

        // 2. Get a client by ID
        public async Task<ClientDto> GetClientByIdAsync(int clientId)
        {
            return await _clientService.GetByIdAsync(clientId);
        }

        // 3. Add a new client
        public async Task<int> AddClientAsync(ClientDto clientDto)
        {
            return await _clientService.AddAsync(clientDto);
        }

        // 4. Update an existing client
        public async Task<bool> UpdateClientAsync(int clientId, ClientDto clientDto)
        {
            return await _clientService.UpdateAsync(clientId, clientDto);
        }

        // 5. Delete a client
        public async Task<bool> DeleteClientAsync(int clientId)
        {
            return await _clientService.DeleteAsync(clientId);
        }

        // 6. Send a WhatsApp message to a client
        public async Task SendWhatsAppMessageToClientAsync(int clientId, string message)
        {
            var client = await _clientService.GetByIdAsync(clientId);
            if (client == null)
                throw new Exception("Client not found");

            if (string.IsNullOrWhiteSpace(client.PhoneNumber))
                throw new Exception("Client does not have a valid phone number");

            await _notificationService.SendWhatsAppMessageAsync(client.PhoneNumber, message);
        }

        // 7. Notify client about delivery update
        public async Task NotifyClientAboutDeliveryAsync(int clientId, string deliveryStatus)
        {
            var client = await _clientService.GetByIdAsync(clientId);
            if (client == null)
                throw new Exception("Client not found");

            var message = $"Dear {client.Name}, your delivery status is: {deliveryStatus}.";
            await _notificationService.SendWhatsAppMessageAsync(client.PhoneNumber, message);
        }

        // 8. Handle predefined client messages (e.g., Request ETA, Cancel booking)
        public async Task HandleClientMessageAsync(int clientId, int predefinedMessageIndex)
        {
            var client = await _clientService.GetByIdAsync(clientId);
            if (client == null)
                throw new Exception("Client not found");

            // Fetch predefined message
            var predefinedMessages = PredefinedMessages.ClientMessages;
            if (predefinedMessageIndex < 0 || predefinedMessageIndex >= predefinedMessages.Count)
                throw new ArgumentOutOfRangeException(nameof(predefinedMessageIndex), "Invalid message index");

            var message = predefinedMessages[predefinedMessageIndex];
            await _notificationService.SendWhatsAppMessageAsync(client.PhoneNumber, message);
        }
    }
}
