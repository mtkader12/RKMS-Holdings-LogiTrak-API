﻿using LogisticsTrackingAPI.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Orchestration
{
    public class VehicleOrchestration
    {
        private readonly VehicleService _vehicleService;
        private readonly TrailerService _trailerService;

        public VehicleOrchestration(VehicleService vehicleService, TrailerService trailerService)
        {
            _vehicleService = vehicleService ?? throw new ArgumentNullException(nameof(vehicleService));
            _trailerService = trailerService ?? throw new ArgumentNullException(nameof(trailerService));
        }

        public async Task AssignVehicleToTrailerAsync(int vehicleId, int trailerId)
        {
            var vehicle = await _vehicleService.GetByIdAsync(vehicleId);
            if (vehicle == null) throw new KeyNotFoundException("Vehicle not found.");

            var trailer = await _trailerService.GetByIdAsync(trailerId);
            if (trailer == null) throw new KeyNotFoundException("Trailer not found.");

            if (trailer.Status != "Available")
                throw new InvalidOperationException("Trailer is not available for assignment.");

            // Link vehicle and trailer
            trailer.VehicleId = vehicleId;
            trailer.Status = "Assigned";
            await _trailerService.UpdateAsync(trailerId, trailer);
        }

        public async Task<List<VehicleDto>> GetAvailableVehiclesAsync()
        {
            return await _vehicleService.GetAllAsync(); // Filter by availability if needed
        }
    }
}