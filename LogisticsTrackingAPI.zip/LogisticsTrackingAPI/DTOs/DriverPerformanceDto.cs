﻿public class DriverPerformanceDto
{
    public int Id { get; set; }
    public int DriverId { get; set; }
    public int DeliveryId { get; set; }
    public int MilesDriven { get; set; }
    public decimal FuelConsumed { get; set; }
    public TimeSpan TimeTaken { get; set; }
    public string PerformanceRating { get; set; }
    public decimal AIOverallScore { get; set; }
    public string DriverName { get; set; }
    public string DeliveryDetails { get; set; } // JSON or structured data
}
