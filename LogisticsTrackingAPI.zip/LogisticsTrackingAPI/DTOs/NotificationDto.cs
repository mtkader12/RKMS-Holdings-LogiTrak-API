﻿//public class NotificationDto
//{
//    public int Id { get; set; }
//    public int RecipientId { get; set; }
//    public string Message { get; set; }
//    public DateTime SentDate { get; set; }
//    public NotificationStatus Status { get; set; } // Use the enum directly
//}
