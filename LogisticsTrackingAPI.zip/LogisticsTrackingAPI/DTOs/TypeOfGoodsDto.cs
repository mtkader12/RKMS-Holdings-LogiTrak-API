﻿public class TypeOfGoodsDto
{
    public int GoodsId { get; set; }
    public string GoodsType { get; set; }
    public DateTime Timestamp { get; set; }
    public string GoodsName { get; set; }
    public string Category { get; set; }
    public string HazardClass { get; set; }
    public string Description { get; set; }
    public int? TrailerId { get; set; }
    public string TrailerNumber { get; set; }
}
