﻿public class WeatherConditionsDto
{
    public int WeatherId { get; set; }
    public int VehicleId { get; set; }
    public string Condition { get; set; } // e.g., Clear, Rainy, Snowy
    public double Temperature { get; set; } // In Celsius
    public double Humidity { get; set; } // In percentage
    public DateTime Timestamp { get; set; }
    public string Location { get; set; }
    public Vehicle Vehicle { get; set; }
    public string VehicleRegistration { get; set; }
}
