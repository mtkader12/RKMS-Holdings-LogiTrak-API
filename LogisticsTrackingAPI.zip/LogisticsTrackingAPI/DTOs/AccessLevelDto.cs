﻿public class AccessLevelDto
{
    public int AccessLevelId { get; set; }
    public string AccessLevelName { get; set; }
    public string Permissions { get; set; } // JSON or comma-separated string
}
