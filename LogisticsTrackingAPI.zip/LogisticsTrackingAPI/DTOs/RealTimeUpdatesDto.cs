﻿public class RealTimeUpdatesDto
{
    public int Id { get; set; }
    public int VehicleId { get; set; }
    public DateTime Timestamp { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public decimal Speed { get; set; }
    public string VehicleRegistration { get; set; } // Add this property
}
