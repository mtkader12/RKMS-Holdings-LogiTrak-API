﻿public class LogisticsRouteDto
{
    public int Id { get; set; }
    public int DeliveryId { get; set; }
    public string DepotLocation { get; set; }
    public string Stops { get; set; }
    public decimal Distance { get; set; }
    public TimeSpan EstimatedTime { get; set; }
    public string DeliveryDetails { get; set; } // Add this property
                                                // Add collection for TrafficConditions
    public ICollection<TrafficConditions> TrafficConditions { get; set; }
}
