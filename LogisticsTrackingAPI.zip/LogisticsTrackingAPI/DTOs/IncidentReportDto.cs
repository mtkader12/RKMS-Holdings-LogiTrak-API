﻿//public class IncidentReportDto
//{
//    public int Id { get; set; }
//    public int DeliveryId { get; set; }
//    public string Description { get; set; }
//    public DateTime IncidentDate { get; set; }
//    public string Severity { get; set; }
//    public string DeliveryDetails { get; set; } // Add this property
//    public Driver Driver { get; set; } // Add this property
//    public int DriverId { get; set; } // Add this property
//}
