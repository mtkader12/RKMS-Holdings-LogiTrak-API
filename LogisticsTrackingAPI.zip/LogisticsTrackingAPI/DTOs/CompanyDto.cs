﻿public class CompanyDto
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string? Address { get; set; }
    public string? ContactDetails { get; set; } // JSON or string
    public string Email { get; set; }
  //  public string AccountType { get; set; }
}
