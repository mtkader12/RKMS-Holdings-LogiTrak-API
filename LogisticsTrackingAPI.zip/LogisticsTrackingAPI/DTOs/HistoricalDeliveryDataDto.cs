﻿public class HistoricalDeliveryDataDto
{
    public int Id { get; set; }
    public int DeliveryId { get; set; }
    public int VehicleId { get; set; }
    public int DriverId { get; set; }
    public DateTime DeliveryTime { get; set; }
    public string Delays { get; set; }
    public double DistanceTraveled { get; set; }
    public string DriverName { get; set; } // Add this property
    public string VehicleRegistration { get; set; } // Add this property
    public string DeliveryDetails { get; set; } // Add this property for additional delivery details
    public string TrafficConditionsSummary { get; set; } // E.g., "Heavy traffic near stops"
    public string WeatherConditionsSummary { get; set; } // E.g., "Rainy with fog"

}
