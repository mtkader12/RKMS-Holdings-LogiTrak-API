﻿public class ClientToTrailerDto
{
    public int ClientToTrailerId { get; set; }
    public int ClientId { get; set; }
    public int TrailerId { get; set; }
    public string GoodsDescription { get; set; }
    public DateTime DateAssigned { get; set; }
    public string ClientName { get; set; } // Ensure this exists
    public string TrailerNumber { get; set; } // Ensure this exists
}
