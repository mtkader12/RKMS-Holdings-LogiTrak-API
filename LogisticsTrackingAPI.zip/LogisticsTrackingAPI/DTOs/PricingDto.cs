﻿public class PricingDto
{
    public int Id { get; set; }
    public string TrailerType { get; set; }
    public decimal DistanceRate { get; set; }
    public decimal LoadRate { get; set; }
    public decimal ContractRate { get; set; }
}
