﻿public class DeliveryDto
{
    public int Id { get; set; }
    public int ClientId { get; set; }
    public string LoadType { get; set; } // Full Trailer, Pallets
    public string PickupLocation { get; set; }
    public string DeliveryLocation { get; set; }
    public int? PalletCount { get; set; }
    public string Urgency { get; set; } // High, Medium, Low
    public decimal Pricing { get; set; }
    public DateTime ScheduledDate { get; set; }
    public string ClientName { get; set; }
    public string DeliveryDetails { get; set; } // JSON or structured data
    public bool HasArrears { get; set; } // New field
    public int? DriverId { get; set; } // New field
    public int RiskLevel { get; set; } // 1 = Low, 5 = High
    public int TrailerId { get; set; }

}
