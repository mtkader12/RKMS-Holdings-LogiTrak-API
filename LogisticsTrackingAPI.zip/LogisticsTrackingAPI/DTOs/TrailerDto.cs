﻿public class TrailerDto
{
    public int TrailerId { get; set; }
    public string TrailerNumber { get; set; }
    public string TrackerId { get; set; }
    public int Capacity { get; set; }
    public string Type { get; set; }
    public string Status { get; set; }
    public string Location { get; set; }
    public DateTime LastServiced { get; set; }
    public int VehicleId { get; set; }
    public int DriverId { get; set; }
    public int DeliveryId { get; set; }

    public int ClientId { get; set; }
}
