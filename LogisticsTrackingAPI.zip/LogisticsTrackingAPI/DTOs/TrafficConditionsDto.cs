﻿public class TrafficConditionsDto
{
    public int TrafficId { get; set; }
    public int VehicleId { get; set; }
    public string Condition { get; set; }
    public DateTime Timestamp { get; set; }
    public string Location { get; set; }
    public int Severity { get; set; }
    public string VehicleRegistration { get; set; } // Add this property
    public int? LogisticsRouteId { get; set; } // Nullable if traffic may not always link to a route
}
