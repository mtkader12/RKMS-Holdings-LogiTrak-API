﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class TrailerController : ControllerBase
{
    private readonly TrailerOrchestration _trailerOrchestration;

    public TrailerController(TrailerOrchestration trailerOrchestration)
    {
        _trailerOrchestration = trailerOrchestration ?? throw new ArgumentNullException(nameof(trailerOrchestration));
    }

    // 1. Assign a trailer to a client
    [HttpPost("{trailerId}/assign-to-client/{clientId}")]
    public async Task<ActionResult> AssignTrailerToClient(int trailerId, int clientId, [FromQuery] string goodsDescription)
    {
        if (string.IsNullOrWhiteSpace(goodsDescription))
            return BadRequest("Goods description is required.");

        try
        {
            await _trailerOrchestration.AssignTrailerToClientAsync(trailerId, clientId, goodsDescription);
            return Ok("Trailer assigned successfully.");
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 2. Get all available trailers
    [HttpGet("available")]
    public async Task<ActionResult<List<TrailerDto>>> GetAvailableTrailers()
    {
        var trailers = await _trailerOrchestration.GetAvailableTrailersAsync();
        return Ok(trailers);
    }
}
