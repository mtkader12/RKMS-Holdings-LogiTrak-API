﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class WeatherConditionsController : ControllerBase
{
    private readonly WeatherConditionsOrchestration _weatherConditionsOrchestration;

    public WeatherConditionsController(WeatherConditionsOrchestration weatherConditionsOrchestration)
    {
        _weatherConditionsOrchestration = weatherConditionsOrchestration ?? throw new ArgumentNullException(nameof(weatherConditionsOrchestration));
    }

    // 1. Adjust logistics route based on weather conditions
    [HttpPost("adjust/{deliveryId}")]
    public async Task<ActionResult<int>> InfluenceRouteWithWeather(int deliveryId)
    {
        try
        {
            var adjustedEta = await _weatherConditionsOrchestration.InfluenceRouteWithWeatherAsync(deliveryId);
            return Ok(new { AdjustedETA = adjustedEta });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 2. Get weather conditions for a delivery
    [HttpGet("conditions")]
    public async Task<ActionResult<List<WeatherConditionsDto>>> GetWeatherConditionsForDelivery(
        [FromQuery] string pickupLocation, [FromQuery] string deliveryLocation)
    {
        if (string.IsNullOrWhiteSpace(pickupLocation) || string.IsNullOrWhiteSpace(deliveryLocation))
            return BadRequest("Pickup and delivery locations are required.");

        try
        {
            var weatherConditions = await _weatherConditionsOrchestration.GetWeatherConditionsForDeliveryAsync(pickupLocation, deliveryLocation);
            return Ok(weatherConditions);
        }
        catch (HttpRequestException ex)
        {
            return StatusCode(502, ex.Message);
        }
    }

    // 3. Get weather for a specific location
    [HttpGet("location")]
    public async Task<ActionResult<WeatherConditionsDto>> GetWeatherForLocation([FromQuery] string location)
    {
        if (string.IsNullOrWhiteSpace(location))
            return BadRequest("Location is required.");

        try
        {
            var weather = await _weatherConditionsOrchestration.GetWeatherForLocationAsync(location);
            return Ok(weather);
        }
        catch (HttpRequestException ex)
        {
            return StatusCode(502, ex.Message);
        }
    }
}
