﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class DriverPerformanceController : ControllerBase
{
    private readonly DriverPerformanceOrchestration _driverPerformanceOrchestration;

    public DriverPerformanceController(DriverPerformanceOrchestration driverPerformanceOrchestration)
    {
        _driverPerformanceOrchestration = driverPerformanceOrchestration ?? throw new ArgumentNullException(nameof(driverPerformanceOrchestration));
    }

    // 1. Get all driver performance records
    [HttpGet]
    public async Task<ActionResult<List<DriverPerformanceDto>>> GetAllPerformances()
    {
        var performances = await _driverPerformanceOrchestration.GetAllPerformancesAsync();
        return Ok(performances);
    }

    // 2. Get performance records for a specific driver
    [HttpGet("driver/{driverId}")]
    public async Task<ActionResult<List<DriverPerformanceDto>>> GetPerformancesByDriverId(int driverId)
    {
        try
        {
            var performances = await _driverPerformanceOrchestration.GetPerformancesByDriverIdAsync(driverId);
            return Ok(performances);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 3. Get top-performing drivers
    [HttpGet("top/{count}")]
    public async Task<ActionResult<List<DriverPerformanceDto>>> GetTopPerformingDrivers(int count)
    {
        var topDrivers = await _driverPerformanceOrchestration.GetTopPerformingDriversAsync(count);
        return Ok(topDrivers);
    }

    // 4. Save or update driver performance
    [HttpPost]
    public async Task<ActionResult> SaveOrUpdatePerformance([FromBody] DriverPerformanceDto performanceDto)
    {
        if (performanceDto == null) return BadRequest("Performance data is required.");

        try
        {
            await _driverPerformanceOrchestration.SaveOrUpdatePerformanceAsync(performanceDto);
            return Ok("Performance record saved or updated successfully.");
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 5. Get performance ranking for a driver
    [HttpGet("ranking/{driverId}")]
    public async Task<ActionResult<decimal>> GetDriverRanking(int driverId)
    {
        try
        {
            var ranking = await _driverPerformanceOrchestration.GetDriverRankingAsync(driverId);
            return Ok(ranking);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }
}
