﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class LogisticsRouteController : ControllerBase
{
    private readonly LogisticsRouteOrchestration _logisticsRouteOrchestration;

    public LogisticsRouteController(LogisticsRouteOrchestration logisticsRouteOrchestration)
    {
        _logisticsRouteOrchestration = logisticsRouteOrchestration ?? throw new ArgumentNullException(nameof(logisticsRouteOrchestration));
    }

    // 1. Get all logistics routes
    [HttpGet]
    public async Task<ActionResult<List<LogisticsRouteDto>>> GetAllRoutes()
    {
        var routes = await _logisticsRouteOrchestration.GetAllLogisticsRoutesAsync();
        return Ok(routes);
    }

    // 2. Get a logistics route by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<LogisticsRouteDto>> GetRouteById(int id)
    {
        try
        {
            var route = await _logisticsRouteOrchestration.GetLogisticsRouteByIdAsync(id);
            return Ok(route);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 3. Determine and add a logistics route based on a delivery
    [HttpPost("determine/{deliveryId}")]
    public async Task<ActionResult<int>> DetermineAndAddRoute(int deliveryId)
    {
        try
        {
            var routeId = await _logisticsRouteOrchestration.DetermineAndAddRouteAsync(deliveryId);
            return CreatedAtAction(nameof(GetRouteById), new { id = routeId }, new { RouteId = routeId });
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 4. Update an existing logistics route
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateRoute(int id, [FromBody] LogisticsRouteDto routeDto)
    {
        if (routeDto == null) return BadRequest("Route data is required.");

        try
        {
            var success = await _logisticsRouteOrchestration.UpdateLogisticsRouteAsync(id, routeDto);
            if (!success) return NotFound();
            return NoContent();
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 5. Delete a logistics route
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteRoute(int id)
    {
        try
        {
            var success = await _logisticsRouteOrchestration.DeleteLogisticsRouteAsync(id);
            if (!success) return NotFound();
            return NoContent();
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }
}
