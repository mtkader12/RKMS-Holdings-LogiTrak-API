﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ClientController : ControllerBase
{
    private readonly ClientOrchestration _clientOrchestration;

    public ClientController(ClientOrchestration clientOrchestration)
    {
        _clientOrchestration = clientOrchestration ?? throw new ArgumentNullException(nameof(clientOrchestration));
    }

    // 1. Get all clients
    [HttpGet]
    public async Task<ActionResult<List<ClientDto>>> GetAllClients()
    {
        var clients = await _clientOrchestration.GetAllClientsAsync();
        return Ok(clients);
    }

    // 2. Get a client by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<ClientDto>> GetClientById(int id)
    {
        var client = await _clientOrchestration.GetClientByIdAsync(id);
        if (client == null) return NotFound();
        return Ok(client);
    }

    // 3. Add a new client
    [HttpPost]
    public async Task<ActionResult<int>> AddClient([FromBody] ClientDto clientDto)
    {
        if (clientDto == null) return BadRequest("Client data is required.");

        var clientId = await _clientOrchestration.AddClientAsync(clientDto);
        return CreatedAtAction(nameof(GetClientById), new { id = clientId }, clientDto);
    }

    // 4. Update an existing client
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateClient(int id, [FromBody] ClientDto clientDto)
    {
        if (clientDto == null) return BadRequest("Client data is required.");

        var success = await _clientOrchestration.UpdateClientAsync(id, clientDto);
        if (!success) return NotFound();
        return NoContent();
    }

    // 5. Delete a client
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteClient(int id)
    {
        var success = await _clientOrchestration.DeleteClientAsync(id);
        if (!success) return NotFound();
        return NoContent();
    }

    // 6. Send a WhatsApp message to a client
    [HttpPost("{id}/whatsapp")]
    public async Task<ActionResult> SendWhatsAppMessageToClient(int id, [FromBody] string message)
    {
        if (string.IsNullOrWhiteSpace(message)) return BadRequest("Message content is required.");

        await _clientOrchestration.SendWhatsAppMessageToClientAsync(id, message);
        return Ok("Message sent successfully.");
    }

    // 7. Notify client about delivery update
    [HttpPost("{id}/delivery-status")]
    public async Task<ActionResult> NotifyClientAboutDelivery(int id, [FromBody] string deliveryStatus)
    {
        if (string.IsNullOrWhiteSpace(deliveryStatus)) return BadRequest("Delivery status is required.");

        await _clientOrchestration.NotifyClientAboutDeliveryAsync(id, deliveryStatus);
        return Ok("Notification sent successfully.");
    }

    // 8. Handle predefined client messages
    [HttpPost("{id}/predefined-message")]
    public async Task<ActionResult> HandleClientMessage(int id, [FromBody] int predefinedMessageIndex)
    {
        try
        {
            await _clientOrchestration.HandleClientMessageAsync(id, predefinedMessageIndex);
            return Ok("Message sent successfully.");
        }
        catch (ArgumentOutOfRangeException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
}
