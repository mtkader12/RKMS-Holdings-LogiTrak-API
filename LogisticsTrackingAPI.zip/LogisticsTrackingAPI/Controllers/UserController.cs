﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class UserController : ControllerBase
{
    private readonly UserOrchestration _userOrchestration;

    public UserController(UserOrchestration userOrchestration)
    {
        _userOrchestration = userOrchestration ?? throw new ArgumentNullException(nameof(userOrchestration));
    }

    // 1. Get all users
    [HttpGet]
    public async Task<ActionResult<List<UserDto>>> GetAllUsers()
    {
        var users = await _userOrchestration.GetAllUsersAsync();
        return Ok(users);
    }

    // 2. Get a user by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<UserDto>> GetUserById(int id)
    {
        try
        {
            var user = await _userOrchestration.GetUserByIdAsync(id);
            return Ok(user);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 3. Add a new user
    [HttpPost]
    public async Task<ActionResult> AddUser([FromBody] UserDto userDto)
    {
        if (userDto == null) return BadRequest("User data is required.");

        try
        {
            await _userOrchestration.AddUserAsync(userDto);
            return Ok("User added successfully.");
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 4. Update an existing user
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateUser(int id, [FromBody] UserDto userDto)
    {
        if (userDto == null) return BadRequest("User data is required.");

        try
        {
            await _userOrchestration.UpdateUserAsync(id, userDto);
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 5. Delete a user
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteUser(int id)
    {
        try
        {
            await _userOrchestration.DeleteUserAsync(id);
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 6. Send a WhatsApp message to a client
    [HttpPost("{userId}/send-message/client/{clientId}")]
    public async Task<ActionResult> SendMessageToClient(int userId, int clientId, [FromBody] string message)
    {
        if (string.IsNullOrWhiteSpace(message)) return BadRequest("Message content is required.");

        try
        {
            await _userOrchestration.SendMessageToClientAsync(userId, clientId, message);
            return Ok("Message sent to client successfully.");
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 7. Send a WhatsApp message to a driver
    [HttpPost("{userId}/send-message/driver/{driverId}")]
    public async Task<ActionResult> SendMessageToDriver(int userId, int driverId, [FromBody] string message)
    {
        if (string.IsNullOrWhiteSpace(message)) return BadRequest("Message content is required.");

        try
        {
            await _userOrchestration.SendMessageToDriverAsync(userId, driverId, message);
            return Ok("Message sent to driver successfully.");
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 8. Get vehicle details, ETA, and route information
    [HttpGet("{userId}/vehicle-details/{vehicleId}")]
    public async Task<ActionResult<string>> GetVehicleDetails(int userId, string vehicleId)
    {
        try
        {
            var details = await _userOrchestration.GetVehicleDetailsAsync(userId, vehicleId);
            return Ok(details);
        }
        catch (UnauthorizedAccessException ex)
        {
            return Forbid(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
}
