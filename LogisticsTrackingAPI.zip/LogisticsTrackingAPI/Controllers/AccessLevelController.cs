﻿using Microsoft.AspNetCore.Mvc;
using LogisticsTrackingAPI.Orchestration;
using System.Threading.Tasks;

namespace LogisticsTrackingAPI.Controllers
{
    /// <summary>
    /// Controller to manage Access Levels within the system.
    /// Provides endpoints for CRUD operations on Access Levels.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AccessLevelController : ControllerBase
    {
        private readonly AccessLevelOrchestration _orchestration;

        /// <summary>
        /// Initializes a new instance of the <see cref="AccessLevelController"/> class.
        /// </summary>
        /// <param name="orchestration">The orchestration layer handling business logic for Access Levels.</param>
        public AccessLevelController(AccessLevelOrchestration orchestration)
        {
            _orchestration = orchestration;
        }

        /// <summary>
        /// Retrieves all Access Levels.
        /// </summary>
        /// <returns>A list of all Access Levels in the system.</returns>
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var result = await _orchestration.GetAllAccessLevelsAsync();
            return Ok(result); // Returns a 200 OK response with the Access Levels.
        }

        /// <summary>
        /// Retrieves an Access Level by its ID.
        /// </summary>
        /// <param name="id">The ID of the Access Level to retrieve.</param>
        /// <returns>The Access Level if found, or a 404 Not Found response if it doesn't exist.</returns>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var result = await _orchestration.GetAccessLevelByIdAsync(id);
            if (result == null) return NotFound(); // Returns 404 if the Access Level is not found.
            return Ok(result); // Returns a 200 OK response with the Access Level.
        }

        /// <summary>
        /// Adds a new Access Level.
        /// </summary>
        /// <param name="dto">The data transfer object containing Access Level details.</param>
        /// <returns>The created Access Level's ID with a 201 Created response.</returns>
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] AccessLevelDto dto)
        {
            if (dto == null) return BadRequest("Access Level data is required."); // Returns 400 Bad Request if no data is provided.
            var id = await _orchestration.AddAccessLevelAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id }, dto); // Returns 201 Created with the new Access Level ID.
        }

        /// <summary>
        /// Updates an existing Access Level by its ID.
        /// </summary>
        /// <param name="id">The ID of the Access Level to update.</param>
        /// <param name="dto">The data transfer object containing updated Access Level details.</param>
        /// <returns>A 204 No Content response if updated successfully, or 404 Not Found if the Access Level doesn't exist.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] AccessLevelDto dto)
        {
            if (dto == null) return BadRequest("Access Level data is required."); // Returns 400 Bad Request if no data is provided.
            var updated = await _orchestration.UpdateAccessLevelAsync(id, dto);
            if (!updated) return NotFound(); // Returns 404 if the Access Level is not found.
            return NoContent(); // Returns 204 No Content if updated successfully.
        }

        /// <summary>
        /// Deletes an Access Level by its ID.
        /// </summary>
        /// <param name="id">The ID of the Access Level to delete.</param>
        /// <returns>A 204 No Content response if deleted successfully, or 404 Not Found if the Access Level doesn't exist.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _orchestration.DeleteAccessLevelAsync(id);
            if (!deleted) return NotFound(); // Returns 404 if the Access Level is not found.
            return NoContent(); // Returns 204 No Content if deleted successfully.
        }
    }
}
