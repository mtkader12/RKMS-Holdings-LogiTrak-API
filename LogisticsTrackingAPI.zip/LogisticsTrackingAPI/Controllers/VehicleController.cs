﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class VehicleController : ControllerBase
{
    private readonly VehicleOrchestration _vehicleOrchestration;

    public VehicleController(VehicleOrchestration vehicleOrchestration)
    {
        _vehicleOrchestration = vehicleOrchestration ?? throw new ArgumentNullException(nameof(vehicleOrchestration));
    }

    // 1. Assign a vehicle to a trailer
    [HttpPost("{vehicleId}/assign-to-trailer/{trailerId}")]
    public async Task<ActionResult> AssignVehicleToTrailer(int vehicleId, int trailerId)
    {
        try
        {
            await _vehicleOrchestration.AssignVehicleToTrailerAsync(vehicleId, trailerId);
            return Ok("Vehicle assigned to trailer successfully.");
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 2. Get all available vehicles
    [HttpGet("available")]
    public async Task<ActionResult<List<VehicleDto>>> GetAvailableVehicles()
    {
        var vehicles = await _vehicleOrchestration.GetAvailableVehiclesAsync();
        return Ok(vehicles);
    }
}
