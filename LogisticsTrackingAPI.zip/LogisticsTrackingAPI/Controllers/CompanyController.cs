﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class CompanyController : ControllerBase
{
    private readonly CompanyOrchestration _companyOrchestration;

    public CompanyController(CompanyOrchestration companyOrchestration)
    {
        _companyOrchestration = companyOrchestration ?? throw new ArgumentNullException(nameof(companyOrchestration));
    }

    // 1. Get all companies
    [HttpGet]
    public async Task<ActionResult<List<CompanyDto>>> GetAllCompanies()
    {
        var companies = await _companyOrchestration.GetAllCompaniesAsync();
        return Ok(companies);
    }

    // 2. Get a company by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<CompanyDto>> GetCompanyById(int id)
    {
        var company = await _companyOrchestration.GetCompanyByIdAsync(id);
        if (company == null) return NotFound();
        return Ok(company);
    }

    // 3. Add a new company
    [HttpPost]
    public async Task<ActionResult<int>> AddCompany([FromBody] CompanyDto companyDto)
    {
        try
        {
            var companyId = await _companyOrchestration.AddCompanyAsync(companyDto);
            return CreatedAtAction(nameof(GetCompanyById), new { id = companyId }, companyDto);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    // 4. Update a company
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateCompany(int id, [FromBody] CompanyDto updatedCompanyDto)
    {
        try
        {
            var success = await _companyOrchestration.UpdateCompanyAsync(id, updatedCompanyDto);
            if (!success) return NotFound();
            return NoContent();
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 5. Delete a company
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteCompany(int id)
    {
        try
        {
            var success = await _companyOrchestration.DeleteCompanyAsync(id);
            if (!success) return NotFound();
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    // 6. Get all users in a company
    [HttpGet("{id}/users")]
    public async Task<ActionResult<List<UserDto>>> GetAllUsersInCompany(int id)
    {
        var users = await _companyOrchestration.GetAllUsersInCompanyAsync(id);
        return Ok(users);
    }

    // 7. Get all clients in a company
    [HttpGet("{id}/clients")]
    public async Task<ActionResult<List<ClientDto>>> GetAllClientsInCompany(int id)
    {
        var clients = await _companyOrchestration.GetAllClientsInCompanyAsync(id);
        return Ok(clients);
    }

    // 8. Assign a user to a company
    [HttpPost("{companyId}/assign-user/{userId}")]
    public async Task<ActionResult> AssignUserToCompany(int userId, int companyId)
    {
        try
        {
            await _companyOrchestration.AssignUserToCompanyAsync(userId, companyId);
            return Ok("User assigned to company successfully.");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 9. Assign a client to a company
    [HttpPost("{companyId}/assign-client/{clientId}")]
    public async Task<ActionResult> AssignClientToCompany(int clientId, int companyId)
    {
        try
        {
            await _companyOrchestration.AssignClientToCompanyAsync(clientId, companyId);
            return Ok("Client assigned to company successfully.");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
}
