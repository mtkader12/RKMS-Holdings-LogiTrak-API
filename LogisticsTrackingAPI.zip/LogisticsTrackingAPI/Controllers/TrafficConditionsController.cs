﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class TrafficConditionsController : ControllerBase
{
    private readonly TrafficConditionsOrchestration _trafficConditionsOrchestration;

    public TrafficConditionsController(TrafficConditionsOrchestration trafficConditionsOrchestration)
    {
        _trafficConditionsOrchestration = trafficConditionsOrchestration ?? throw new ArgumentNullException(nameof(trafficConditionsOrchestration));
    }

    // 1. Fetch and save traffic conditions for a delivery
    [HttpPost("delivery")]
    public async Task<ActionResult> AddTrafficConditionsForDelivery([FromQuery] string pickupLocation, [FromQuery] string deliveryLocation)
    {
        if (string.IsNullOrWhiteSpace(pickupLocation) || string.IsNullOrWhiteSpace(deliveryLocation))
            return BadRequest("Pickup and delivery locations are required.");

        await _trafficConditionsOrchestration.AddTrafficConditionsForDeliveryAsync(pickupLocation, deliveryLocation);
        return Ok("Traffic conditions fetched and saved successfully.");
    }

    // 2. Get all traffic conditions
    [HttpGet]
    public async Task<ActionResult<List<TrafficConditionsDto>>> GetAllTrafficConditions()
    {
        var trafficConditions = await _trafficConditionsOrchestration.GetAllTrafficConditionsAsync();
        return Ok(trafficConditions);
    }

    // 3. Get traffic conditions for a specific delivery
    [HttpGet("delivery")]
    public async Task<ActionResult<List<TrafficConditionsDto>>> GetTrafficConditionsForDelivery([FromQuery] string pickupLocation, [FromQuery] string deliveryLocation)
    {
        if (string.IsNullOrWhiteSpace(pickupLocation) || string.IsNullOrWhiteSpace(deliveryLocation))
            return BadRequest("Pickup and delivery locations are required.");

        var trafficConditions = await _trafficConditionsOrchestration.GetTrafficConditionsForDeliveryAsync(pickupLocation, deliveryLocation);
        return Ok(trafficConditions);
    }

    // 4. Delete traffic conditions by ID
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteTrafficCondition(int id)
    {
        var success = await _trafficConditionsOrchestration.DeleteTrafficConditionAsync(id);
        if (!success) return NotFound("Traffic condition not found.");
        return NoContent();
    }

    // 5. Update traffic conditions
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateTrafficCondition(int id, [FromBody] TrafficConditionsDto trafficConditionDto)
    {
        if (trafficConditionDto == null) return BadRequest("Traffic condition data is required.");

        var success = await _trafficConditionsOrchestration.UpdateTrafficConditionAsync(id, trafficConditionDto);
        if (!success) return NotFound("Traffic condition not found.");
        return NoContent();
    }
}
