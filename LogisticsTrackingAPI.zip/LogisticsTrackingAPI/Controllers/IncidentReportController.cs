﻿//using Microsoft.AspNetCore.Mvc;

//[ApiController]
//[Route("api/[controller]")]
//public class IncidentReportController : ControllerBase
//{
//    private readonly IncidentReportOrchestration _incidentReportOrchestration;

//    public IncidentReportController(IncidentReportOrchestration incidentReportOrchestration)
//    {
//        _incidentReportOrchestration = incidentReportOrchestration ?? throw new ArgumentNullException(nameof(incidentReportOrchestration));
//    }

//    // 1. Add a new incident report and adjust driver performance
//    [HttpPost]
//    public async Task<ActionResult<int>> AddIncidentReport([FromBody] IncidentReportDto incidentReportDto)
//    {
//        try
//        {
//            var incidentId = await _incidentReportOrchestration.AddIncidentReportAndAdjustPerformanceAsync(incidentReportDto);
//            return CreatedAtAction(nameof(GetIncidentReportById), new { id = incidentId }, incidentReportDto);
//        }
//        catch (ArgumentException ex)
//        {
//            return BadRequest(ex.Message);
//        }
//        catch (Exception ex)
//        {
//            return NotFound(ex.Message);
//        }
//    }

//    // 2. Get all incident reports
//    [HttpGet]
//    public async Task<ActionResult<List<IncidentReportDto>>> GetAllIncidentReports()
//    {
//        var reports = await _incidentReportOrchestration.GetAllIncidentReportsAsync();
//        return Ok(reports);
//    }

//    // 3. Get an incident report by ID
//    [HttpGet("{id}")]
//    public async Task<ActionResult<IncidentReportDto>> GetIncidentReportById(int id)
//    {
//        try
//        {
//            var report = await _incidentReportOrchestration.GetIncidentReportByIdAsync(id);
//            return Ok(report);
//        }
//        catch (KeyNotFoundException ex)
//        {
//            return NotFound(ex.Message);
//        }
//    }

//    // 4. Get incident reports by driver ID
//    [HttpGet("driver/{driverId}")]
//    public async Task<ActionResult<List<IncidentReportDto>>> GetIncidentReportsByDriver(int driverId)
//    {
//        try
//        {
//            var reports = await _incidentReportOrchestration.GetIncidentReportsByDriverAsync(driverId);
//            return Ok(reports);
//        }
//        catch (Exception ex)
//        {
//            return NotFound(ex.Message);
//        }
//    }
//}
