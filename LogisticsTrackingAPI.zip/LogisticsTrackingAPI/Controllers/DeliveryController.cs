﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class DeliveryController : ControllerBase
{
    private readonly DeliveryOrchestration _deliveryOrchestration;

    public DeliveryController(DeliveryOrchestration deliveryOrchestration)
    {
        _deliveryOrchestration = deliveryOrchestration ?? throw new ArgumentNullException(nameof(deliveryOrchestration));
    }

    // 1. Get all deliveries
    [HttpGet]
    public async Task<ActionResult<List<DeliveryDto>>> GetAllDeliveries()
    {
        var deliveries = await _deliveryOrchestration.GetAllDeliveriesAsync();
        return Ok(deliveries);
    }

    // 2. Get delivery by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<DeliveryDto>> GetDeliveryById(int id)
    {
        var delivery = await _deliveryOrchestration.GetDeliveryByIdAsync(id);
        if (delivery == null) return NotFound();
        return Ok(delivery);
    }

    // 3. Add a new delivery
    [HttpPost]
    public async Task<ActionResult> AddDelivery([FromBody] DeliveryDto deliveryDto)
    {
        if (deliveryDto == null) return BadRequest("Delivery data is required.");

        try
        {
            await _deliveryOrchestration.AddDeliveryAsync(deliveryDto);
            return CreatedAtAction(nameof(GetDeliveryById), new { id = deliveryDto.Id }, deliveryDto);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 4. Update an existing delivery
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateDelivery(int id, [FromBody] DeliveryDto deliveryDto)
    {
        if (deliveryDto == null) return BadRequest("Delivery data is required.");

        try
        {
            await _deliveryOrchestration.UpdateDeliveryAsync(id, deliveryDto);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound("Delivery not found.");
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 5. Delete a delivery
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteDelivery(int id)
    {
        try
        {
            await _deliveryOrchestration.DeleteDeliveryAsync(id);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound("Delivery not found.");
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 6. Check for client arrears
    [HttpGet("client/{clientId}/arrears")]
    public async Task<ActionResult<bool>> CheckClientArrears(int clientId)
    {
        var hasArrears = await _deliveryOrchestration.CheckClientArrearsAsync(clientId);
        return Ok(hasArrears);
    }

    // 7. Get deliveries for a specific client
    [HttpGet("client/{clientId}")]
    public async Task<ActionResult<List<DeliveryDto>>> GetDeliveriesByClientId(int clientId)
    {
        var deliveries = await _deliveryOrchestration.GetDeliveriesByClientIdAsync(clientId);
        return Ok(deliveries);
    }
}
