﻿using LogisticsTrackingAPI.Orchestration;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class DriverController : ControllerBase
{
    private readonly DriverOrchestration _driverOrchestration;

    public DriverController(DriverOrchestration driverOrchestration)
    {
        _driverOrchestration = driverOrchestration ?? throw new ArgumentNullException(nameof(driverOrchestration));
    }

    // 1. Get all drivers
    [HttpGet]
    public async Task<ActionResult<List<Driver>>> GetAllDrivers()
    {
        var drivers = await _driverOrchestration.GetAllDriversAsync();
        return Ok(drivers);
    }

    // 2. Get a driver by ID
    [HttpGet("{id}")]
    public async Task<ActionResult<Driver>> GetDriverById(int id)
    {
        try
        {
            var driver = await _driverOrchestration.GetDriverByIdAsync(id);
            return Ok(driver);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 3. Add a new driver
    [HttpPost]
    public async Task<ActionResult> AddDriver([FromBody] Driver driver)
    {
        try
        {
            await _driverOrchestration.AddDriverAsync(driver);
            return CreatedAtAction(nameof(GetDriverById), new { id = driver.Id }, driver);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    // 4. Update an existing driver
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateDriver(int id, [FromBody] Driver updatedDriver)
    {
        try
        {
            await _driverOrchestration.UpdateDriverAsync(id, updatedDriver);
            return NoContent();
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 5. Delete a driver
    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteDriver(int id)
    {
        try
        {
            await _driverOrchestration.DeleteDriverAsync(id);
            return NoContent();
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 6. Send a WhatsApp message to the driver
    [HttpPost("{id}/send-message/{messageIndex}")]
    public async Task<ActionResult> SendDriverUpdate(int id, int messageIndex)
    {
        try
        {
            await _driverOrchestration.SendDriverUpdateAsync(id, messageIndex);
            return Ok("Message sent successfully.");
        }
        catch (ArgumentOutOfRangeException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }

    // 7. Assign a trailer and vehicle to the driver
    [HttpPost("{id}/assign/{trailerId}/{vehicleId}")]
    public async Task<ActionResult> AssignTrailerAndVehicle(int id, int trailerId, int vehicleId)
    {
        try
        {
            await _driverOrchestration.AssignTrailerAndVehicleAsync(id, trailerId, vehicleId);
            return Ok("Trailer and vehicle assigned successfully.");
        }
        catch (Exception ex)
        {
            return NotFound(ex.Message);
        }
    }
}
